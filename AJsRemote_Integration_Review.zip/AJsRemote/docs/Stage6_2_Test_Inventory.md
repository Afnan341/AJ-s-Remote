# Stage 6.2: test-source inventory

17 Kotlin test files, 71 annotated methods. **None executed** in this environment. Counting test annotations is not coverage.

The 66 tests present in Stage 6.1 include the original 59; five Stage 6.2 tests were added.

## `app/src/test/java/com/ajsremote/authentication/AuthenticationProofTest.kt`
5 methods
- `matchesPythonServerVector`
- `changingDeviceOrChallengeChangesProof`
- `replayKeysDoNotCollideOnDelimiters`
- `rejectsMalformedSecretAndChallenge`
- `rejectsReuseWithinProcess`

## `app/src/test/java/com/ajsremote/authentication/ConnectionLeaseTest.kt`
1 methods
- `concurrentAttemptsAreRejectedAndCancellationReleasesLease`

## `app/src/test/java/com/ajsremote/authentication/PairingClientIntegrationTest.kt`
1 methods
- `successfulPairThenReconnectAuthenticatesWithoutReusingToken`

## `app/src/test/java/com/ajsremote/authentication/PairingErrorCorrelationTest.kt`
1 methods
- `unrelatedInvalidTokenErrorPreservesRecoveryJournal`

## `app/src/test/java/com/ajsremote/authentication/PairingProtocolTest.kt`
6 methods
- `exactPairRequestAndAuthFields`
- `handlesApprovalAndAuthResponses`
- `serverErrorsMapToFailureStates`
- `rejectsErrorWithWrongReplyId`
- `rejectsInvalidAuthenticationAcknowledgements`
- `rejectsWrongReplyAndSecret`

## `app/src/test/java/com/ajsremote/data/DeviceCredentialStoreTest.kt`
1 methods
- `savesLoadsAndClearsWhileKeepingDeviceId`

## `app/src/test/java/com/ajsremote/data/PairedServerCredentialsTest.kt`
3 methods
- `jsonRoundTrip_withFingerprint`
- `jsonRoundTrip_withoutFingerprint_keepsNull`
- `toString_masksDeviceSecret`

## `app/src/test/java/com/ajsremote/data/PairingRecoveryTest.kt`
7 methods
- `lossBeforeSecretLeavesRecoveryMarker`
- `failedSecretStoragePreservesMarkerAndNeverReportsSaved`
- `cancellationDuringStartedApprovalSaveFinishesAtomicCommit`
- `reconnectCanReadCompletedCredentials`
- `duplicateBeginDoesNotOverwriteRecoveryMarker`
- `completionForWrongServerDoesNotClearMarkerOrSaveCredentials`
- `journalCannotBeClearedForDifferentServer`

## `app/src/test/java/com/ajsremote/networking/CertificatePinTest.kt`
3 methods
- `matchingDerCertificateAcceptedAndDifferentRejected`
- `emptyChainAndClientTrustAreRejected`
- `malformedFingerprintIsRejected`

## `app/src/test/java/com/ajsremote/networking/HelloProtocolTest.kt`
4 methods
- `helloUsesServerEnvelopeAndRequiredFields`
- `exactServerAckParses`
- `wrongIdentityAndMalformedChallengeFailClosed`
- `invalidVersionsAndMessagesFailClosed`

## `app/src/test/java/com/ajsremote/networking/ServerConnectionTest.kt`
1 methods
- `websocketSendsHelloAndWaitsForRealAcknowledgement`

## `app/src/test/java/com/ajsremote/pairing/PairingPayloadParserTest.kt`
26 methods
- `validPayloadWithFingerprint_parsesEveryField`
- `validPayloadWithoutFingerprint_hasNullFingerprint`
- `plusSignDecodesToSpace_andUtf8PercentEscapesDecode`
- `unknownParameter_isIgnoredLikeTheServer`
- `boundaryValues_areAccepted`
- `payloadToString_doesNotExposeToken`
- `foreignSchemeOrAuthority_isNotPairingCode`
- `missingQuery_isNotPairingCode`
- `emptyQuery_isMalformed`
- `fragment_isMalformed`
- `rawWhitespaceOrNonAscii_isMalformed`
- `uriLongerThanLimit_isMalformed`
- `parameterWithoutEqualsOrKey_isMalformed`
- `emptyValue_isMalformed`
- `invalidPercentEscapes_areMalformed`
- `invalidUtf8Escapes_areMalformed`
- `tooManyParameters_isMalformed`
- `duplicateParameter_isRejected`
- `missingEachRequiredField_isReportedByName`
- `unsupportedOrNonNumericVersion_isRejected`
- `serverIdHasNoInvented128CharacterLimit`
- `invalidIpv4Addresses_areRejected`
- `invalidPorts_areRejected`
- `invalidTokens_areRejected`
- `invalidNames_areRejected`
- `invalidFingerprints_areRejected`

## `app/src/test/java/com/ajsremote/pairing/PairingPayloadTest.kt`
1 methods
- `everyErrorHasAUserFacingMessage`

## `app/src/test/java/com/ajsremote/pairing/ServerGeneratedQrTest.kt`
2 methods
- `canonicalServerUriIsParsed`
- `serverUriWithoutFingerprintIsParsedAsUnencrypted`

## `app/src/test/java/com/ajsremote/scanner/ScanGateTest.kt`
2 methods
- `acceptsOnlyFirstValueInSession`
- `concurrentCallbacksOnlyDeliverOneValue`

## `app/src/test/java/com/ajsremote/security/EncryptedPayloadTest.kt`
6 methods
- `encodeThenDecode_roundTripsBytes`
- `unknownVersionPrefix_isRejected`
- `wrongPartCount_isRejected`
- `wrongIvLength_isRejected`
- `ciphertextWithoutTag_isRejected`
- `invalidBase64_isRejected`

## `app/src/test/java/com/ajsremote/security/SecretCipherContractTest.kt`
1 methods
- `gcmPayloadRoundTripAndTamperDetection`

## Limits

- MockWebServer tests are scripted peers, not tests of the Linux server. The successful pairing peer returns `auth_ok` without checking the HMAC.
- Fake-cipher DataStore tests do not verify Android Keystore, disk failures, app-process restart, or cryptographic security.
- Correlation, recovery races, CameraX lifecycle, Compose navigation, real TLS pinning and real server interactions require executed tests and device verification.
