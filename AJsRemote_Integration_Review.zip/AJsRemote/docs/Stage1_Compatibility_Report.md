# AJ's Remote: Android Client Compatibility Report (Stage 1)

Source inspected: AJS Remote Server 2.0 ZIP (ajs_remote_server/). Code is the source of truth; docs/PROTOCOL.md matches it on every point below.

## 1. Transport
- WebSocket, text frames only, UTF-8 JSON. Binary frames are rejected. Max frame 16 KiB (16384 bytes).
- Endpoint: `wss://<host>:<port>/` by default, `ws://` only when the PC user disabled TLS (then the QR has no `fp`). Path is ignored.
- Default port 8765 in config; QR carries the actual port (valid range 1024 to 65535).
- Handshake timeout 10 s (CONNECTED/GREETED). Idle timeout 30 s once authenticated, so the app must heartbeat.

## 2. Envelope (every message, both directions)
`{"v":1,"type":"<type>","payload":{...},"id":"<1-64 chars, optional>","re":"<echoed id, optional>"}`
- `v` must be a supported version (1), otherwise fatal `unsupported_version`.
- Unknown payload fields are rejected with `invalid_payload`.

## 3. QR payload (server: qr/generator.py, parse_pairing_uri)
`ajsremote://pair?v=1&sid=<server_id>&host=<ipv4>&port=<port>&token=<token>&name=<url-encoded name>&fp=<sha256 hex>`
- Required, each exactly once: `v`, `sid`, `host`, `port`, `token`, `name`. Empty values are rejected.
- `host`: IPv4 only. `port`: 1024 to 65535. `v`: must be supported. `token`: `[A-Za-z0-9_-]{16,128}`. `name`: at most 64 chars.
- `fp`: optional, but present whenever TLS is on. Exactly 64 lowercase hex chars (SHA-256 of the DER certificate).
- Max 9 query fields. The app must parse strictly and reject anything else.
- Not a browser URL. Scheme is `ajsremote`, host segment is `pair`.

## 4. Session flow
Client to server types: `hello`, `pair_request`, `auth`, `ping`, `bye`. Server to client: `hello_ack`, `pair_pending`, `pair_accepted`, `pair_rejected`, `auth_ok`, `pong`, `error`, `bye`.

**First pairing (no stored secret):**
1. Connect (wss with pinned fingerprint).
2. Send `hello` with `device_id` (16 to 64 chars `[A-Za-z0-9_-]`, generated once, persisted), `device_name` (1 to 64 printable chars), optional `app_version` (max 32).
3. Receive `hello_ack`: `server_id`, `server_name`, `protocol_version`, `paired`, `challenge` (base64url, 32 bytes, one-time).
4. Send `pair_request` with `pairing_token` from the QR. Token is single-use and expires after 120 s by default. An invalid or expired token gives fatal `pairing_token_invalid`.
5. Receive `pair_pending` (`timeout_seconds`). The PC GUI shows the request; the user clicks Approve or Deny.
6. Approved: `pair_accepted` with `device_secret` (base64url, 32 bytes). Shown once, so store it immediately. Denied or timed out: `pair_rejected` with `reason: "denied"`, then the server closes.
7. After `pair_accepted`, the same socket may send `auth` using the same `challenge` from step 3 (the server keeps it).

**Later connections (paired):**
1. Connect, send `hello`, receive `hello_ack` with a fresh `challenge`.
2. Compute the proof (section 5) and send `auth` with `proof`.
3. Receive `auth_ok` (`session_id`, `heartbeat_interval_seconds`, currently 10).
4. Send `ping` every heartbeat interval. Expect `pong`. Treat ~15 s with no pong as dead and reconnect (1 s to 15 s backoff). Never resend the pairing token on reconnect.

**Disconnects:** graceful close sends `bye`. The server sends `bye` with `reason` of `server_shutdown`, `unpaired`, `disconnected_by_server`, or `replaced_by_new_connection` when a new socket for the same `device_id` authenticates.

## 5. Authentication (server: security/authentication.py)
```
key   = SHA256( base64url_decode(device_secret) )          // 32 raw bytes
proof = base64url_nopad( HMAC_SHA256(key, challenge_string + ":" + device_id) )
```
- `challenge_string` is the `challenge` text exactly as received, encoded as UTF-8. Do NOT base64-decode it.
- `device_id` is the same string sent in `hello`. UTF-8 encoded.
- Proof is 43 chars, no padding, `-` and `_` allowed (matches `[A-Za-z0-9_-]{43}`).
- Each challenge allows exactly one `auth` attempt. Failure is fatal `authentication_failed`, and a failure also counts toward the lockout.
- The server stores only SHA256(secret). The app stores the raw secret in encrypted storage (Android Keystore-backed).

## 6. TLS and certificate pinning (server: security/tls.py, docs/TLS.md)
- Self-signed ECDSA P-256 certificate, created on first server start, valid 5 years.
- Fingerprint = lowercase hex SHA-256 of the DER-encoded certificate. This is the `fp` value in the QR.
- The app must pin this value: during the TLS handshake, compare the leaf certificate's DER SHA-256 to `fp` and reject on mismatch. Do not use a trust-all manager, and do not disable hostname or chain checks by any other means.
- The app must still accept the self-signed certificate ONLY because its pinned fingerprint matches. No other certificate is trusted.
- If the QR has no `fp`, the server is in plain `ws://` mode. The app should still allow it only in that case, and show an "unencrypted" warning.

## 7. Error codes the app must handle
`malformed_message`, `message_too_large` (fatal), `unsupported_version` (fatal), `unknown_type`, `invalid_payload`, `not_allowed_in_state`, `pairing_token_invalid` (fatal), `pairing_denied`, `authentication_failed` (fatal), `input_disabled`, `rate_limited`, `temporarily_locked_out` (fatal; 5 failures from one IP in 60 s locks that IP for 60 s), `timeout` (fatal), `internal_error` (fatal).
If `fatal` is true, the server closes right after the error.

## 8. Differences from the brief (must be followed on the server's terms)
| Brief said | Server actually does | Decision |
|---|---|---|
| Six-digit PIN verification | No PIN exists anywhere in the server | Not implemented. Pairing is QR token plus PC-side Approve. |
| Connection token persisted | Persistent credential is `device_secret` (returned once in `pair_accepted`) | Store `device_secret` plus `device_id` and server identity in encrypted DataStore/Keystore. |
| "Server returns authentication response" | Pairing returns `pair_accepted`; login returns `auth_ok` | Implement both as specified. |
| Port unspecified | Default 8765, but the QR is authoritative | Use the QR port. |

## 9. Gaps and risks to watch
- Certificate pinning from a self-signed cert with OkHttp needs a custom `X509TrustManager` or `SSLSocketFactory` that checks only the pinned fingerprint. This is the most error-prone part; test it against a real server.
- Re-pairing: if the PC user removes the device, the next `auth` fails with `authentication_failed` and the app must clear its stored secret and offer to re-scan.
- Token TTL is 120 s by default and configurable (10 to 600 s on the server). The app must not cache QR payloads.
- Not verifiable from here: real-device camera behavior, ML Kit detection rate, and the live handshake. Those need a device and a running server.

## 10. Stage plan
- Stage 1 (this report): done.
- Stage 2: Gradle project, manifest, permissions, DataStore/Keystore storage, QR parser (pure Kotlin, unit tested).
- Stage 3: OkHttp WebSocket client with fingerprint pinning, envelope encode/decode, hello/hello_ack.
- Stage 4: Pairing and HMAC auth, reconnection and heartbeat.
- Stage 5: Compose UI (scanner, status, errors) and wiring.
- Stage 6: Unit tests and an HMAC test vector cross-checked against the server's Python code.
