# Stage 3: Native QR scanner (source implemented, not verified)

## Implemented
- `MainActivity` launches `RemoteApp`, a Compose flow: home, runtime camera permission, scanner, error/retry, and validated-code result.
- `ScannerScreen` uses `PreviewView`, an electric-red frame and animated scan line, plus flashlight and navigation. The frame is a visual guide, not an analysis crop: QR codes visible outside the frame may also be detected.
- `QrCameraSession` owns CameraX preview and analysis use cases, an ML Kit QR-only barcode client, and its analysis executor. It binds to the lifecycle, closes each image proxy, and defers owned-use-case unbinding while its ML Kit request is in flight. One atomic `ScanGate` accepts only one result per scanner session. A retry creates a fresh session.
- Permission denied offers retry and app-settings navigation; permission is rechecked when returning to the app. Camera/scanner errors offer retry. Devices without a flashlight get a disabled flashlight button.
- Successful text is validated using the existing Stage 2 parser. The app displays the server name/address and whether a fingerprint exists, plus **Not connected**. It does not try to pair, consume the single-use QR token, persist it, or pretend to connect. The validated `PairingPayload` is kept only in in-memory Compose state. Leaving the result clears it. Avoid logging it or saving it to saved-state storage.
- New JVM tests describe duplicate gate behavior (including contention) and parser acceptance of a canonical URI produced by the actual server generator. No Kotlin tests were executed.
- Added `androidx.lifecycle:lifecycle-runtime-compose:2.8.7` for Compose `LocalLifecycleOwner`.

## Modified existing files
- `app/src/main/java/com/ajsremote/MainActivity.kt`: route to new app UI.
- `app/build.gradle.kts`, `gradle/libs.versions.toml`: add lifecycle-runtime-compose.
- `PROJECT_TREE.txt`: regenerate file index.

Stage 1 compatibility report, Stage 2 progress/verification documents, parser, credential code, server source, and existing tests were not overwritten.

## Checks run
- `python3 tools/verify_stage3_source.py`: 5 source-structure checks passed (catalog, camera manifest permission, entry and pipeline wiring markers, atomic scan gate, test-source presence). These are not functional tests, a Kotlin compiler or a security audit.
- `AJS_SERVER_DIR=<existing server> python3 tools/verify_foundation.py`: 9 server/parser and manifest/catalog checks passed. These Python checks run the server's actual URI functions, not the Android parser.
- Generated a TLS QR URI fixture via the server's actual `build_pairing_uri` and wrote Kotlin assertions for the parsed fields and non-TLS variant. These assertions have not run.
- Verified the Stage 1 report copy still matches the original by SHA-256.

## Unverified / blockers
- No Gradle installation, Gradle wrapper scripts/JAR, Kotlin compiler, Android SDK, emulator, adb or network access in the sandbox. Dependencies cannot be fetched. Source has not compiled; dependency resolution, Compose UI, CameraX/ML Kit integration, image cleanup, torch behavior, permissions and duplicate detection remain unverified. No APK was created or installed and no physical phone was tested.
- Stage 2 build, JUnit and Android Keystore verification remains open. The new JVM tests also remain unexecuted. A source review does not replace an emulator/device test.
- QR recognition, performance, camera selection, background/foreground transitions, denied/permanently denied permissions, scanning retries, the overlay at different screen sizes, and flashlight operation must be tested on real devices. A phone with no rear camera currently gets a camera error, not a front-camera fallback.
- The QR token is single-use, and its TTL runs while the result is shown. The Stage 3 screen never consumes the token. Because Stage 4 is not implemented, the user will need to scan a fresh code when pairing becomes available.
- A no-fingerprint QR indicates unencrypted server mode. Android's current manifest blocks cleartext by default; Stage 4 must not silently fall back or disable TLS checks. Implement any explicitly allowed plain mode with an explicit warning and the necessary Android network policy.
- Parser deliberately rejects some noncanonical forms accepted by the server; Kotlin/server compatibility requires running the fixture and malformed-input tests. The test using a no-fingerprint URI removes the fingerprint from a server-generated TLS URI, rather than rendering a second physical QR.
- `QrCameraSession` waits for an in-flight ML Kit task to complete before unbinding; lifecycle or camera shutdown may still invalidate images independently. Test cancellation and lifecycle races on real hardware.

## Exact next steps before Stage 4
1. Generate and verify a trusted Gradle 8.9 wrapper; install JDK 17, Android SDK 35 and dependencies. Run `./gradlew :app:testDebugUnitTest :app:assembleDebug`, fix actual compilation/test failures, and retain logs.
2. Verify the Stage 2 Keystore/DataStore behavior on Android, and test the scanner on device: permission deny/allow/settings, QR valid/invalid/version mismatch, scan duplicate/retry, no camera/flash, torch, navigation, background/foreground, long-running analysis and cleanup. Confirm the server-generated QR fixtures in Kotlin.
3. Wire `PairingParseResult.Success.payload` from `RemoteApp` into a lifecycle-aware Stage 4 connection coordinator. Verify QR server identity and DER certificate SHA-256 pin, follow protocol v1 hello and PC-approved single-use QR pairing, securely store the returned device secret, and implement exact HMAC auth, heartbeat and reconnect. Never treat a scanned code as an authenticated connection. Never silently accept an arbitrary certificate, downgrade TLS, or add a PIN flow.
