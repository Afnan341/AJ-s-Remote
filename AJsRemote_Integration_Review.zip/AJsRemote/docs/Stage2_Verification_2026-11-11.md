# Stage 2 verification: blocked, not completed

## Status
Stage 2 is not verified. There is no complete Gradle wrapper, no Android build or APK, and no executed Android/Kotlin tests. No Stage 3 features were started. The Stage 1 report and all existing source were preserved; the existing Stage 2 progress report remains intact.

## Environment and exact blockers
- Java: OpenJDK 17.0.20.1 present.
- Gradle, Kotlin compiler, Android SDK, sdkmanager, adb, emulator: not installed; `ANDROID_HOME` and `ANDROID_SDK_ROOT` unset.
- The sandbox has no internet access, so Gradle distributions, Android SDK components, Maven plugins and libraries cannot be fetched here.
- Project contains `gradle/wrapper/gradle-wrapper.properties`, but no `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`. A properties file alone is not a functional wrapper. No trusted Gradle installation was found to generate those files. We did not create or substitute unverified wrapper binaries.
- `:app:testDebugUnitTest` and `:app:assembleDebug` could not be started because the wrapper is absent, and their dependencies and SDK are unavailable. No APK was generated. Dependency resolution and Kotlin/Compose compiler execution are not verified.

## What ran
On 2026-11-11, `AJS_SERVER_DIR=<server source directory> python3 tools/verify_foundation.py` passed all 9 checks. These are Python checks of manifest/XML and TOML structure and the actual server Python QR generator/parser (synthetic fixture values): valid TLS and non-TLS round trips; invalid token, invalid fingerprint, missing field and duplicate required field rejection. The script stubs the unavailable `qrcode` rendering dependency and does not render a QR image. It does not run, compile or exercise the Android Kotlin parser. The server GUI and full server were not started.

The project contains 37 JUnit test methods in source; **zero were executed**. There were no Android instrumented tests executed. No real Android device or Linux Mint PC was tested.

`docs/Stage1_Compatibility_Report.md` was compared byte-for-byte with the delivered report; SHA-256 for both is `b6c6423ac1dbd8c53f609b04411ea07cd564929820654f3742ce9d8fc9334134`.

## Static compatibility review, not a build
- `gradle-wrapper.properties` points to Gradle 8.9. AGP 8.7 documentation lists Gradle 8.9 and JDK 17 minimums and API 35 maximum; project config uses AGP 8.7.3, JDK 17 bytecode, compile/target API 35. Source: https://developer.android.com/build/releases/agp-8-7-0-release-notes
- Kotlin Android and Compose compiler plugins use the same `kotlin = 2.0.21` catalog version; the Compose plugin is applied to the app and `buildFeatures.compose` is true. This follows the documented Kotlin 2.0+ pattern: https://developer.android.com/develop/ui/compose/setup-compose-dependencies-and-compiler
- Repositories, plugin aliases and catalog references were inspected statically. TOML parses. Actual resolution, version conflicts, compiler compatibility, generated resources, merged manifest and all Gradle task execution remain unverified.
- The wrapper's distribution checksum is not configured. Once the wrapper is generated, compare its JAR with the official Gradle wrapper checksums, and configure the official Gradle 8.9 distribution SHA-256. See https://docs.gradle.org/current/userguide/best_practices_security.html. Do not infer or invent a checksum.

## Manifest review
XML parsed and CAMERA, INTERNET and ACCESS_NETWORK_STATE permissions exist. Application backup is disabled; launcher activity is exported and explicitly declares MAIN/LAUNCHER; camera features are optional. This is a static source-manifest check, not a merged manifest review. Runtime camera permission handling is not implemented. The manifest does not opt in to cleartext networking, so plain `ws://` mode remains unsupported until intentionally configured and clearly disclosed to the user. TLS and socket handling are not implemented.

## QR compatibility review
The Android source validates the required fields, protocol version, IPv4, port, token and optional lower-case SHA-256 fingerprint, and decodes query values. The server's generated example URIs were tested against its own parser only. The actual Kotlin parser was not executed against any server-generated payload, so client/server QR compatibility remains open. Client behavior is deliberately stricter than the server on several forms, including raw non-ASCII/whitespace, invalid UTF-8 or percent escapes, repeated unknown parameters and non-canonical decimal encodings. These differences must be reviewed and validated against server-generated cases during actual Kotlin tests.

## Credential storage review: source-level only
- Secret and server details are serialized and encrypted with AES-256-GCM and a 12-byte IV, with the key obtained from Android Keystore. Only the ciphertext is placed in Preferences DataStore. This is application-level encryption before storage, not a built-in encrypted DataStore.
- A shared mutex serializes the repository's save and clear calls; device ID generation occurs atomically within a DataStore edit. `clear` removes ciphertext but retains the key and ID. Exceptions during decryption propagate to callers. `allowBackup=false` reduces restoration of ciphertext without the device-bound key.
- Keystore behavior, persistence, tag failure, key invalidation, and concurrency have not been verified on an Android emulator or device. Hardware backing is device-dependent.
- The secret is represented in immutable Kotlin Strings and JSON, so overwriting the temporary UTF-8 byte array does not erase all in-memory copies. Callers must never log serialized credentials or QR payloads. Credential creation has no server-response validation yet; the future pairing layer must validate the device secret, server ID and fingerprint binding before saving.
- The key creation and deletion interface can be called directly outside the repository lock; the current repository does not call `deleteKey`. If future code uses the cipher directly or introduces multiple processes, revisit synchronization and key lifecycle before use. One paired server only.

## Next step, before Stage 3
On a trusted development machine with network access:
1. Install JDK 17, verified Gradle 8.9, Android SDK Platform 35 and compatible Android build tools. Point Android Studio/Gradle to the SDK.
2. From the project root run `gradle wrapper --gradle-version 8.9 --distribution-type bin`. Verify `gradlew`, `gradlew.bat` and `gradle/wrapper/gradle-wrapper.jar` against official Gradle sources/checksums; configure `distributionSha256Sum` using the official Gradle 8.9 distribution checksum. Keep wrapper JAR validation distinct from distribution ZIP checksum validation.
3. Run `./gradlew :app:testDebugUnitTest` and `./gradlew :app:assembleDebug` (Windows: `gradlew.bat ...`). Save logs and fix real errors without overwriting the report or replacing working files.
4. Generate fixture URIs with the actual server's `build_pairing_uri`, feed them to the Kotlin parser's JVM tests, and assert exact parsed values, with and without TLS and with encoded Unicode. Add invalid-token, fingerprint, duplicate-field, host and version cases. Review deliberate parsing differences.
5. Run Android instrumented tests for Keystore encrypt/decrypt, tampered ciphertext, persisted credentials across restart, missing/invalidated key and DataStore atomicity. Inspect the merged manifest. Install the debug APK on a real device and verify launch.
6. Record actual results and only proceed to Stage 3 scanner development when the agreed Stage 2 verification is successful.
