# Stage 2 progress

## Implemented in source
- Gradle Kotlin DSL configuration, version catalog, Android manifest, resources and Compose activity.
- CameraX and bundled ML Kit barcode dependencies, plus OkHttp and coroutines dependencies for later use. Their corresponding features are not wired yet.
- QR parser and model with local validation of protocol version, required fields, IPv4, port, token and optional certificate fingerprint.
- Device ID and single-server encrypted credential repository using Preferences DataStore and Android Keystore AES-GCM. Encrypted credentials and device ID are stored separately. App backup disabled.
- JVM unit-test source for QR parser, data JSON format, and AES-GCM payload serialization.
- Unchanged copy of Stage 1 report in this directory.

## Checks executed
Nine Python standard-library checks passed: XML well-formedness; version-catalog TOML parsing; manifest permissions; actual server QR generator/parser round trips with and without TLS fingerprint; server parser rejecting malformed token, fingerprint, missing field, duplicate required field. A small in-memory stub supplies the unavailable QR image-rendering module; real server URI functions run. These checks do not compile or execute Kotlin and are not Android app tests.

## Not verified / known issues
- Android SDK, Gradle, Kotlin compiler, emulator, adb and pytest are not installed; sandbox has no internet access. No Android project compilation, JUnit, instrumentation, APK install or real-phone checks were possible.
- `gradle-wrapper.properties` exists but wrapper scripts and wrapper JAR are missing. Generate them using trusted Gradle 8.9 as described in README. Until generated, this is not a complete self-contained Android Studio build setup.
- Camera dependency only: scanning, permission request, flashlight and UI are not implemented in Stage 2.
- No WebSocket, pairing, TLS pin verification, HMAC authentication, reconnection or network UI exists yet. The launch screen shows only Not connected.
- Plain WebSocket is currently blocked by Android's default cleartext policy. Supporting the server's explicitly disabled-TLS mode requires a future deliberate, user-visible opt-in and configuration, never a silent fallback.
- Keystore-backed encryption must be verified on an Android device. Storage format tests do not test Android Keystore, persistence, race handling, backups or actual pairing. Persistence is one paired server; multi-server support is not implemented.
- Parser applies defensive restrictions beyond the server's liberal parser: 16384-character maximum, strict UTF-8 and percent escapes, no raw whitespace/non-ASCII, duplicate unknown query keys rejected and canonical decimal fields only. Tests target canonical QR payloads emitted by the server; broader equivalence is not established.
- The Gradle plugin, dependencies and Kotlin source may require corrections after the first real Gradle sync/build. Dependency availability was not checked.

## Exact next stage
1. On a machine with Android SDK 35, JDK 17, Gradle 8.9 and internet, generate the missing wrapper and run `./gradlew :app:testDebugUnitTest :app:assembleDebug`. Fix any build/test failures without replacing the server or Stage 1 report.
2. On Android, add instrumentation tests for Keystore round-trip/tamper and encrypted DataStore persistence. Then build the CameraX + ML Kit scanner and runtime camera permission flow.
3. Implement the real v1 WebSocket state machine, strict certificate pinning, PC-approved QR pairing and HMAC authentication. Add reconnect/heartbeat, and test end-to-end against the existing server. Do not add gamepad controls or PIN pairing.
