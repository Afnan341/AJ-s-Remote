package com.ajsremote.authentication

import kotlinx.coroutines.sync.Mutex

/** Serializes all UI authentication sessions inside the app process; not a cross-process lock. */
internal object ConnectionLease {
    private val mutex = Mutex()
    suspend fun run(onBusy: suspend () -> Unit, block: suspend () -> Unit) {
        if (!mutex.tryLock()) { onBusy(); return }
        try { block() } finally { mutex.unlock() }
    }
}
