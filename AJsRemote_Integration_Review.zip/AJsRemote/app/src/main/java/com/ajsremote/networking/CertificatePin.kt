package com.ajsremote.networking

import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.net.ssl.X509TrustManager

/** Trust is the QR's SHA-256 of the entire DER certificate, not OkHttp's SPKI pin. */
class CertificatePin(fingerprint: String) {
    private val expected: ByteArray
    init {
        require(Regex("[0-9a-f]{64}").matches(fingerprint)) { "Invalid certificate fingerprint" }
        expected = fingerprint.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    }
    fun matches(certificate: X509Certificate): Boolean =
        MessageDigest.isEqual(expected, MessageDigest.getInstance("SHA-256").digest(certificate.encoded))

    fun verify(certificate: X509Certificate) {
        if (!matches(certificate)) throw CertificateException("Certificate fingerprint does not match the scanned QR")
        certificate.checkValidity()
        // The server generates a self-signed identity; the QR pins that exact certificate.
        try { certificate.verify(certificate.publicKey) }
        catch (e: Exception) { throw CertificateException("Invalid self-signed server certificate", e) }
    }
}

class PinnedTrustManager(private val pin: CertificatePin) : X509TrustManager {
    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        throw CertificateException("Client certificates are not trusted by this manager")
    }
    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        if (chain.isNullOrEmpty() || authType.isNullOrBlank()) throw CertificateException("Missing server certificate")
        pin.verify(chain[0])
    }
    override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
}
