package com.ajsremote.authentication

import com.ajsremote.gamepad.GamepadSession
import com.ajsremote.data.DeviceCredentialStore
import com.ajsremote.data.PairedServerCredentials
import com.ajsremote.networking.CertificatePin
import com.ajsremote.networking.HelloProtocol
import com.ajsremote.networking.PinnedTrustManager
import com.ajsremote.networking.ProtocolException
import com.ajsremote.pairing.PairingPayload
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.IOException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import kotlin.coroutines.coroutineContext

sealed interface PairingState {
    data class Connecting(val attempt: Int): PairingState
    data object WaitingForApproval: PairingState
    data object Approved: PairingState
    data object Authenticating: PairingState
    data class Connected(val name: String, val inputError: String? = null): PairingState
    data object Rejected: PairingState
    data object Expired: PairingState
    data object AuthFailed: PairingState
    data class RecoveryNeeded(val serverId: String): PairingState
    data class Failed(val message: String): PairingState
}

private sealed interface SocketEvent {
    data object Open: SocketEvent
    data class Text(val text: String): SocketEvent
    data class Failure(val cause: Throwable): SocketEvent
    data object Closed: SocketEvent
}
private class PairingStopped(val result: PairingState): Exception()

/** Pairing is never attempted over plaintext: pair_accepted contains the long-term secret. */
class PairingClient(private val store: DeviceCredentialStore, private val scanned: PairingPayload?, private val gamepad: GamepadSession? = null) {
    suspend fun run(update: suspend (PairingState) -> Unit) {
        ConnectionLease.run(
            onBusy = { update(PairingState.Failed("Another connection is still closing. Try again.")) },
            block = { runExclusive(update) },
        )
    }

    private suspend fun runExclusive(update: suspend (PairingState) -> Unit) = withContext(Dispatchers.IO) {
        var tokenSubmitted = false
        var pairingSaved = false
        val id = store.deviceId()
        val pending = store.pendingPairing()
        if (pending != null) {
            update(PairingState.RecoveryNeeded(pending))
            return@withContext
        }
        for (attempt in 1..3) {
            try {
                val saved = store.credentials.first()
                if (scanned != null && saved != null && saved.serverId != scanned.serverId) {
                    throw PairingStopped(PairingState.Failed("Another PC is already saved. The app currently stores one PC; remove the existing pairing before adding another."))
                }
                val host = scanned?.host ?: saved?.host ?: throw PairingStopped(PairingState.Failed("No saved PC. Scan a pairing code."))
                val port = scanned?.port ?: saved?.port ?: throw PairingStopped(PairingState.Failed("No saved PC."))
                val sid = scanned?.serverId ?: saved?.serverId ?: throw PairingStopped(PairingState.Failed("No saved PC."))
                val pin = scanned?.fingerprint ?: if (scanned == null) saved?.fingerprint else null
                if (pin == null) throw PairingStopped(PairingState.Failed("Pairing requires encrypted TLS. Enable TLS on the PC and scan a new QR code."))
                if (saved != null && (saved.deviceId != id || saved.fingerprint != pin)) {
                    throw PairingStopped(PairingState.Failed("Saved identity or certificate changed. Verify the PC and re-pair; no credentials were sent."))
                }
                if (tokenSubmitted && saved == null) throw PairingStopped(PairingState.Failed("Pairing outcome is uncertain. Check the PC, then scan a new QR code."))
                update(PairingState.Connecting(attempt))
                session(host, port, sid, pin, id, saved, update, { tokenSubmitted = true }, { pairingSaved = true })
                return@withContext
            } catch (e: PairingStopped) {
                if (tokenSubmitted && !pairingSaved && (e.result == PairingState.Rejected || e.result == PairingState.Expired)) {
                    // These are definitive responses for this pairing request.
                    withContext(NonCancellable) { scanned?.serverId?.let { store.clearPendingPairing(it) } }
                }
                update(e.result); return@withContext
            }
            catch (e: TimeoutCancellationException) {
                if (tokenSubmitted && !pairingSaved) { update(PairingState.RecoveryNeeded(requireNotNull(scanned).serverId)); return@withContext }
                if (attempt == 3) { update(PairingState.Failed("Connection timed out.")); return@withContext }
                update(PairingState.Connecting(attempt + 1))
                delay((1L shl (attempt - 1)) * 1000)
            } catch (e: CancellationException) { throw e }
            catch (e: ProtocolException) {
                if (tokenSubmitted && !pairingSaved) update(PairingState.RecoveryNeeded(requireNotNull(scanned).serverId))
                else update(PairingState.Failed(e.message ?: "Invalid server response"))
                return@withContext
            }
            catch (e: SSLException) { update(PairingState.Failed("Certificate verification failed. Verify the PC and scan a new QR code.")); return@withContext }
            catch (e: Exception) {
                if (tokenSubmitted && !pairingSaved) { update(PairingState.RecoveryNeeded(requireNotNull(scanned).serverId)); return@withContext }
                if (attempt == 3) { update(PairingState.Failed("Connection lost. Check the PC and network.")); return@withContext }
                update(PairingState.Connecting(attempt + 1))
                delay((1L shl (attempt - 1)) * 1000)
            }
        }
    }

    private suspend fun session(host: String, port: Int, serverId: String, fingerprint: String, deviceId: String,
        saved: PairedServerCredentials?, update: suspend (PairingState) -> Unit, onSubmitted: () -> Unit, onSaved: () -> Unit) {
        val client = pinnedClient(host, fingerprint)
        val events = Channel<SocketEvent>(32)
        var socket: WebSocket? = null
        try {
            val listener = object: WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) { events.trySend(SocketEvent.Open) }
                override fun onMessage(webSocket: WebSocket, text: String) { if (events.trySend(SocketEvent.Text(text)).isFailure) webSocket.cancel() }
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) { webSocket.cancel(); events.trySend(SocketEvent.Failure(ProtocolException("Binary server message"))) }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { events.trySend(SocketEvent.Failure(t)) }
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) { webSocket.close(code, null); events.trySend(SocketEvent.Closed) }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { events.trySend(SocketEvent.Closed) }
            }
            val ws = client.newWebSocket(Request.Builder().url("wss://$host:$port/").build(), listener)
            socket = ws
            val first = withTimeout(10000) { events.receive() }
            if (first !is SocketEvent.Open) throwEvent(first)
            if (!ws.send(HelloProtocol.hello(deviceId))) throw IOException("Unable to send hello")
            val ackText = receiveText(events, 10000)
            checkError(ackText)
            val ack = HelloProtocol.helloAck(ackText, serverId)
            var credentials = saved
            if (credentials != null && !ack.paired) throw PairingStopped(PairingState.Failed("PC no longer recognizes this device. Remove the saved pairing, then scan a fresh QR."))
            if (credentials == null && ack.paired) {
                // Server knows this device, but this phone has no secret. No remote revoke exists.
                withContext(NonCancellable) { store.beginPairing(serverId) }
                throw PairingStopped(PairingState.RecoveryNeeded(serverId))
            }
            if (credentials == null) {
                val token = scanned?.token ?: throw PairingStopped(PairingState.Failed("Scan a new pairing code."))
                // Durable marker precedes the wire send, including cancellation/process death.
                withContext(NonCancellable) { store.beginPairing(serverId) }
                onSubmitted()
                if (!ws.send(PairingProtocol.pairRequest(token))) throw IOException("Cannot send pairing request")
                val pending = receiveText(events, 10000)
                checkError(pending, PairingProtocol.PAIR_ID)
                val timeout = PairingProtocol.approvalTimeout(pending)
                update(PairingState.WaitingForApproval)
                val response = receiveText(events, (timeout + 5L) * 1000)
                checkError(response, PairingProtocol.PAIR_ID)
                when (HelloProtocol.type(response)) {
                    "pair_rejected" -> { PairingProtocol.payload(response, "pair_rejected", PairingProtocol.PAIR_ID); throw PairingStopped(PairingState.Rejected) }
                    "pair_accepted" -> Unit
                    else -> throw ProtocolException("Unexpected pairing response")
                }
                val secret = PairingProtocol.secret(response)
                val newCredentials = PairedServerCredentials(serverId, ack.serverName, host, port, fingerprint, deviceId, secret)
                // Server returns the secret only once. Complete a started save even if UI is cancelled.
                withContext(NonCancellable) { store.completePairing(newCredentials) }
                credentials = newCredentials
                onSaved()
                update(PairingState.Approved)
            }
            val secret = credentials.deviceSecret
            if (!ChallengeReplayGuard.claim(serverId, deviceId, ack.challenge)) throw ProtocolException("Repeated challenge or replay guard full. Verify the PC and restart the app.")
            update(PairingState.Authenticating)
            if (!ws.send(PairingProtocol.auth(AuthenticationProof.calculate(secret, ack.challenge, deviceId)))) throw IOException("Unable to send authentication")
            val auth = receiveText(events, 10000)
            checkError(auth, PairingProtocol.AUTH_ID)
            val interval = PairingProtocol.heartbeat(auth)
            // A newly scanned IP is persisted only after pin verification and authenticated success.
            if (saved != null && (saved.host != host || saved.port != port || saved.serverName != ack.serverName)) {
                withContext(NonCancellable) { store.save(saved.copy(host = host, port = port, serverName = ack.serverName)) }
            }
            gamepad?.attach(ws)
            update(PairingState.Connected(ack.serverName))
            while (coroutineContext.isActive) {
                val event = withTimeoutOrNull(interval * 1000L) { events.receive() }
                if (event != null) {
                    val text = eventText(event)
                    if (HelloProtocol.type(text) == "error" && HelloProtocol.errorCode(text) == "input_disabled") {
                        gamepad?.detach(ws)
                        update(PairingState.Connected(ack.serverName, "Gamepad unavailable. Enable gamepad input on the PC, then reconnect."))
                    } else {
                        checkError(text)
                        if (HelloProtocol.type(text) != "pong") throw ProtocolException("Unexpected server response")
                    }
                } else {
                    if (!ws.send(HelloProtocol.ping())) throw IOException("Unable to send heartbeat")
                    withTimeout(15000) {
                        while (true) {
                            val pong = eventText(events.receive())
                            if (HelloProtocol.type(pong) == "error" && HelloProtocol.errorCode(pong) == "input_disabled") {
                                gamepad?.detach(ws)
                        update(PairingState.Connected(ack.serverName, "Gamepad unavailable. Enable gamepad input on the PC, then reconnect."))
                                continue
                            }
                            checkError(pong)
                            if (HelloProtocol.type(pong) != "pong") throw ProtocolException("Heartbeat response invalid")
                            break
                        }
                    }
                }
            }
        } finally {
            socket?.let { gamepad?.detach(it) }
            socket?.send(HelloProtocol.bye())
            socket?.close(1000, "Client disconnect")
            // Force release on cancellation and unresponsive peers; bye delivery is best-effort.
            socket?.cancel()
            events.close()
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        }
    }
    private suspend fun receiveText(events: Channel<SocketEvent>, ms: Long): String = eventText(withTimeout(ms) { events.receive() })
    private fun eventText(event: SocketEvent): String = if (event is SocketEvent.Text) event.text else throwEvent(event)
    private fun throwEvent(event: SocketEvent): Nothing = when (event) {
        is SocketEvent.Failure -> {
            val tls = generateSequence(event.cause) { it.cause }.firstOrNull { it is SSLException }
            if (tls is SSLException) throw tls
            if (event.cause is ProtocolException) throw event.cause
            throw IOException("WebSocket failed", event.cause)
        }
        else -> throw IOException("WebSocket closed")
    }
    private fun checkError(text: String, expectedReply: String? = null) {
        when (HelloProtocol.type(text)) {
            "error" -> {
                val code = HelloProtocol.errorCode(text)
                val expectedForCode = when (code) {
                    "pairing_token_invalid" -> PairingProtocol.PAIR_ID
                    "authentication_failed" -> PairingProtocol.AUTH_ID
                    else -> null
                }
                if (expectedForCode != null && expectedReply == expectedForCode) {
                    PairingProtocol.payload(text, "error", expectedForCode)
                    throw PairingStopped(pairingErrorState(code))
                }
                throw ProtocolException("Server rejected the request or sent an unexpected error.")
            }
            "bye" -> throw PairingStopped(PairingState.Failed("PC ended the connection."))
        }
    }
    private fun pinnedClient(host: String, fingerprint: String): OkHttpClient {
        val pin = CertificatePin(fingerprint)
        val trust = PinnedTrustManager(pin)
        val context = SSLContext.getInstance("TLS")
        context.init(null, arrayOf(trust), null)
        return OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(0, TimeUnit.SECONDS)
            .retryOnConnectionFailure(false).sslSocketFactory(context.socketFactory, trust)
            .hostnameVerifier { actual, session -> actual == host && try {
                val leaf = session.peerCertificates.firstOrNull() as? X509Certificate
                leaf != null && pin.matches(leaf)
            } catch (_: Exception) { false } }.build()
    }
}

/** Mapping from documented fatal server codes to visible state; no server message is treated as success. */
internal fun pairingErrorState(code: String): PairingState = when (code) {
    "pairing_token_invalid" -> PairingState.Expired
    "authentication_failed" -> PairingState.AuthFailed
    else -> PairingState.Failed("Server rejected the request.")
}
