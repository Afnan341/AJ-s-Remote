package com.ajsremote.authentication

import java.security.MessageDigest
import java.util.Base64
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/** Server v1: SHA256(decoded secret), then HMAC over the literal challenge text + ':' + device ID. */
object AuthenticationProof {
    private val base64url = Regex("[A-Za-z0-9_-]{43}")
    fun calculate(secret: String, challenge: String, deviceId: String): String {
        require(base64url.matches(secret) && base64url.matches(challenge))
        require(Regex("[A-Za-z0-9_-]{16,64}").matches(deviceId))
        val secretBytes = Base64.getUrlDecoder().decode(secret)
        val key = try {
            require(secretBytes.size == 32 && Base64.getUrlDecoder().decode(challenge).size == 32)
            MessageDigest.getInstance("SHA-256").digest(secretBytes)
        } finally { secretBytes.fill(0) }
        return try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(SecretKeySpec(key, "HmacSHA256"))
            Base64.getUrlEncoder().withoutPadding().encodeToString(mac.doFinal("$challenge:$deviceId".toByteArray(Charsets.UTF_8)))
        } finally { key.fill(0) }
    }
}

/** Process-local defense in depth. On capacity exhaustion fail closed rather than evict old challenges. */
object ChallengeReplayGuard {
    private const val MAX_ENTRIES = 4096
    private val used = mutableSetOf<Triple<String, String, String>>()
    @Synchronized fun claim(serverId: String, deviceId: String, challenge: String): Boolean {
        if (used.size >= MAX_ENTRIES) return false
        return used.add(Triple(serverId, deviceId, challenge))
    }
}
