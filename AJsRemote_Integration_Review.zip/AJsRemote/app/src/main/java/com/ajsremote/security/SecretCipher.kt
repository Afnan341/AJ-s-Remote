package com.ajsremote.security

/**
 * Encrypts and decrypts small secrets at rest. The only production implementation is
 * [KeystoreSecretCipher], which keeps its key inside the Android Keystore (hardware-backed where available).
 * Plaintext never leaves this layer unencrypted.
 */
interface SecretCipher {
    /** Returns an opaque, self-describing string that contains the IV and ciphertext. */
    fun encrypt(plaintext: ByteArray): String

    /** Throws if the payload is malformed, the key is missing, or authentication fails. */
    fun decrypt(payload: String): ByteArray

    /** Destroys the key. Anything encrypted with it becomes unreadable. */
    fun deleteKey()
}
