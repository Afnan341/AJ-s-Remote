package com.ajsremote.ui

import androidx.camera.view.PreviewView
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ajsremote.scanner.QrCameraSession
import com.ajsremote.ui.theme.AjsBackground
import com.ajsremote.ui.theme.AjsRed
import com.ajsremote.ui.theme.AjsTextSecondary

@Composable
fun ScannerScreen(onBack: () -> Unit, onFailure: (String) -> Unit, onCode: (String) -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latestOnCode by rememberUpdatedState(onCode)
    val latestOnFailure by rememberUpdatedState(onFailure)
    val preview = remember(context) {
        PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
    }
    var session by remember { mutableStateOf<QrCameraSession?>(null) }
    var ready by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }
    var torchOn by remember { mutableStateOf(false) }

    DisposableEffect(preview, owner) {
        val camera = QrCameraSession(
            context = context,
            lifecycleOwner = owner,
            previewView = preview,
            onDecoded = { latestOnCode(it) },
            onCameraReady = { flash -> ready = true; hasFlash = flash },
            onError = { latestOnFailure(it) },
            onTorchChanged = { torchOn = it },
        )
        session = camera
        camera.start()
        onDispose { camera.close(); session = null }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(AjsBackground).padding(horizontal = 24.dp, vertical = 32.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("SCAN TO CONNECT", style = MaterialTheme.typography.labelLarge, color = AjsRed)
            Text("Find your PC", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Point your camera at the pairing QR code on AJ's Remote Server.",
                style = MaterialTheme.typography.bodyLarge, color = AjsTextSecondary,
                textAlign = TextAlign.Center)
        }
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(26.dp))
                .background(Color(0xFF151515)),
            contentAlignment = Alignment.Center,
        ) {
            AndroidView(factory = { preview }, modifier = Modifier.fillMaxSize())
            ScanningOverlay(Modifier.fillMaxSize())
            if (!ready) Text("Starting camera…", color = Color.White,
                modifier = Modifier.background(AjsBackground.copy(alpha = .8f), RoundedCornerShape(8.dp)).padding(12.dp))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Keep the code inside the frame", color = AjsTextSecondary,
                style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onBack) { Text("Back") }
                Button(onClick = { session?.toggleTorch() }, enabled = ready && hasFlash) {
                    Text(if (!hasFlash && ready) "No flashlight" else if (torchOn) "Flashlight on" else "Flashlight off")
                }
            }
        }
    }
}

@Composable
private fun ScanningOverlay(modifier: Modifier) {
    val animation = rememberInfiniteTransition(label = "scan line")
    val position by animation.animateFloat(
        initialValue = .12f, targetValue = .88f,
        animationSpec = infiniteRepeatable(tween(2100), RepeatMode.Reverse),
        label = "scan position",
    )
    Canvas(modifier) {
        val inset = size.width * .06f
        val width = size.width - 2 * inset
        val height = size.height - 2 * inset
        drawRoundRect(color = AjsRed.copy(alpha = .28f), topLeft = Offset(inset, inset),
            size = androidx.compose.ui.geometry.Size(width, height),
            cornerRadius = CornerRadius(28.dp.toPx()), style = Stroke(width = 7.dp.toPx()))
        drawRoundRect(color = AjsRed, topLeft = Offset(inset, inset),
            size = androidx.compose.ui.geometry.Size(width, height),
            cornerRadius = CornerRadius(28.dp.toPx()), style = Stroke(width = 2.dp.toPx()))
        val y = size.height * position
        drawLine(AjsRed.copy(alpha = .24f), Offset(inset + 12.dp.toPx(), y),
            Offset(size.width - inset - 12.dp.toPx(), y), strokeWidth = 8.dp.toPx())
        drawLine(AjsRed, Offset(inset + 12.dp.toPx(), y),
            Offset(size.width - inset - 12.dp.toPx(), y), strokeWidth = 2.dp.toPx())
    }
}
