package com.ajsremote.data

import org.json.JSONObject

/**
 * What the app keeps after a successful pairing. [deviceSecret] is the base64url value from
 * `pair_accepted`; it is shown to the app exactly once, so it must be persisted encrypted.
 */
data class PairedServerCredentials(
    val serverId: String,
    val serverName: String,
    val host: String,
    val port: Int,
    /** Lowercase hex SHA-256 of the server certificate. Null means plain ws:// (no TLS). */
    val fingerprint: String?,
    val deviceId: String,
    val deviceSecret: String,
) {
    /** The secret must never appear in logs or debug output. */
    override fun toString(): String =
        "PairedServerCredentials(serverName=$serverName, host=$host, port=$port, " +
            "fingerprint=${fingerprint ?: "none"}, deviceId=$deviceId, deviceSecret=***)"

    fun toJson(): String = JSONObject()
        .put("serverId", serverId)
        .put("serverName", serverName)
        .put("host", host)
        .put("port", port)
        .put("fingerprint", fingerprint ?: JSONObject.NULL)
        .put("deviceId", deviceId)
        .put("deviceSecret", deviceSecret)
        .toString()

    companion object {
        fun fromJson(json: String): PairedServerCredentials {
            val obj = JSONObject(json)
            return PairedServerCredentials(
                serverId = obj.getString("serverId"),
                serverName = obj.getString("serverName"),
                host = obj.getString("host"),
                port = obj.getInt("port"),
                fingerprint = if (obj.isNull("fingerprint")) null else obj.getString("fingerprint"),
                deviceId = obj.getString("deviceId"),
                deviceSecret = obj.getString("deviceSecret"),
            )
        }
    }
}
