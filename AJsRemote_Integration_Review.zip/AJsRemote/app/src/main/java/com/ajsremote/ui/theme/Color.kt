package com.ajsremote.ui.theme

import androidx.compose.ui.graphics.Color

val AjsBackground = Color(0xFF050505)
val AjsCharcoal = Color(0xFF151515)
val AjsRed = Color(0xFFFF2020)
val AjsTextPrimary = Color(0xFFFFFFFF)
val AjsTextSecondary = Color(0xFFB3B3B3)
