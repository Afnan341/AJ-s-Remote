package com.ajsremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ajsremote.gamepad.GamepadSession
import com.ajsremote.gamepad.ControllerScreen
import com.ajsremote.authentication.PairingClient
import com.ajsremote.authentication.PairingState
import com.ajsremote.data.DeviceCredentialStore
import com.ajsremote.pairing.PairingPayload
import com.ajsremote.ui.theme.AjsBackground
import com.ajsremote.ui.theme.AjsTextSecondary
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ConnectionScreen(payload: PairingPayload?, onBack: () -> Unit) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var attempt by remember { mutableIntStateOf(0) }
    var confirmForget by remember { mutableStateOf(false) }
    var confirmRecovery by remember { mutableStateOf(false) }
    var state by remember { mutableStateOf<PairingState>(PairingState.Connecting(1)) }
    val store = remember(context) { DeviceCredentialStore(context) }
    val gamepad = remember { GamepadSession() }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_STOP) onBack() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(payload, attempt) {
        try {
            PairingClient(store, payload, gamepad).run { next -> withContext(Dispatchers.Main.immediate) { state = next } }
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { state = PairingState.Failed("Unable to access saved credentials. Check device storage and try again.") }
    }
    val connected = state as? PairingState.Connected
    if (connected != null) {
        ControllerScreen(gamepad, connected.name, connected.inputError, onBack)
        return
    }
    if (confirmForget) AlertDialog(
        onDismissRequest = { confirmForget = false },
        title = { Text("Forget saved PC?") },
        text = { Text("This removes the credentials from this phone. It does not remove the device from the PC.") },
        confirmButton = { TextButton(onClick = {
            confirmForget = false
            scope.launch {
                try { store.clear(); onBack() }
                catch (_: Exception) { state = PairingState.Failed("Couldn't remove saved credentials.") }
            }
        }) { Text("Forget") } },
        dismissButton = { TextButton(onClick = { confirmForget = false }) { Text("Cancel") } },
    )
    if (confirmRecovery && state is PairingState.RecoveryNeeded) {
        val recovery = state as PairingState.RecoveryNeeded
        AlertDialog(
            onDismissRequest = { confirmRecovery = false },
            title = { Text("PC recovery checked?") },
            text = { Text("On the PC, dismiss or deny any outstanding approval prompt, then remove AJ's Remote Android from Devices if present. Only continue after the prompt is resolved and removal is complete. This app cannot verify or perform PC-side removal.") },
            confirmButton = { TextButton(onClick = {
                confirmRecovery = false
                scope.launch {
                    try { store.clearPendingPairing(recovery.serverId); onBack() }
                    catch (_: Exception) { state = PairingState.Failed("Couldn't clear the local recovery marker. Try again.") }
                }
            }) { Text("I checked the PC") } },
            dismissButton = { TextButton(onClick = { confirmRecovery = false }) { Text("Not yet") } },
        )
    }
    Box(Modifier.fillMaxSize().background(AjsBackground).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(20.dp)) {
            val current = state
            val text = when (current) {
                is PairingState.Connecting -> "Connecting (attempt ${current.attempt})"
                PairingState.WaitingForApproval -> "Waiting for PC approval. Approve this phone on your PC."
                PairingState.Approved -> "Pairing approved. Credentials saved."
                PairingState.Authenticating -> "Authenticating"
                is PairingState.Connected -> "Connected to ${current.name}"
                PairingState.Rejected -> "Pairing was denied or approval timed out. Scan a new QR code."
                PairingState.Expired -> "Pairing code invalid or expired. Scan a new code."
                PairingState.AuthFailed -> "Authentication failed. Verify the PC and re-pair if the device was removed."
                is PairingState.RecoveryNeeded -> "Pairing may be incomplete. Check the PC before starting over."
                is PairingState.Failed -> current.message
            }
            if (current is PairingState.Connecting || current is PairingState.WaitingForApproval || current is PairingState.Authenticating) CircularProgressIndicator()
            Text(text, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
            if (current is PairingState.RecoveryNeeded) {
                Text("Resolve any approval prompt on the PC, then remove this phone from Devices if it appears. The phone cannot verify removal.", color = AjsTextSecondary, textAlign = TextAlign.Center)
                Button(onClick = { confirmRecovery = true }) { Text("Review recovery steps") }
            }
            if (current is PairingState.Connected) Text("Authenticated", color = AjsTextSecondary)
            if (current is PairingState.Failed || current is PairingState.AuthFailed) {
                if (payload == null) Button(onClick = { attempt++ }) { Text("Retry saved connection") }
                OutlinedButton(onClick = { confirmForget = true }) { Text("Forget saved PC") }
            }
            OutlinedButton(onClick = onBack) {
                Text(if (current is PairingState.WaitingForApproval) "Cancel and disconnect" else "Disconnect")
            }
            if (current is PairingState.WaitingForApproval) Text(
                "Cancelling closes the phone connection. The PC may still need you to dismiss its approval prompt.",
                color = AjsTextSecondary, textAlign = TextAlign.Center)
        }
    }
}
