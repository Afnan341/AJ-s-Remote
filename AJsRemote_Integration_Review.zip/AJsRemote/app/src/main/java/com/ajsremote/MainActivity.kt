package com.ajsremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ajsremote.ui.RemoteApp
import com.ajsremote.ui.theme.AjsRemoteTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AjsRemoteTheme {
                RemoteApp()
            }
        }
    }
}
