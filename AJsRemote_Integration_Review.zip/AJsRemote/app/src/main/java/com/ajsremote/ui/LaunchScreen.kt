package com.ajsremote.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ajsremote.ui.theme.AjsBackground
import com.ajsremote.ui.theme.AjsTextPrimary
import com.ajsremote.ui.theme.AjsTextSecondary

/** Launch screen. Connection flow (scanner, pairing, status) is added in later stages. */
@Composable
fun LaunchScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AjsBackground),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text(
                text = "AJ's Remote",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = AjsTextPrimary,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Not connected",
                style = MaterialTheme.typography.bodyLarge,
                color = AjsTextSecondary,
            )
        }
    }
}
