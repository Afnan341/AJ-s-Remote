package com.ajsremote.gamepad

import org.json.JSONObject

/** Protocol v1 messages, validated before reaching the server. */
object GamepadProtocol {
    private val buttons = setOf("a", "b", "x", "y", "lb", "rb", "back", "start", "guide", "ls", "rs")
    private val sticks = setOf("left_x", "left_y", "right_x", "right_y")
    private val triggers = setOf("lt", "rt")
    private val dpad = setOf("dpad_x", "dpad_y")
    fun button(name: String, pressed: Boolean): String {
        require(name in buttons)
        return envelope("gamepad_button", JSONObject().put("button", name).put("action", if (pressed) "down" else "up"))
    }
    fun axis(name: String, value: Float): String {
        require(value.isFinite())
        require(when (name) {
            in sticks -> value in -1f..1f
            in triggers -> value in 0f..1f
            in dpad -> value == -1f || value == 0f || value == 1f
            else -> false
        })
        return envelope("gamepad_axis", JSONObject().put("axis", name).put("value", value.toDouble()))
    }
    private fun envelope(type: String, payload: JSONObject): String =
        JSONObject().put("v", 1).put("type", type).put("payload", payload).toString()
}
