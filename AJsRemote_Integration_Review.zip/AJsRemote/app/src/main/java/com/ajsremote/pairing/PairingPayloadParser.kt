package com.ajsremote.pairing

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/**
 * Strict parser for the pairing URI that AJS Remote Server renders as a QR code.
 *
 * Source of truth: server ajs_server/qr/generator.py (parse_pairing_uri) and docs/PROTOCOL.md section 5.
 *
 *   ajsremote://pair?v=1&sid=<server_id>&host=<ipv4>&port=<port>&token=<token>&name=<name>[&fp=<sha256-hex>]
 *
 * Unknown parameters are ignored. Duplicate keys, malformed percent encoding and invalid UTF-8
 * are rejected to avoid ambiguous input. Parsing never touches the network.
 */
object PairingPayloadParser {

    internal const val SCHEME = "ajsremote"
    internal const val AUTHORITY = "pair"
    internal const val SUPPORTED_VERSION = 1
    // Defensive size limit, larger than the capacity of a physical QR code.
    internal const val MAX_RAW_LENGTH = 16384
    internal const val MAX_QUERY_FIELDS = 9
    internal const val MAX_SERVER_NAME_LENGTH = 64
    internal const val MIN_PORT = 1024
    internal const val MAX_PORT = 65535

    private val VERSION_PATTERN = Regex("[0-9]{1,3}")
    private val PORT_PATTERN = Regex("[0-9]{1,5}")
    private val OCTET_PATTERN = Regex("0|[1-9][0-9]{0,2}")
    private val TOKEN_PATTERN = Regex("[A-Za-z0-9_-]{16,128}")
    private val FINGERPRINT_PATTERN = Regex("[0-9a-f]{64}")
    private val REQUIRED_KEYS = listOf("v", "sid", "host", "port", "token", "name")

    fun parse(raw: String): PairingParseResult = try {
        PairingParseResult.Success(parseOrThrow(raw))
    } catch (failure: PairingParseFailure) {
        PairingParseResult.Failure(failure.error, failure.field)
    }

    private fun parseOrThrow(raw: String): PairingPayload {
        val prefix = "$SCHEME://$AUTHORITY"
        if (!raw.startsWith(prefix)) fail(PairingError.NOT_PAIRING_CODE)
        val afterPrefix = raw.substring(prefix.length)
        if (!afterPrefix.startsWith("?")) fail(PairingError.NOT_PAIRING_CODE)

        if (raw.length > MAX_RAW_LENGTH) fail(PairingError.MALFORMED_PAYLOAD)
        // A URI is ASCII only: no spaces, no control characters, no raw non-ASCII.
        if (raw.any { it.code < 0x21 || it.code > 0x7e }) fail(PairingError.MALFORMED_PAYLOAD)

        val query = afterPrefix.substring(1)
        if (query.isEmpty() || query.contains('#')) fail(PairingError.MALFORMED_PAYLOAD)

        val pairs = query.split('&')
        if (pairs.size > MAX_QUERY_FIELDS) fail(PairingError.MALFORMED_PAYLOAD)

        val values = LinkedHashMap<String, String>()
        for (pair in pairs) {
            val separator = pair.indexOf('=')
            if (separator <= 0) fail(PairingError.MALFORMED_PAYLOAD)
            val key = decodeValue(pair.substring(0, separator)) ?: fail(PairingError.MALFORMED_PAYLOAD)
            val rawValue = pair.substring(separator + 1)
            if (rawValue.isEmpty()) fail(PairingError.MALFORMED_PAYLOAD, key)
            if (values.containsKey(key)) fail(PairingError.DUPLICATE_PARAMETER, key)
            values[key] = decodeValue(rawValue) ?: fail(PairingError.MALFORMED_PAYLOAD, key)
        }

        for (key in REQUIRED_KEYS) {
            if (!values.containsKey(key)) fail(PairingError.MISSING_PARAMETER, key)
        }

        val version = values.getValue("v")
        if (!VERSION_PATTERN.matches(version) || version.toInt() != SUPPORTED_VERSION) {
            fail(PairingError.UNSUPPORTED_VERSION, "v")
        }

        val serverId = values.getValue("sid")
        if (serverId.isEmpty()) fail(PairingError.INVALID_SERVER_ID, "sid")

        val host = values.getValue("host")
        if (!isIpv4(host)) fail(PairingError.INVALID_HOST, "host")

        val portText = values.getValue("port")
        if (!PORT_PATTERN.matches(portText)) fail(PairingError.INVALID_PORT, "port")
        val port = portText.toInt()
        if (port !in MIN_PORT..MAX_PORT) fail(PairingError.INVALID_PORT, "port")

        val token = values.getValue("token")
        if (!TOKEN_PATTERN.matches(token)) fail(PairingError.INVALID_TOKEN, "token")

        val name = values.getValue("name")
        val nameIsValid = name.isNotEmpty() &&
            name.codePointCount(0, name.length) <= MAX_SERVER_NAME_LENGTH
        if (!nameIsValid) fail(PairingError.INVALID_SERVER_NAME, "name")

        val fingerprint = values["fp"]
        if (fingerprint != null && !FINGERPRINT_PATTERN.matches(fingerprint)) {
            fail(PairingError.INVALID_FINGERPRINT, "fp")
        }

        return PairingPayload(
            version = SUPPORTED_VERSION,
            serverId = serverId,
            host = host,
            port = port,
            token = token,
            serverName = name,
            fingerprint = fingerprint,
        )
    }

    private fun isIpv4(candidate: String): Boolean {
        val octets = candidate.split('.')
        return octets.size == 4 && octets.all { octet ->
            OCTET_PATTERN.matches(octet) && octet.toInt() <= 255
        }
    }

    /** Percent-decodes one query value (with '+' as space, like the server's parse_qs). Null if invalid. */
    private fun decodeValue(raw: String): String? {
        val bytes = ByteArrayOutputStream(raw.length)
        var index = 0
        while (index < raw.length) {
            val c = raw[index]
            when {
                c == '+' -> {
                    bytes.write(' '.code)
                    index++
                }
                c == '%' -> {
                    if (index + 2 >= raw.length) return null
                    val high = Character.digit(raw[index + 1], 16)
                    val low = Character.digit(raw[index + 2], 16)
                    if (high < 0 || low < 0) return null
                    bytes.write(high * 16 + low)
                    index += 3
                }
                c.code in 0x21..0x7e -> {
                    bytes.write(c.code)
                    index++
                }
                else -> return null
            }
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes.toByteArray()))
                .toString()
        } catch (e: CharacterCodingException) {
            null
        }
    }

    private fun fail(error: PairingError, field: String? = null): Nothing =
        throw PairingParseFailure(error, field)

    private class PairingParseFailure(val error: PairingError, val field: String?) :
        RuntimeException(error.name, null, false, false)
}
