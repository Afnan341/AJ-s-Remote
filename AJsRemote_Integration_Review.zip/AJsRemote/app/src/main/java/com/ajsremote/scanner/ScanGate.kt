package com.ajsremote.scanner

import java.util.concurrent.atomic.AtomicBoolean

/** One decoded value per scanning session, including when analysis callbacks race. */
class ScanGate {
    private val claimed = AtomicBoolean(false)
    fun tryClaim(): Boolean = claimed.compareAndSet(false, true)
}
