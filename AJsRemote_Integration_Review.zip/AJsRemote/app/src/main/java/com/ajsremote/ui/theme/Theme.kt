package com.ajsremote.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val AjsColorScheme = darkColorScheme(
    primary = AjsRed,
    onPrimary = AjsTextPrimary,
    background = AjsBackground,
    onBackground = AjsTextPrimary,
    surface = AjsCharcoal,
    onSurface = AjsTextPrimary,
    onSurfaceVariant = AjsTextSecondary,
)

@Composable
fun AjsRemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AjsColorScheme, content = content)
}
