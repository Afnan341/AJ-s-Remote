package com.ajsremote.authentication

import com.ajsremote.networking.HelloProtocol
import com.ajsremote.networking.ProtocolException
import org.json.JSONObject
import java.util.Base64

object PairingProtocol {
    const val PAIR_ID = "pair-1"
    const val AUTH_ID = "auth-1"
    private fun envelope(type: String, id: String, payload: JSONObject): String =
        JSONObject().put("v", 1).put("type", type).put("id", id).put("payload", payload).toString()
    fun pairRequest(token: String): String {
        require(Regex("[A-Za-z0-9_-]{16,128}").matches(token))
        return envelope("pair_request", PAIR_ID, JSONObject().put("pairing_token", token))
    }
    fun auth(proof: String): String {
        require(Regex("[A-Za-z0-9_-]{43}").matches(proof))
        return envelope("auth", AUTH_ID, JSONObject().put("proof", proof))
    }
    fun payload(text: String, expectedType: String, expectedReply: String): JSONObject {
        if (HelloProtocol.type(text) != expectedType) throw ProtocolException("Unexpected server response")
        val root = JSONObject(text)
        if (root.opt("re") != expectedReply) throw ProtocolException("Server response ID mismatch")
        return root.getJSONObject("payload")
    }
    fun secret(text: String): String {
        val p = payload(text, "pair_accepted", PAIR_ID)
        val secret = p.opt("device_secret") as? String ?: throw ProtocolException("Missing device secret")
        if (!Regex("[A-Za-z0-9_-]{43}").matches(secret)) throw ProtocolException("Invalid device secret")
        try { if (Base64.getUrlDecoder().decode(secret).size != 32) throw ProtocolException("Invalid device secret") }
        catch (e: IllegalArgumentException) { throw ProtocolException("Invalid device secret") }
        return secret
    }
    fun approvalTimeout(text: String): Int {
        val p = payload(text, "pair_pending", PAIR_ID)
        val value = p.opt("timeout_seconds")
        if (value !is Number || value.toLong() !in 1..600 || value.toDouble() != value.toLong().toDouble()) throw ProtocolException("Invalid approval timeout")
        return value.toInt()
    }
    fun heartbeat(text: String): Int {
        val p = payload(text, "auth_ok", AUTH_ID)
        val id = p.opt("session_id") as? String ?: throw ProtocolException("Missing session ID")
        val seconds = p.opt("heartbeat_interval_seconds")
        if (id.isEmpty() || seconds !is Number || seconds.toLong() !in 1..300 || seconds.toDouble() != seconds.toLong().toDouble()) throw ProtocolException("Invalid auth response")
        return seconds.toInt()
    }
}
