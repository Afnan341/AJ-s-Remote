package com.ajsremote.security

import java.util.Base64

/**
 * Text format for encrypted values: `v1:<base64 iv>:<base64 ciphertext-with-tag>`.
 * Pure Kotlin so the format can be unit tested on the JVM.
 */
class EncryptedPayload(val iv: ByteArray, val ciphertext: ByteArray) {

    fun encode(): String {
        val encoder = Base64.getEncoder()
        return "$VERSION_PREFIX:${encoder.encodeToString(iv)}:${encoder.encodeToString(ciphertext)}"
    }

    companion object {
        private const val VERSION_PREFIX = "v1"
        internal const val IV_BYTES = 12
        internal const val MIN_CIPHERTEXT_BYTES = 16 // GCM authentication tag

        fun decode(text: String): EncryptedPayload {
            val parts = text.split(':')
            require(parts.size == 3 && parts[0] == VERSION_PREFIX) { "Unsupported encrypted payload format" }
            val decoder = Base64.getDecoder()
            val iv = decoder.decode(parts[1])
            val ciphertext = decoder.decode(parts[2])
            require(iv.size == IV_BYTES) { "Invalid IV length" }
            require(ciphertext.size >= MIN_CIPHERTEXT_BYTES) { "Ciphertext too short" }
            return EncryptedPayload(iv, ciphertext)
        }
    }
}
