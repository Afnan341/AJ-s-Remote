package com.ajsremote.pairing

/** A validated AJ's Remote pairing payload. Only [PairingPayloadParser] creates these. */
data class PairingPayload(
    val version: Int,
    val serverId: String,
    val host: String,
    val port: Int,
    val token: String,
    val serverName: String,
    /** Lowercase hex SHA-256 of the server's DER certificate. Null means the server runs plain ws://. */
    val fingerprint: String?,
) {
    /** The pairing token is single-use and must never end up in logs. */
    override fun toString(): String =
        "PairingPayload(serverName=$serverName, host=$host, port=$port, token=***, " +
            "fingerprint=${fingerprint ?: "none"})"
}

sealed interface PairingParseResult {
    data class Success(val payload: PairingPayload) : PairingParseResult

    data class Failure(val error: PairingError, val field: String? = null) : PairingParseResult
}

enum class PairingError(val userMessage: String) {
    NOT_PAIRING_CODE("This isn't an AJ's Remote pairing code."),
    MALFORMED_PAYLOAD("The pairing code is damaged or incomplete. Try scanning again."),
    DUPLICATE_PARAMETER("The pairing code repeats a field. Try scanning again."),
    MISSING_PARAMETER("The pairing code is missing a required field."),
    UNSUPPORTED_VERSION("This pairing code needs a different version of AJ's Remote."),
    INVALID_SERVER_ID("The server ID in the pairing code is invalid."),
    INVALID_HOST("The PC address in the pairing code is invalid."),
    INVALID_PORT("The port in the pairing code is invalid."),
    INVALID_TOKEN("The pairing token is invalid."),
    INVALID_SERVER_NAME("The PC name in the pairing code is invalid."),
    INVALID_FINGERPRINT("The certificate fingerprint in the pairing code is invalid."),
}
