package com.ajsremote.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.ajsremote.security.KeystoreSecretCipher
import com.ajsremote.security.SecretCipher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONException
import java.security.GeneralSecurityException
import java.util.UUID

private val Context.ajsRemoteDataStore: DataStore<Preferences> by preferencesDataStore(name = "ajs_remote_store")

/**
 * Persists the device identity (plain, not secret) and the paired-server credentials
 * (encrypted with [SecretCipher] before they reach DataStore).
 */
class DeviceCredentialStore internal constructor(
    private val dataStore: DataStore<Preferences>,
    private val cipher: SecretCipher,
) {

    constructor(context: Context) : this(
        dataStore = context.applicationContext.ajsRemoteDataStore,
        cipher = KeystoreSecretCipher(),
    )

    /** Null means unpaired. Decryption or corruption errors are surfaced, never silently treated as unpaired. */
    val credentials: Flow<PairedServerCredentials?> = dataStore.data.map { prefs ->
        prefs[CREDENTIALS_KEY]?.let { encrypted ->
            PairedServerCredentials.fromJson(String(cipher.decrypt(encrypted), Charsets.UTF_8))
        }
    }

    /** Returns one stable device ID, atomically created even across multiple store instances. */
    suspend fun deviceId(): String {
        val updated = dataStore.edit { prefs ->
            val existing = prefs[DEVICE_ID_KEY]
            if (existing == null || !DEVICE_ID_PATTERN.matches(existing)) {
                prefs[DEVICE_ID_KEY] = UUID.randomUUID().toString().replace("-", "")
            }
        }
        return requireNotNull(updated[DEVICE_ID_KEY])
    }

    suspend fun save(credentials: PairedServerCredentials) = credentialWriteLock.withLock {
        val plaintext = credentials.toJson().toByteArray(Charsets.UTF_8)
        val encrypted = try { cipher.encrypt(plaintext) } finally { plaintext.fill(0) }
        dataStore.edit { it[CREDENTIALS_KEY] = encrypted }
        Unit
    }

    /** Persist before pair_request: no token or secret is stored in this marker. */
    suspend fun beginPairing(serverId: String) = credentialWriteLock.withLock {
        dataStore.edit { prefs ->
            check(prefs[PAIRING_IN_PROGRESS] == null) { "A pairing attempt needs recovery" }
            prefs[PAIRING_IN_PROGRESS] = serverId
        }
        Unit
    }

    suspend fun pendingPairing(): String? = dataStore.data.first()[PAIRING_IN_PROGRESS]

    /** The secret record and journal removal commit together, or neither does. */
    suspend fun completePairing(credentials: PairedServerCredentials) = credentialWriteLock.withLock {
        val plaintext = credentials.toJson().toByteArray(Charsets.UTF_8)
        val encrypted = try { cipher.encrypt(plaintext) } finally { plaintext.fill(0) }
        dataStore.edit { prefs ->
            check(prefs[PAIRING_IN_PROGRESS] == credentials.serverId) { "Pairing journal mismatch" }
            prefs[CREDENTIALS_KEY] = encrypted
            prefs.remove(PAIRING_IN_PROGRESS)
        }
        Unit
    }

    /** Call only after definite rejection or explicit user acknowledgement of PC-side cleanup. */
    suspend fun clearPendingPairing(expectedServerId: String) = credentialWriteLock.withLock {
        dataStore.edit { prefs ->
            check(prefs[PAIRING_IN_PROGRESS] == expectedServerId) { "Pairing journal changed" }
            prefs.remove(PAIRING_IN_PROGRESS)
        }
        Unit
    }

    /** Removes the encrypted record while retaining the device ID and Keystore key. */
    suspend fun clear() = credentialWriteLock.withLock {
        dataStore.edit { it.remove(CREDENTIALS_KEY) }
        Unit
    }

    companion object {
        private val credentialWriteLock = Mutex()
        private val CREDENTIALS_KEY = stringPreferencesKey("paired_server_v1")
        private val PAIRING_IN_PROGRESS = stringPreferencesKey("pairing_in_progress_server_v1")
        private val DEVICE_ID_KEY = stringPreferencesKey("device_id")
        private val DEVICE_ID_PATTERN = Regex("[A-Za-z0-9_-]{16,64}")
    }
}
