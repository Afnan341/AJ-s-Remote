package com.ajsremote.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ajsremote.pairing.PairingParseResult
import com.ajsremote.pairing.PairingPayload
import com.ajsremote.pairing.PairingPayloadParser
import com.ajsremote.ui.theme.AjsBackground
import com.ajsremote.ui.theme.AjsRed
import com.ajsremote.ui.theme.AjsTextSecondary

/** All scan state is memory-only; pairing tokens are never saved in Compose saved state. */
private sealed interface Screen {
    data object Home : Screen
    data object Permission : Screen
    data object Scanner : Screen
    data class Error(val message: String) : Screen
    data class Scanned(val payload: PairingPayload) : Screen
    data class Connecting(val payload: PairingPayload?) : Screen
}

@Composable
fun RemoteApp() {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    var permissionAsked by remember { mutableStateOf(false) }
    fun hasPermission(): Boolean = ContextCompat.checkSelfPermission(
        context, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        screen = if (granted) Screen.Scanner else Screen.Permission
    }
    fun requestScanner() {
        if (hasPermission()) screen = Screen.Scanner
        else { screen = Screen.Permission; permissionAsked = true; launcher.launch(Manifest.permission.CAMERA) }
    }
    // Returning from system settings after granting permission can resume scanning.
    DisposableEffect(owner, screen) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (screen is Screen.Permission && hasPermission()) screen = Screen.Scanner
                else if (screen is Screen.Scanner && !hasPermission()) screen = Screen.Permission
            }
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    BackHandler(enabled = screen !is Screen.Home) { screen = Screen.Home }

    when (val current = screen) {
        Screen.Home -> MessageScreen(
            title = "AJ's Remote", message = "Not connected", action = "Connect to PC",
            onAction = { requestScanner() },
            secondary = "Reconnect saved PC", onSecondary = { screen = Screen.Connecting(null) }
        )
        Screen.Permission -> MessageScreen(
            title = "Camera access needed",
            message = "Allow camera access to scan the pairing code on your PC.",
            action = if (permissionAsked) "Try permission again" else "Allow camera",
            onAction = { requestScanner() },
            secondary = "Open app settings",
            onSecondary = {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", context.packageName, null))
                context.startActivity(intent)
            },
            cancel = { screen = Screen.Home },
        )
        Screen.Scanner -> ScannerScreen(
            onBack = { screen = Screen.Home },
            onFailure = { screen = Screen.Error(it) },
            onCode = { raw ->
                screen = when (val result = PairingPayloadParser.parse(raw)) {
                    is PairingParseResult.Success -> Screen.Scanned(result.payload)
                    is PairingParseResult.Failure -> Screen.Error(result.error.userMessage)
                }
            },
        )
        is Screen.Error -> MessageScreen(
            title = "Couldn't scan", message = current.message,
            action = "Try again", onAction = { requestScanner() },
            cancel = { screen = Screen.Home },
        )
        is Screen.Scanned -> MessageScreen(
            title = "Pairing code recognized",
            message = "${current.payload.serverName}\n${current.payload.host}:${current.payload.port}\n" +
                (if (current.payload.fingerprint == null)
                    "Unencrypted server. Enable TLS on the PC and scan a new code to pair securely."
                 else "Encrypted: certificate fingerprint will be verified.") +
                "\n\nNot connected yet.",
            action = if (current.payload.fingerprint == null) "Scan a TLS-enabled code" else "Pair with PC",
            onAction = { if (current.payload.fingerprint == null) requestScanner() else screen = Screen.Connecting(current.payload) },
            secondary = "Scan another", onSecondary = { requestScanner() },
            cancel = { screen = Screen.Home },
        )
        is Screen.Connecting -> ConnectionScreen(
            payload = current.payload,
            onBack = { screen = Screen.Home },
        )
    }
}

@Composable
private fun MessageScreen(
    title: String,
    message: String,
    action: String,
    onAction: () -> Unit,
    secondary: String? = null,
    onSecondary: (() -> Unit)? = null,
    cancel: (() -> Unit)? = null,
) {
    Box(Modifier.fillMaxSize().background(AjsBackground).padding(24.dp), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)) {
            Box(Modifier.size(width = 48.dp, height = 4.dp).background(AjsRed, RoundedCornerShape(2.dp)))
            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(message, color = AjsTextSecondary, style = MaterialTheme.typography.bodyLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Button(onClick = onAction) { Text(action) }
            if (secondary != null && onSecondary != null) {
                OutlinedButton(onClick = onSecondary) { Text(secondary) }
            }
            if (cancel != null) OutlinedButton(onClick = cancel) { Text("Back") }
        }
    }
}
