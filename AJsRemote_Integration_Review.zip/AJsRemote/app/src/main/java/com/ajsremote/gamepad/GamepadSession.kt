package com.ajsremote.gamepad

import okhttp3.WebSocket

/** All sends are serialized with attachment/detachment; a socket attaches only after auth_ok. */
class GamepadSession {
    private val lock = Any()
    private var socket: WebSocket? = null
    private val down = mutableSetOf<String>()
    private val axes = mutableMapOf<String, Float>()

    fun attach(authenticatedSocket: WebSocket) = synchronized(lock) {
        socket = authenticatedSocket
        down.clear(); axes.clear()
        transmit(GamepadProtocol.axis("left_x", 0f))
    }
    fun button(name: String, pressed: Boolean) = synchronized(lock) {
        if (socket == null) return@synchronized
        // Validate before changing the held-state set, so an invalid name cannot break cleanup.
        val frame = GamepadProtocol.button(name, pressed)
        if (pressed && down.add(name)) transmit(frame)
        else if (!pressed && down.remove(name)) transmit(frame)
    }
    fun axis(name: String, value: Float) = synchronized(lock) {
        if (socket == null) return@synchronized
        if (axes[name] != value) {
            val frame = GamepadProtocol.axis(name, value)
            axes[name] = value
            transmit(frame)
        }
    }
    /** Called when controller UI disappears; server also releases inputs on disconnect. */
    fun neutralize() = synchronized(lock) {
        if (socket != null) {
            down.toList().forEach { transmit(GamepadProtocol.button(it, false)) }
            axes.filterValues { it != 0f }.keys.toList().forEach { transmit(GamepadProtocol.axis(it, 0f)) }
        }
        down.clear(); axes.clear()
    }
    fun detach(expected: WebSocket) = synchronized(lock) {
        if (socket === expected) { neutralize(); socket = null }
    }
    private fun transmit(frame: String) {
        val s = socket ?: return
        if (!s.send(frame)) { socket = null; down.clear(); axes.clear(); s.cancel() }
    }
}
