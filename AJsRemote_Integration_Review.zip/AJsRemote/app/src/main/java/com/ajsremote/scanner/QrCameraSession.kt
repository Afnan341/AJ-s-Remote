package com.ajsremote.scanner

import android.content.Context
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Owns one preview, one analysis use case and one ML Kit client. All UI callbacks are posted
 * to the main executor. The decoded string is ephemeral and is never logged or persisted.
 */
class QrCameraSession(
    context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val previewView: PreviewView,
    private val onDecoded: (String) -> Unit,
    private val onCameraReady: (Boolean) -> Unit,
    private val onError: (String) -> Unit,
    private val onTorchChanged: (Boolean) -> Unit,
) : AutoCloseable {
    private val appContext = context.applicationContext
    private val main = ContextCompat.getMainExecutor(appContext)
    private val executor: ExecutorService = Executors.newSingleThreadExecutor()
    private val scanner: BarcodeScanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    )
    private val gate = ScanGate()
    private val closed = AtomicBoolean(false)
    private val busy = AtomicBoolean(false)
    private val cleaned = AtomicBoolean(false)
    private val torchPending = AtomicBoolean(false)
    private var provider: ProcessCameraProvider? = null
    private var preview: Preview? = null
    private var analysis: ImageAnalysis? = null
    private var camera: Camera? = null
    private var torch = false

    /** Call from the main thread. */
    fun start() {
        val future = try {
            ProcessCameraProvider.getInstance(appContext)
        } catch (_: Exception) {
            onError("Camera couldn't start. Check camera permission and try again.")
            return
        }
        future.addListener({
            if (closed.get()) return@addListener
            try {
                val p = future.get()
                provider = p
                val pview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analyzer = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                preview = pview
                analysis = analyzer
                analyzer.setAnalyzer(executor) { image -> analyze(image) }
                camera = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, pview, analyzer)
                onCameraReady(camera?.cameraInfo?.hasFlashUnit() == true)
            } catch (_: Exception) {
                onError("Camera couldn't start. Check camera permission and try again.")
            }
        }, main)
    }

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    private fun analyze(proxy: ImageProxy) {
        if (closed.get() || !busy.compareAndSet(false, true)) {
            proxy.close()
            return
        }
        if (closed.get()) {
            proxy.close()
            busy.set(false)
            main.execute { finishCleanup() }
            return
        }
        try {
            val mediaImage = proxy.image
            if (mediaImage == null) {
                proxy.close()
                busy.set(false)
                if (closed.get()) main.execute { finishCleanup() }
                return
            }
            val input = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
            scanner.process(input)
                .addOnSuccessListener(main) { barcodes ->
                    val text = barcodes.firstNotNullOfOrNull { it.rawValue }
                    if (text != null && !closed.get() && gate.tryClaim()) onDecoded(text)
                }
                .addOnFailureListener(main) {
                    if (!closed.get()) onError("QR scanning failed. Please try again.")
                }
                .addOnCompleteListener(main) {
                    proxy.close()
                    busy.set(false)
                    if (closed.get()) finishCleanup()
                }
        } catch (_: Exception) {
            proxy.close()
            busy.set(false)
            main.execute {
                if (closed.get()) finishCleanup() else onError("QR scanning failed. Please try again.")
            }
        }
    }

    /** CameraControl futures report the actual result, rather than assuming the torch changed. */
    fun toggleTorch() {
        val current = camera ?: return
        if (!current.cameraInfo.hasFlashUnit() || closed.get() || !torchPending.compareAndSet(false, true)) return
        val requested = !torch
        val future = current.cameraControl.enableTorch(requested)
        future.addListener({
            torchPending.set(false)
            if (!closed.get()) {
                try {
                    future.get()
                    torch = requested
                    onTorchChanged(torch)
                } catch (_: Exception) {
                    onError("Flashlight couldn't be changed. Please try again.")
                }
            }
        }, main)
    }

    /** Call from the main thread. Does not unbind use cases owned by other parts of the app. */
    override fun close() {
        if (!closed.compareAndSet(false, true)) return
        try { camera?.cameraControl?.enableTorch(false) } catch (_: Exception) { /* camera already unavailable */ }
        analysis?.clearAnalyzer()
        executor.shutdown()
        // CameraX invalidates images on unbind; let an in-flight ML Kit task finish first.
        if (!busy.get()) finishCleanup()
    }

    /** Main thread only. No use case is unbound while a submitted image is being analyzed. */
    private fun finishCleanup() {
        if (!closed.get() || busy.get() || !cleaned.compareAndSet(false, true)) return
        val owned = listOfNotNull(preview, analysis).toTypedArray()
        try {
            if (owned.isNotEmpty()) provider?.unbind(*owned)
        } finally {
            camera = null
            scanner.close()
        }
    }
}
