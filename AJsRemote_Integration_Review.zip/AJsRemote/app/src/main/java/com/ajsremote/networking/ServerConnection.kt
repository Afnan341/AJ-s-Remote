package com.ajsremote.networking

import com.ajsremote.pairing.PairingPayload
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.Closeable
import java.io.IOException
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLException
import kotlin.coroutines.coroutineContext

sealed interface ConnectionState {
    data class Connecting(val attempt: Int) : ConnectionState
    data object SendingHello : ConnectionState
    data class Greeted(val serverName: String, val unencrypted: Boolean) : ConnectionState
    data class Retrying(val attempt: Int) : ConnectionState
    data class Failed(val message: String) : ConnectionState
}

private sealed interface WireEvent {
    data object Open : WireEvent
    data class Text(val text: String) : WireEvent
    data class Failure(val throwable: Throwable) : WireEvent
    data class Closed(val reason: String) : WireEvent
    data object Binary : WireEvent
}

/** One QR-scoped connection. This stage stops before pairing and cannot authenticate. */
@Deprecated("Legacy hello-only diagnostic; the application lifecycle is owned by PairingClient")
internal class ServerConnection(
    private val qr: PairingPayload,
    private val deviceId: String,
    private val allowUnencrypted: Boolean = false,
) {
    /** Call from a lifecycle-bound coroutine. Cancellation closes the underlying socket. */
    suspend fun run(onState: suspend (ConnectionState) -> Unit) = withContext(Dispatchers.IO) {
        if (qr.fingerprint == null && !allowUnencrypted) {
            onState(ConnectionState.Failed("Unencrypted connections require explicit consent."))
            return@withContext
        }
        for (attempt in 1..3) {
            try {
                onState(ConnectionState.Connecting(attempt))
                runOnce(onState)
                return@withContext
            } catch (e: TimeoutCancellationException) {
                if (attempt == 3) {
                    onState(ConnectionState.Failed("Connection timed out. Check the PC and network.")); return@withContext
                }
                onState(ConnectionState.Retrying(attempt + 1))
                delay(if (attempt == 1) 1000 else 2000)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ProtocolException) {
                onState(ConnectionState.Failed(e.message ?: "Invalid server response")); return@withContext
            } catch (e: javax.net.ssl.SSLException) {
                onState(ConnectionState.Failed("TLS verification failed. Check the QR code and server certificate.")); return@withContext
            } catch (e: Exception) {
                if (attempt == 3) {
                    onState(ConnectionState.Failed("Connection lost or timed out. Check the PC, network and QR code."))
                    return@withContext
                }
                onState(ConnectionState.Retrying(attempt + 1))
                delay(if (attempt == 1) 1000 else 2000)
            }
        }
    }

    private suspend fun runOnce(onState: suspend (ConnectionState) -> Unit) {
        val client = createClient()
        val events = Channel<WireEvent>(32)
        var socket: WebSocket? = null
        try {
            val url = "${if (qr.fingerprint == null) "ws" else "wss"}://${qr.host}:${qr.port}/"
            val listener = object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) { events.trySend(WireEvent.Open) }
                override fun onMessage(webSocket: WebSocket, text: String) {
                    if (events.trySend(WireEvent.Text(text)).isFailure) webSocket.cancel()
                }
                override fun onMessage(webSocket: WebSocket, bytes: ByteString) { events.trySend(WireEvent.Binary) }
                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { events.trySend(WireEvent.Failure(t)) }
                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(code, null); events.trySend(WireEvent.Closed(reason))
                }
                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { events.trySend(WireEvent.Closed(reason)) }
            }
            val ws = client.newWebSocket(Request.Builder().url(url).build(), listener)
            socket = ws
            when (val event = withTimeout(10000) { events.receive() }) {
                WireEvent.Open -> Unit
                else -> throwEvent(event)
            }
            onState(ConnectionState.SendingHello)
            if (!ws.send(HelloProtocol.hello(deviceId))) throw IOException("Unable to send hello")
            val ack = when (val event = withTimeout(10000) { events.receive() }) {
                is WireEvent.Text -> {
                    val type = HelloProtocol.type(event.text)
                    if (type == "error") throw ProtocolException("Server refused handshake: ${HelloProtocol.errorCode(event.text)}")
                    HelloProtocol.helloAck(event.text, qr.serverId)
                }
                else -> throwEvent(event)
            }
            onState(ConnectionState.Greeted(ack.serverName, qr.fingerprint == null))
            // The server times out GREETED sessions after 10s. Ping while showing the screen.
            var awaitingPong = false
            var lastPing = 0L
            while (coroutineContext.isActive) {
                val event = withTimeoutOrNull(5000) { events.receive() }
                if (event == null) {
                    if (awaitingPong && System.nanoTime() - lastPing > TimeUnit.SECONDS.toNanos(15)) {
                        throw IOException("Heartbeat timeout")
                    }
                    if (!awaitingPong) {
                        if (!ws.send(HelloProtocol.ping())) throw IOException("Unable to send heartbeat")
                        awaitingPong = true
                        lastPing = System.nanoTime()
                    }
                    continue
                }
                when (event) {
                    is WireEvent.Text -> when (HelloProtocol.type(event.text)) {
                        "pong" -> awaitingPong = false
                        "error" -> throw ProtocolException("Server error: ${HelloProtocol.errorCode(event.text)}")
                        "bye" -> throw ProtocolException("Server closed this session")
                        else -> throw ProtocolException("Unexpected server response")
                    }
                    else -> throwEvent(event)
                }
            }
        } finally {
            socket?.send(HelloProtocol.bye())
            socket?.close(1000, "Client disconnect")
            events.close()
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        }
    }

    private fun throwEvent(event: WireEvent): Nothing = when (event) {
        is WireEvent.Failure -> {
            val tls = generateSequence(event.throwable) { it.cause }.firstOrNull { it is SSLException }
            if (tls is SSLException) throw tls
            throw IOException("WebSocket failure", event.throwable)
        }
        is WireEvent.Closed -> throw IOException("Socket closed")
        WireEvent.Binary -> throw ProtocolException("Server sent a binary message")
        else -> throw ProtocolException("Unexpected socket event")
    }

    private fun createClient(): OkHttpClient {
        val builder = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.SECONDS).retryOnConnectionFailure(false)
        qr.fingerprint?.let { fingerprint ->
            val pin = CertificatePin(fingerprint)
            val trust = PinnedTrustManager(pin)
            val context = SSLContext.getInstance("TLS")
            context.init(null, arrayOf(trust), null)
            builder.sslSocketFactory(context.socketFactory, trust)
            // The server's self-signed cert has no IP SAN. Verify the exact QR host and pinned
            // peer certificate here instead of DNS hostname validation. This never accepts an unpinned cert.
            builder.hostnameVerifier { host, session ->
                host == qr.host && try {
                    val leaf = session.peerCertificates.firstOrNull() as? X509Certificate
                    leaf != null && pin.matches(leaf)
                } catch (_: Exception) { false }
            }
        }
        return builder.build()
    }
}
