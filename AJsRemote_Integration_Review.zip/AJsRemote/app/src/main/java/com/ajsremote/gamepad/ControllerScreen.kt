package com.ajsremote.gamepad

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import com.ajsremote.ui.theme.AjsBackground
import com.ajsremote.ui.theme.AjsRed
import com.ajsremote.ui.theme.AjsTextSecondary
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.hypot

private val android.content.Context.controllerPreferences by preferencesDataStore(name = "controller_layout")
private val SWAP_STICKS = booleanPreferencesKey("swap_sticks")

@Composable
fun ControllerScreen(session: GamepadSession, name: String, error: String?, onDisconnect: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var swap by remember { mutableStateOf(false) }
    androidx.compose.runtime.LaunchedEffect(context) {
        swap = context.applicationContext.controllerPreferences.data.first()[SWAP_STICKS] ?: false
    }
    DisposableEffect(session) { onDispose { session.neutralize() } }
    Column(Modifier.fillMaxSize().background(AjsBackground).verticalScroll(rememberScrollState()).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("AJ'S REMOTE", color = AjsRed, style = MaterialTheme.typography.labelLarge)
                Text("Connected: $name", color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
            }
            OutlinedButton(onClick = onDisconnect) { Text("Disconnect") }
        }
        if (error != null) Text(error, color = AjsRed, textAlign = TextAlign.Center)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            HoldControl("L2", Modifier.weight(1f).height(48.dp)) { session.axis("lt", if (it) 1f else 0f) }
            Spacer(Modifier.width(8.dp))
            HoldControl("R2", Modifier.weight(1f).height(48.dp)) { session.axis("rt", if (it) 1f else 0f) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            HoldControl("L1", Modifier.weight(1f).height(44.dp)) { session.button("lb", it) }
            Spacer(Modifier.width(8.dp))
            HoldControl("R1", Modifier.weight(1f).height(44.dp)) { session.button("rb", it) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (swap) "RIGHT STICK" else "LEFT STICK", color = AjsTextSecondary, style = MaterialTheme.typography.labelSmall)
                Stick(if (swap) "right" else "left", session)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (swap) "LEFT STICK" else "RIGHT STICK", color = AjsTextSecondary, style = MaterialTheme.typography.labelSmall)
                Stick(if (swap) "left" else "right", session)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Dpad(session)
            FaceButtons(session)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HoldControl("SELECT", Modifier.width(100.dp).height(44.dp)) { session.button("back", it) }
            HoldControl("START", Modifier.width(100.dp).height(44.dp)) { session.button("start", it) }
        }
        OutlinedButton(onClick = {
            session.neutralize()
            swap = !swap
            val newValue = swap
            scope.launch { context.applicationContext.controllerPreferences.edit { it[SWAP_STICKS] = newValue } }
        }) { Text(if (swap) "Layout: sticks swapped" else "Layout: standard") }
        Text("Hold controls to play. Swap sticks to customize.", color = AjsTextSecondary,
            style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
    }
}

/** A button's pointer owns its hold until release/cancel; simultaneous controls remain independent. */
@Composable
private fun HoldControl(label: String, modifier: Modifier = Modifier, onHold: (Boolean) -> Unit) {
    val latest by androidx.compose.runtime.rememberUpdatedState(onHold)
    var pressed by remember { mutableStateOf(false) }
    Box(modifier.background(if (pressed) AjsRed else Color(0xFF252525), RoundedCornerShape(14.dp))
        .border(1.dp, AjsRed.copy(alpha = .65f), RoundedCornerShape(14.dp))
        .pointerInput(Unit) {
            awaitEachGesture {
                val start = awaitFirstDown(requireUnconsumed = false)
                start.consume()
                pressed = true
                latest(true)
                try {
                    var held = true
                    while (held) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == start.id }
                        held = change?.pressed == true
                        change?.consume()
                    }
                } finally { pressed = false; latest(false) }
            }
        }, contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun Stick(which: String, session: GamepadSession) {
    var position by remember(which) { mutableStateOf(Offset.Zero) }
    Canvas(Modifier.padding(4.dp).size(126.dp).pointerInput(which, session) {
        awaitEachGesture {
            val first = awaitFirstDown(requireUnconsumed = false)
            fun update(p: Offset) {
                val radius = (minOf(size.width, size.height) / 2f).coerceAtLeast(1f)
                val dx = (p.x - size.width / 2f) / radius
                val dy = (p.y - size.height / 2f) / radius
                val mag = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
                val x = (dx / mag).coerceIn(-1f, 1f); val y = (dy / mag).coerceIn(-1f, 1f)
                position = Offset(x, y)
                session.axis("${which}_x", x); session.axis("${which}_y", y)
            }
            first.consume()
            try {
                update(first.position)
                var held = true
                while (held) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == first.id }
                    held = change?.pressed == true
                    if (change != null) { if (change.pressed) update(change.position); change.consume() }
                }
            } finally { position = Offset.Zero; session.axis("${which}_x", 0f); session.axis("${which}_y", 0f) }
        }
    }) {
        drawCircle(Color(0xFF252525))
        drawCircle(AjsRed.copy(alpha = .55f), style = androidx.compose.ui.graphics.drawscope.Stroke(2.dp.toPx()))
        val radius = size.minDimension / 2f
        drawCircle(AjsRed, radius = radius * .30f, center = Offset(center.x + position.x * radius * .6f, center.y + position.y * radius * .6f))
    }
}

@Composable
private fun Dpad(session: GamepadSession) {
    var left by remember { mutableStateOf(false) }; var right by remember { mutableStateOf(false) }
    var up by remember { mutableStateOf(false) }; var down by remember { mutableStateOf(false) }
    fun horizontal() = session.axis("dpad_x", (if (right) 1f else 0f) - (if (left) 1f else 0f))
    fun vertical() = session.axis("dpad_y", (if (down) 1f else 0f) - (if (up) 1f else 0f))
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HoldControl("▲", Modifier.size(44.dp)) { up = it; vertical() }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            HoldControl("◀", Modifier.size(44.dp)) { left = it; horizontal() }
            Spacer(Modifier.size(44.dp))
            HoldControl("▶", Modifier.size(44.dp)) { right = it; horizontal() }
        }
        HoldControl("▼", Modifier.size(44.dp)) { down = it; vertical() }
    }
}

@Composable
private fun FaceButtons(session: GamepadSession) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HoldControl("Y", Modifier.size(44.dp)) { session.button("y", it) }
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            HoldControl("X", Modifier.size(44.dp)) { session.button("x", it) }
            Spacer(Modifier.size(44.dp))
            HoldControl("B", Modifier.size(44.dp)) { session.button("b", it) }
        }
        HoldControl("A", Modifier.size(44.dp)) { session.button("a", it) }
    }
}
