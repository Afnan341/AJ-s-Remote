package com.ajsremote.networking

import org.json.JSONObject
import java.util.Base64

class ProtocolException(message: String) : Exception(message)

data class HelloAck(val serverId: String, val serverName: String, val paired: Boolean, val challenge: String)

/** Only the v1 initial greeting. No pairing, auth or secret handling is implemented here. */
object HelloProtocol {
    const val HELLO_ID = "hello-1"
    fun hello(deviceId: String): String {
        require(Regex("[A-Za-z0-9_-]{16,64}").matches(deviceId))
        val payload = JSONObject().put("device_id", deviceId)
            .put("device_name", "AJ's Remote Android").put("app_version", "0.2.0")
        return JSONObject().put("v", 1).put("type", "hello").put("id", HELLO_ID).put("payload", payload).toString()
    }
    fun ping(): String = JSONObject().put("v", 1).put("type", "ping").put("payload", JSONObject()).toString()
    fun bye(): String = JSONObject().put("v", 1).put("type", "bye").put("payload", JSONObject()).toString()

    fun type(text: String): String {
        if (text.toByteArray(Charsets.UTF_8).size > 16384) throw ProtocolException("Oversized server message")
        try {
            val root = JSONObject(text)
            if (root.opt("v") !is Int || root.getInt("v") != 1) throw ProtocolException("Unsupported protocol version")
            val t = root.opt("type")
            if (t !is String || t.isEmpty()) throw ProtocolException("Invalid message type")
            if (root.opt("payload") !is JSONObject) throw ProtocolException("Invalid server payload")
            return t
        } catch (e: ProtocolException) { throw e }
        catch (_: Exception) { throw ProtocolException("Malformed server response") }
    }

    fun helloAck(text: String, expectedServerId: String): HelloAck {
        if (type(text) != "hello_ack") throw ProtocolException("Expected server hello acknowledgement")
        try {
            val root = JSONObject(text)
            if (root.opt("re") != HELLO_ID) throw ProtocolException("Unexpected hello response ID")
            val p = root.getJSONObject("payload")
            val sid = p.opt("server_id") as? String ?: throw ProtocolException("Missing server identity")
            if (sid != expectedServerId) throw ProtocolException("Server identity differs from QR code")
            val name = p.opt("server_name") as? String ?: throw ProtocolException("Missing server name")
            if (name.isEmpty() || name.codePointCount(0, name.length) > 64) throw ProtocolException("Invalid server name")
            if (p.opt("protocol_version") !is Int || p.getInt("protocol_version") != 1) throw ProtocolException("Unsupported protocol version")
            val paired = p.opt("paired") as? Boolean ?: throw ProtocolException("Invalid pairing state")
            val challenge = p.opt("challenge") as? String ?: throw ProtocolException("Missing challenge")
            if (!Regex("[A-Za-z0-9_-]{43}").matches(challenge) || Base64.getUrlDecoder().decode(challenge).size != 32) {
                throw ProtocolException("Invalid authentication challenge")
            }
            return HelloAck(sid, name, paired, challenge)
        } catch (e: ProtocolException) { throw e }
        catch (_: Exception) { throw ProtocolException("Malformed hello acknowledgement") }
    }
    fun errorCode(text: String): String = try {
        JSONObject(text).getJSONObject("payload").optString("code", "unknown")
    } catch (_: Exception) { "unknown" }
}
