package com.ajsremote.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.ajsremote.security.SecretCipher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.util.Base64

/** Local repository race regressions. The test cipher is NOT Keystore encryption. */
class PairingRecoveryTest {
    private class Cipher : SecretCipher {
        var fail = false
        override fun encrypt(plaintext: ByteArray): String {
            check(!fail) { "simulated storage failure" }
            return Base64.getEncoder().encodeToString(plaintext)
        }
        override fun decrypt(payload: String) = Base64.getDecoder().decode(payload)
        override fun deleteKey() = Unit
    }
    private suspend fun runStore(block: suspend (DeviceCredentialStore, Cipher) -> Unit) {
        val dir = createTempDir(prefix = "ajs-recovery-")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        try {
            val ds = PreferenceDataStoreFactory.create(scope = scope, produceFile = { File(dir, "recovery.preferences_pb") })
            val cipher = Cipher()
            block(DeviceCredentialStore(ds, cipher), cipher)
        } finally { scope.cancel(); dir.deleteRecursively() }
    }
    private fun record() = PairedServerCredentials("pc", "PC", "192.168.1.2", 8765, "a".repeat(64), "a".repeat(32), "A".repeat(43))

    @Test fun lossBeforeSecretLeavesRecoveryMarker() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("pc")
            // Simulated loss: no completion is invoked.
            assertEquals("pc", store.pendingPairing())
            assertNull(store.credentials.first())
        }
    }
    @Test fun failedSecretStoragePreservesMarkerAndNeverReportsSaved() = runBlocking {
        runStore { store, cipher ->
            store.beginPairing("pc"); cipher.fail = true
            var failed = false
            try { store.completePairing(record()) } catch (_: IllegalStateException) { failed = true }
            assertTrue(failed)
            assertEquals("pc", store.pendingPairing())
            assertNull(store.credentials.first())
        }
    }
    @Test fun cancellationDuringStartedApprovalSaveFinishesAtomicCommit() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("pc")
            val entered = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
            val job = launch {
                withContext(NonCancellable) {
                    entered.complete(Unit); release.await(); store.completePairing(record())
                }
            }
            entered.await(); job.cancel(); release.complete(Unit); job.join()
            assertNull(store.pendingPairing())
            assertEquals(record(), store.credentials.first())
        }
    }
    @Test fun reconnectCanReadCompletedCredentials() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("pc"); store.completePairing(record())
            // Re-read repository output as reconnect does. This is not a socket or process-restart test.
            assertEquals(record(), store.credentials.first())
            assertNull(store.pendingPairing())
        }
    }
    @Test fun duplicateBeginDoesNotOverwriteRecoveryMarker() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("pc")
            var failed = false
            try { store.beginPairing("other") } catch (_: IllegalStateException) { failed = true }
            assertTrue(failed)
            assertEquals("pc", store.pendingPairing())
        }
    }
    @Test fun completionForWrongServerDoesNotClearMarkerOrSaveCredentials() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("other")
            var failed = false
            try { store.completePairing(record()) } catch (_: IllegalStateException) { failed = true }
            assertTrue(failed)
            assertEquals("other", store.pendingPairing())
            assertNull(store.credentials.first())
        }
    }
    @Test fun journalCannotBeClearedForDifferentServer() = runBlocking {
        runStore { store, _ ->
            store.beginPairing("pc")
            var failed = false
            try { store.clearPendingPairing("other") } catch (_: IllegalStateException) { failed = true }
            assertTrue(failed); assertEquals("pc", store.pendingPairing())
        }
    }
}
