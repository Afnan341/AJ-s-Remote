package com.ajsremote.security

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Tests the serialized GCM payload using JVM cryptography, not Android Keystore. */
class SecretCipherContractTest {
    @Test
    fun gcmPayloadRoundTripAndTamperDetection() {
        val key = SecretKeySpec(ByteArray(32) { it.toByte() }, "AES")
        val encrypt = Cipher.getInstance("AES/GCM/NoPadding")
        encrypt.init(Cipher.ENCRYPT_MODE, key)
        val plaintext = "device-secret-value".toByteArray()
        val decoded = EncryptedPayload.decode(EncryptedPayload(encrypt.iv, encrypt.doFinal(plaintext)).encode())
        fun decrypt(ciphertext: ByteArray): ByteArray {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, decoded.iv))
            return cipher.doFinal(ciphertext)
        }
        assertArrayEquals(plaintext, decrypt(decoded.ciphertext))
        val tampered = decoded.ciphertext.copyOf()
        tampered[0] = (tampered[0].toInt() xor 1).toByte()
        assertThrows(AEADBadTagException::class.java) { decrypt(tampered) }
    }
}
