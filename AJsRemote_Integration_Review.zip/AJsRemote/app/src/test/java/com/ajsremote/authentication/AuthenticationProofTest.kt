package com.ajsremote.authentication

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class AuthenticationProofTest {
    @Test fun matchesPythonServerVector() {
        val secret = "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8"
        val challenge = "ICEiIyQlJicoKSorLC0uLzAxMjM0NTY3ODk6Ozw9Pj8"
        val id = "0123456789abcdef0123456789abcdef"
        assertEquals("8CNXhJEx1_87ZLmkQ5GTYrLVjaXsIAbnsmEldyhg4uQ", AuthenticationProof.calculate(secret, challenge, id))
    }
    @Test fun changingDeviceOrChallengeChangesProof() {
        val secret = "AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8"
        val challenge = "ICEiIyQlJicoKSorLC0uLzAxMjM0NTY3ODk6Ozw9Pj8"
        val id = "0123456789abcdef0123456789abcdef"
        val original = AuthenticationProof.calculate(secret, challenge, id)
        assertFalse(original == AuthenticationProof.calculate(secret, "A".repeat(43), id))
        assertFalse(original == AuthenticationProof.calculate(secret, challenge, "a".repeat(32)))
    }
    @Test fun replayKeysDoNotCollideOnDelimiters() {
        assertTrue(ChallengeReplayGuard.claim("server:one", "device", "challenge"))
        assertTrue(ChallengeReplayGuard.claim("server", "one:device", "challenge"))
    }
    @Test fun rejectsMalformedSecretAndChallenge() {
        assertThrows(IllegalArgumentException::class.java) { AuthenticationProof.calculate("short", "A".repeat(43), "a".repeat(32)) }
        assertThrows(IllegalArgumentException::class.java) { AuthenticationProof.calculate("A".repeat(43), "bad", "a".repeat(32)) }
    }
    @Test fun rejectsReuseWithinProcess() {
        val server = "guard-test-server"; val id = "guard-test-device"; val challenge = "guard-test-challenge"
        assertTrue(ChallengeReplayGuard.claim(server, id, challenge))
        assertFalse(ChallengeReplayGuard.claim(server, id, challenge))
        assertTrue(ChallengeReplayGuard.claim(server, id, "$challenge-new"))
    }
}
