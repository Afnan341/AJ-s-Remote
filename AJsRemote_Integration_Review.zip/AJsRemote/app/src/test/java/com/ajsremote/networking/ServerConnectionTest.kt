package com.ajsremote.networking

import com.ajsremote.pairing.PairingPayload
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Real local socket with a fake peer. This is not a test against the Linux server. */
class ServerConnectionTest {
    @Test fun websocketSendsHelloAndWaitsForRealAcknowledgement() = runBlocking {
        val server = MockWebServer()
        server.enqueue(MockResponse().withWebSocketUpgrade(object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                val obj = JSONObject(text)
                if (obj.getString("type") == "hello") {
                    webSocket.send(JSONObject().put("v", 1).put("type", "hello_ack")
                        .put("re", obj.getString("id"))
                        .put("payload", JSONObject().put("server_id", "server-id").put("server_name", "PC")
                            .put("protocol_version", 1).put("paired", false).put("challenge", "A".repeat(43))).toString())
                }
            }
        }))
        server.start()
        val states = Channel<ConnectionState>(16)
        try {
            val qr = PairingPayload(1, "server-id", "127.0.0.1", server.port, "a".repeat(16), "PC", null)
            val job = launch { ServerConnection(qr, "a".repeat(32), allowUnencrypted = true).run { states.send(it) } }
            val greeted = withTimeout(10000) {
                var value: ConnectionState
                do { value = states.receive() } while (value !is ConnectionState.Greeted)
                value as ConnectionState.Greeted
            }
            assertEquals("PC", greeted.serverName)
            assertTrue(greeted.unencrypted)
            job.cancelAndJoin()
        } finally { server.shutdown() }
    }
}
