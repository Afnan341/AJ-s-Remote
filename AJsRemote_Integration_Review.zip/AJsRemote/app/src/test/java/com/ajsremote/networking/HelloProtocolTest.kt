package com.ajsremote.networking

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Test

class HelloProtocolTest {
    private fun ack(id: String = "server-id", challenge: String = "A".repeat(43)): String = JSONObject()
        .put("v", 1).put("type", "hello_ack").put("re", "hello-1")
        .put("payload", JSONObject().put("server_id", id).put("server_name", "PC")
            .put("protocol_version", 1).put("paired", false).put("challenge", challenge)).toString()
    @Test fun helloUsesServerEnvelopeAndRequiredFields() {
        val obj = JSONObject(HelloProtocol.hello("a".repeat(32)))
        assertEquals(1, obj.getInt("v")); assertEquals("hello", obj.getString("type"))
        assertEquals("hello-1", obj.getString("id"))
        assertEquals("a".repeat(32), obj.getJSONObject("payload").getString("device_id"))
    }
    @Test fun exactServerAckParses() {
        val result = HelloProtocol.helloAck(ack(), "server-id")
        assertEquals("PC", result.serverName); assertFalse(result.paired)
    }
    @Test fun wrongIdentityAndMalformedChallengeFailClosed() {
        assertThrows(ProtocolException::class.java) { HelloProtocol.helloAck(ack("other"), "server-id") }
        assertThrows(ProtocolException::class.java) { HelloProtocol.helloAck(ack(challenge = "bad"), "server-id") }
    }
    @Test fun invalidVersionsAndMessagesFailClosed() {
        assertThrows(ProtocolException::class.java) { HelloProtocol.type("not-json") }
        assertThrows(ProtocolException::class.java) { HelloProtocol.type("{\"v\":2,\"type\":\"pong\",\"payload\":{}}") }
        assertThrows(ProtocolException::class.java) { HelloProtocol.hello("bad") }
    }
}
