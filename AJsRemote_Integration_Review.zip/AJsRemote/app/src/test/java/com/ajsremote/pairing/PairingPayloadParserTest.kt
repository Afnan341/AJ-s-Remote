package com.ajsremote.pairing

import com.ajsremote.pairing.PairingParseResult.Failure
import com.ajsremote.pairing.PairingParseResult.Success
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PairingPayloadParserTest {

    private val token = "AbC_123-defGHIjk" // 16 chars, the minimum allowed
    private val fingerprint = "ab".repeat(32) // 64 lowercase hex chars

    private val validParams: Map<String, String>
        get() = linkedMapOf(
            "v" to "1",
            "sid" to "ajs-server-01",
            "host" to "192.168.1.20",
            "port" to "8765",
            "token" to token,
            "name" to "Afnan%27s%20PC",
            "fp" to fingerprint,
        )

    private fun uriFrom(params: Map<String, String>): String =
        "ajsremote://pair?" + params.entries.joinToString("&") { "${it.key}=${it.value}" }

    private fun parseParams(params: Map<String, String>): PairingParseResult =
        PairingPayloadParser.parse(uriFrom(params))

    private fun parseWith(vararg overrides: Pair<String, String>): PairingParseResult {
        val params = validParams.toMutableMap()
        overrides.forEach { (key, value) -> params[key] = value }
        return parseParams(params)
    }

    private fun assertSuccess(result: PairingParseResult): PairingPayload {
        assertTrue("Expected success but got $result", result is Success)
        return (result as Success).payload
    }

    private fun assertFailure(result: PairingParseResult, expected: PairingError, field: String? = null) {
        assertTrue("Expected failure but got $result", result is Failure)
        val failure = result as Failure
        assertEquals(expected, failure.error)
        if (field != null) assertEquals(field, failure.field)
    }

    // ---- valid payloads ----

    @Test
    fun validPayloadWithFingerprint_parsesEveryField() {
        val payload = assertSuccess(parseParams(validParams))
        assertEquals(1, payload.version)
        assertEquals("ajs-server-01", payload.serverId)
        assertEquals("192.168.1.20", payload.host)
        assertEquals(8765, payload.port)
        assertEquals(token, payload.token)
        assertEquals("Afnan's PC", payload.serverName)
        assertEquals(fingerprint, payload.fingerprint)
    }

    @Test
    fun validPayloadWithoutFingerprint_hasNullFingerprint() {
        val payload = assertSuccess(parseParams(validParams - "fp"))
        assertNull(payload.fingerprint)
    }

    @Test
    fun plusSignDecodesToSpace_andUtf8PercentEscapesDecode() {
        assertEquals("My PC", assertSuccess(parseWith("name" to "My+PC")).serverName)
        assertEquals("Café", assertSuccess(parseWith("name" to "Caf%C3%A9")).serverName)
    }

    @Test
    fun unknownParameter_isIgnoredLikeTheServer() {
        val payload = assertSuccess(parseWith("extra" to "value"))
        assertEquals(8765, payload.port)
    }

    @Test
    fun boundaryValues_areAccepted() {
        assertEquals(1024, assertSuccess(parseWith("port" to "1024")).port)
        assertEquals(65535, assertSuccess(parseWith("port" to "65535")).port)
        assertEquals("0.0.0.0", assertSuccess(parseWith("host" to "0.0.0.0")).host)
        assertEquals("255.255.255.255", assertSuccess(parseWith("host" to "255.255.255.255")).host)
        assertEquals("a".repeat(64), assertSuccess(parseWith("name" to "a".repeat(64))).serverName)
    }

    @Test
    fun payloadToString_doesNotExposeToken() {
        val text = assertSuccess(parseParams(validParams)).toString()
        assertTrue(!text.contains(token))
    }

    // ---- not a pairing code ----

    @Test
    fun foreignSchemeOrAuthority_isNotPairingCode() {
        assertFailure(PairingPayloadParser.parse("https://pair?" + validParams.entries.joinToString("&") { "${it.key}=${it.value}" }), PairingError.NOT_PAIRING_CODE)
        assertFailure(PairingPayloadParser.parse("ajsremote://other?v=1"), PairingError.NOT_PAIRING_CODE)
        assertFailure(PairingPayloadParser.parse("hello world"), PairingError.NOT_PAIRING_CODE)
        assertFailure(PairingPayloadParser.parse(""), PairingError.NOT_PAIRING_CODE)
    }

    @Test
    fun missingQuery_isNotPairingCode() {
        assertFailure(PairingPayloadParser.parse("ajsremote://pair"), PairingError.NOT_PAIRING_CODE)
    }

    // ---- malformed structure ----

    @Test
    fun emptyQuery_isMalformed() {
        assertFailure(PairingPayloadParser.parse("ajsremote://pair?"), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun fragment_isMalformed() {
        assertFailure(PairingPayloadParser.parse(uriFrom(validParams) + "#x"), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun rawWhitespaceOrNonAscii_isMalformed() {
        assertFailure(parseWith("name" to "My PC"), PairingError.MALFORMED_PAYLOAD)
        assertFailure(parseWith("name" to "Café"), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun uriLongerThanLimit_isMalformed() {
        assertFailure(parseWith("sid" to "a".repeat(16385)), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun parameterWithoutEqualsOrKey_isMalformed() {
        assertFailure(PairingPayloadParser.parse("ajsremote://pair?=x&v=1"), PairingError.MALFORMED_PAYLOAD)
        assertFailure(PairingPayloadParser.parse("ajsremote://pair?v"), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun emptyValue_isMalformed() {
        assertFailure(parseWith("sid" to ""), PairingError.MALFORMED_PAYLOAD, "sid")
    }

    @Test
    fun invalidPercentEscapes_areMalformed() {
        assertFailure(parseWith("name" to "%ZZ"), PairingError.MALFORMED_PAYLOAD, "name")
        assertFailure(parseWith("name" to "abc%4"), PairingError.MALFORMED_PAYLOAD, "name")
    }

    @Test
    fun invalidUtf8Escapes_areMalformed() {
        assertFailure(parseWith("name" to "%FF%FE"), PairingError.MALFORMED_PAYLOAD, "name")
    }

    @Test
    fun tooManyParameters_isMalformed() {
        val params = validParams.toMutableMap()
        params["x1"] = "a"
        params["x2"] = "a"
        params["x3"] = "a"
        assertFailure(parseParams(params), PairingError.MALFORMED_PAYLOAD)
    }

    @Test
    fun duplicateParameter_isRejected() {
        val uri = uriFrom(validParams) + "&token=$token"
        assertFailure(PairingPayloadParser.parse(uri), PairingError.DUPLICATE_PARAMETER, "token")
        val encodedDuplicate = uriFrom(validParams) + "&%74oken=$token"
        assertFailure(PairingPayloadParser.parse(encodedDuplicate), PairingError.DUPLICATE_PARAMETER, "token")
    }

    // ---- missing fields ----

    @Test
    fun missingEachRequiredField_isReportedByName() {
        for (key in listOf("v", "sid", "host", "port", "token", "name")) {
            assertFailure(parseParams(validParams - key), PairingError.MISSING_PARAMETER, key)
        }
    }

    // ---- version and identity ----

    @Test
    fun unsupportedOrNonNumericVersion_isRejected() {
        assertFailure(parseWith("v" to "2"), PairingError.UNSUPPORTED_VERSION, "v")
        assertFailure(parseWith("v" to "0"), PairingError.UNSUPPORTED_VERSION, "v")
        assertFailure(parseWith("v" to "one"), PairingError.UNSUPPORTED_VERSION, "v")
    }

    @Test
    fun serverIdHasNoInvented128CharacterLimit() {
        assertEquals("a".repeat(129), assertSuccess(parseWith("sid" to "a".repeat(129))).serverId)
    }

    // ---- host ----

    @Test
    fun invalidIpv4Addresses_areRejected() {
        val invalid = listOf("256.1.1.1", "192.168.1", "192.168.1.1.1", "192.168.01.1", "-1.2.3.4", "example.com", "::1", "192.168.1.")
        for (host in invalid) {
            assertFailure(parseWith("host" to host), PairingError.INVALID_HOST, "host")
        }
    }

    // ---- port ----

    @Test
    fun invalidPorts_areRejected() {
        val invalid = listOf("80", "1023", "65536", "0", "abc", "-8765", "123456", "+8765")
        for (port in invalid) {
            assertFailure(parseWith("port" to port), PairingError.INVALID_PORT, "port")
        }
    }

    // ---- token ----

    @Test
    fun invalidTokens_areRejected() {
        assertFailure(parseWith("token" to "short"), PairingError.INVALID_TOKEN, "token")
        assertFailure(parseWith("token" to "abc!defghijklmnop"), PairingError.INVALID_TOKEN, "token")
        assertFailure(parseWith("token" to "a".repeat(129)), PairingError.INVALID_TOKEN, "token")
    }

    // ---- name ----

    @Test
    fun invalidNames_areRejected() {
        assertFailure(parseWith("name" to "a".repeat(65)), PairingError.INVALID_SERVER_NAME, "name")
        // The server parser accepts non-empty decoded names, even control characters or spaces.
        assertEquals("\n", assertSuccess(parseWith("name" to "%0A")).serverName)
        assertEquals(" ", assertSuccess(parseWith("name" to "%20")).serverName)
    }

    // ---- fingerprint ----

    @Test
    fun invalidFingerprints_areRejected() {
        val invalid = listOf(
            "AB".repeat(32), // uppercase is not what the server emits
            "ab".repeat(31), // 62 chars
            "ab".repeat(33), // 66 chars
            "zz" + "ab".repeat(31), // non-hex
        )
        for (fp in invalid) {
            assertFailure(parseWith("fp" to fp), PairingError.INVALID_FINGERPRINT, "fp")
        }
    }
}
