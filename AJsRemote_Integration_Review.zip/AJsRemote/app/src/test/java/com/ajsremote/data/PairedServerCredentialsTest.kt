package com.ajsremote.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertFalse
import org.junit.Test

class PairedServerCredentialsTest {

    private val secret = "c2VjcmV0LXNlY3JldC1zZWNyZXQtc2VjcmV0LXNlY3JldA"

    private fun sample(fingerprint: String?) = PairedServerCredentials(
        serverId = "ajs-server-01",
        serverName = "Afnan's PC",
        host = "192.168.1.20",
        port = 8765,
        fingerprint = fingerprint,
        deviceId = "0123456789abcdef0123456789abcdef",
        deviceSecret = secret,
    )

    @Test
    fun jsonRoundTrip_withFingerprint() {
        val original = sample("ab".repeat(32))
        assertEquals(original, PairedServerCredentials.fromJson(original.toJson()))
    }

    @Test
    fun jsonRoundTrip_withoutFingerprint_keepsNull() {
        val original = sample(null)
        val restored = PairedServerCredentials.fromJson(original.toJson())
        assertNull(restored.fingerprint)
        assertEquals(original, restored)
    }

    @Test
    fun toString_masksDeviceSecret() {
        val text = sample(null).toString()
        assertFalse(text.contains(secret))
        assertEquals(true, text.contains("deviceSecret=***"))
    }
}
