package com.ajsremote.authentication

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.ajsremote.data.DeviceCredentialStore
import com.ajsremote.pairing.PairingPayload
import com.ajsremote.security.SecretCipher
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.tls.HandshakeCertificates
import okhttp3.tls.HeldCertificate
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.concurrent.atomic.AtomicInteger

/** Active PairingClient over real loopback TLS against a scripted peer, not the Linux server. */
class PairingClientIntegrationTest {
    private class Cipher : SecretCipher {
        override fun encrypt(plaintext: ByteArray) = Base64.getEncoder().encodeToString(plaintext)
        override fun decrypt(payload: String) = Base64.getDecoder().decode(payload)
        override fun deleteKey() = Unit
    }
    @Test fun successfulPairThenReconnectAuthenticatesWithoutReusingToken() = runBlocking {
        val dir = createTempDir(prefix = "ajs-pair-")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val server = MockWebServer()
        val cert = HeldCertificate.Builder().commonName("AJ's Remote Server").build()
        val tls = HandshakeCertificates.Builder().heldCertificate(cert).build()
        server.useHttps(tls.sslSocketFactory(), false)
        val pairs = AtomicInteger()
        val hellos = AtomicInteger()
        val secret = "A".repeat(43)
        fun response(type: String, id: String, payload: JSONObject) = JSONObject()
            .put("v", 1).put("type", type).put("re", id).put("payload", payload).toString()
        fun peer(alreadyPaired: Boolean, challenge: String) = object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                val request = JSONObject(text)
                when (request.getString("type")) {
                    "hello" -> {
                        hellos.incrementAndGet()
                        webSocket.send(response("hello_ack", request.getString("id"), JSONObject()
                            .put("server_id", "server-1").put("server_name", "PC")
                            .put("protocol_version", 1).put("paired", alreadyPaired).put("challenge", challenge)))
                    }
                    "pair_request" -> {
                        pairs.incrementAndGet()
                        val id = request.getString("id")
                        webSocket.send(response("pair_pending", id, JSONObject().put("timeout_seconds", 60)))
                        webSocket.send(response("pair_accepted", id, JSONObject().put("device_secret", secret)))
                    }
                    "auth" -> webSocket.send(response("auth_ok", request.getString("id"), JSONObject()
                        .put("session_id", "session").put("heartbeat_interval_seconds", 10)))
                    "bye" -> webSocket.close(1000, null)
                }
            }
        }
        server.enqueue(MockResponse().withWebSocketUpgrade(peer(false, "A".repeat(43))))
        server.enqueue(MockResponse().withWebSocketUpgrade(peer(true, "B".repeat(43))))
        server.start()
        try {
            val ds = PreferenceDataStoreFactory.create(scope = scope, produceFile = { File(dir, "test.preferences_pb") })
            val store = DeviceCredentialStore(ds, Cipher())
            val pin = MessageDigest.getInstance("SHA-256").digest(cert.certificate.encoded)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
            val qr = PairingPayload(1, "server-1", "127.0.0.1", server.port, "a".repeat(16), "PC", pin)
            val states = Channel<PairingState>(32)
            suspend fun waitConnected() = withTimeout(15000) {
                while (true) { if (states.receive() is PairingState.Connected) break }
            }
            val first = launch { PairingClient(store, qr).run { states.send(it) } }
            waitConnected()
            assertNotNull(store.credentials.first())
            assertNull(store.pendingPairing())
            first.cancelAndJoin()
            val second = launch { PairingClient(store, null).run { states.send(it) } }
            waitConnected()
            assertEquals(1, pairs.get())
            assertEquals(2, hellos.get())
            second.cancelAndJoin()
        } finally { server.shutdown(); scope.cancel(); dir.deleteRecursively() }
    }
}
