package com.ajsremote.gamepad

import okhttp3.Request
import okhttp3.WebSocket
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import okio.ByteString

class GamepadSessionTest {
    private class Socket: WebSocket {
        val frames = mutableListOf<String>()
        var cancelled = false
        override fun request(): Request = Request.Builder().url("https://localhost/").build()
        override fun queueSize(): Long = 0
        override fun send(text: String): Boolean { frames.add(text); return true }
        override fun send(bytes: ByteString): Boolean = false
        override fun close(code: Int, reason: String?): Boolean = true
        override fun cancel() { cancelled = true }
    }
    @Test fun noInputSentBeforeAttachmentOrAfterDetach() {
        val session = GamepadSession(); val socket = Socket()
        session.button("a", true); assertTrue(socket.frames.isEmpty())
        session.attach(socket); val count = socket.frames.size
        session.detach(socket); session.button("a", true)
        assertEquals(count, socket.frames.size)
    }
    @Test fun concurrentHoldsAndNeutralizationReleaseAll() {
        val session = GamepadSession(); val socket = Socket(); session.attach(socket)
        session.button("a", true); session.button("b", true); session.button("a", true)
        session.axis("left_x", 0.5f); session.axis("rt", 1f); session.neutralize()
        val frames = socket.frames.map { JSONObject(it) }
        val buttons = frames.filter { it.getString("type") == "gamepad_button" }
        assertEquals(4, buttons.size)
        assertEquals(2, buttons.count { it.getJSONObject("payload").getString("action") == "down" })
        assertEquals(2, buttons.count { it.getJSONObject("payload").getString("action") == "up" })
        for (axis in listOf("left_x", "rt")) assertTrue(frames.any {
            it.getString("type") == "gamepad_axis" && it.getJSONObject("payload").getString("axis") == axis && it.getJSONObject("payload").getDouble("value") == 0.0
        })
    }
    @Test fun invalidButtonDoesNotBreakSubsequentNeutralization() {
        val session = GamepadSession(); val socket = Socket(); session.attach(socket)
        session.button("a", true)
        org.junit.Assert.assertThrows(IllegalArgumentException::class.java) { session.button("invalid", true) }
        session.neutralize()
        val last = JSONObject(socket.frames.last()).getJSONObject("payload")
        assertEquals("a", last.getString("button"))
        assertEquals("up", last.getString("action"))
    }
    @Test fun oldSocketCannotDetachReplacement() {
        val session = GamepadSession(); val old = Socket(); val next = Socket()
        session.attach(old); session.attach(next); session.detach(old); session.button("a", true)
        assertEquals("gamepad_button", JSONObject(next.frames.last()).getString("type"))
    }
}
