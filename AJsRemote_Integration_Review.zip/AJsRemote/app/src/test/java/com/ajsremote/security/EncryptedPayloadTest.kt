package com.ajsremote.security

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class EncryptedPayloadTest {

    @Test
    fun encodeThenDecode_roundTripsBytes() {
        val original = EncryptedPayload(ByteArray(12) { it.toByte() }, ByteArray(32) { (it * 3).toByte() })
        val decoded = EncryptedPayload.decode(original.encode())
        assertArrayEquals(original.iv, decoded.iv)
        assertArrayEquals(original.ciphertext, decoded.ciphertext)
    }

    @Test
    fun unknownVersionPrefix_isRejected() {
        val encoded = EncryptedPayload(ByteArray(12), ByteArray(16)).encode().replaceFirst("v1", "v2")
        assertThrows(IllegalArgumentException::class.java) { EncryptedPayload.decode(encoded) }
    }

    @Test
    fun wrongPartCount_isRejected() {
        assertThrows(IllegalArgumentException::class.java) { EncryptedPayload.decode("v1:AAAA") }
    }

    @Test
    fun wrongIvLength_isRejected() {
        val encoded = EncryptedPayload(ByteArray(8), ByteArray(16)).encode()
        assertThrows(IllegalArgumentException::class.java) { EncryptedPayload.decode(encoded) }
    }

    @Test
    fun ciphertextWithoutTag_isRejected() {
        val encoded = EncryptedPayload(ByteArray(12), ByteArray(8)).encode()
        assertThrows(IllegalArgumentException::class.java) { EncryptedPayload.decode(encoded) }
    }

    @Test
    fun invalidBase64_isRejected() {
        assertThrows(IllegalArgumentException::class.java) { EncryptedPayload.decode("v1:!!!:!!!") }
    }
}
