package com.ajsremote.scanner

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class ScanGateTest {
    @Test fun acceptsOnlyFirstValueInSession() {
        val gate = ScanGate()
        assertTrue(gate.tryClaim())
        assertFalse(gate.tryClaim())
        assertTrue(ScanGate().tryClaim())
    }

    @Test fun concurrentCallbacksOnlyDeliverOneValue() {
        val gate = ScanGate()
        val pool = Executors.newFixedThreadPool(8)
        val start = CountDownLatch(1)
        val done = CountDownLatch(32)
        val count = AtomicInteger()
        try {
            repeat(32) {
                pool.execute {
                    try { start.await(); if (gate.tryClaim()) count.incrementAndGet() }
                    finally { done.countDown() }
                }
            }
            start.countDown()
            assertTrue(done.await(5, TimeUnit.SECONDS))
            assertEquals(1, count.get())
        } finally { pool.shutdownNow() }
    }
}
