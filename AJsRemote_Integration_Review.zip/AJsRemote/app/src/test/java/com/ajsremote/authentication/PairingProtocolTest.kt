package com.ajsremote.authentication

import com.ajsremote.networking.ProtocolException
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class PairingProtocolTest {
    private fun message(type: String, reply: String, body: JSONObject) = JSONObject()
        .put("v", 1).put("type", type).put("re", reply).put("payload", body).toString()
    @Test fun exactPairRequestAndAuthFields() {
        val request = JSONObject(PairingProtocol.pairRequest("a".repeat(16)))
        assertEquals("pair_request", request.getString("type"))
        assertEquals("a".repeat(16), request.getJSONObject("payload").getString("pairing_token"))
        val auth = JSONObject(PairingProtocol.auth("A".repeat(43)))
        assertEquals("auth", auth.getString("type")); assertEquals("A".repeat(43), auth.getJSONObject("payload").getString("proof"))
    }
    @Test fun handlesApprovalAndAuthResponses() {
        assertEquals(60, PairingProtocol.approvalTimeout(message("pair_pending", "pair-1", JSONObject().put("timeout_seconds", 60))))
        assertEquals("A".repeat(43), PairingProtocol.secret(message("pair_accepted", "pair-1", JSONObject().put("device_secret", "A".repeat(43)))))
        assertEquals(10, PairingProtocol.heartbeat(message("auth_ok", "auth-1", JSONObject().put("session_id", "session").put("heartbeat_interval_seconds", 10))))
    }
    @Test fun serverErrorsMapToFailureStates() {
        assertEquals(PairingState.Expired, pairingErrorState("pairing_token_invalid"))
        assertEquals(PairingState.AuthFailed, pairingErrorState("authentication_failed"))
        assertEquals(PairingState.Failed("Server rejected the request."), pairingErrorState("unknown"))
    }
    @Test fun rejectsErrorWithWrongReplyId() {
        val error = message("error", "other", JSONObject().put("code", "pairing_token_invalid").put("fatal", true))
        assertThrows(ProtocolException::class.java) { PairingProtocol.payload(error, "error", PairingProtocol.PAIR_ID) }
    }
    @Test fun rejectsInvalidAuthenticationAcknowledgements() {
        val body = JSONObject().put("session_id", "session").put("heartbeat_interval_seconds", 0)
        assertThrows(ProtocolException::class.java) { PairingProtocol.heartbeat(message("auth_ok", "auth-1", body)) }
        val validBody = JSONObject().put("session_id", "session").put("heartbeat_interval_seconds", 10)
        assertThrows(ProtocolException::class.java) { PairingProtocol.heartbeat(message("auth_ok", "other", validBody)) }
    }
    @Test fun rejectsWrongReplyAndSecret() {
        assertThrows(ProtocolException::class.java) { PairingProtocol.secret(message("pair_accepted", "other", JSONObject().put("device_secret", "A".repeat(43)))) }
        assertThrows(ProtocolException::class.java) { PairingProtocol.secret(message("pair_accepted", "pair-1", JSONObject().put("device_secret", "bad"))) }
    }
}
