package com.ajsremote.pairing

import org.junit.Assert.assertEquals
import org.junit.Test

class PairingErrorTest {
    @Test
    fun everyErrorHasAUserFacingMessage() {
        for (error in PairingError.values()) {
            assertEquals(true, error.userMessage.isNotBlank())
        }
    }
}
