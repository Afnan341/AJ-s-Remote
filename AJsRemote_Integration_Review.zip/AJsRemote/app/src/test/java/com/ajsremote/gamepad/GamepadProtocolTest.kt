package com.ajsremote.gamepad

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class GamepadProtocolTest {
    @Test fun buttonProducesExactServerMessage() {
        val obj = JSONObject(GamepadProtocol.button("a", true))
        assertEquals(1, obj.getInt("v")); assertEquals("gamepad_button", obj.getString("type"))
        assertEquals("a", obj.getJSONObject("payload").getString("button"))
        assertEquals("down", obj.getJSONObject("payload").getString("action"))
        assertEquals("up", JSONObject(GamepadProtocol.button("a", false)).getJSONObject("payload").getString("action"))
    }
    @Test fun axisProducesExactServerMessage() {
        val obj = JSONObject(GamepadProtocol.axis("left_x", -0.5f))
        assertEquals("gamepad_axis", obj.getString("type"))
        assertEquals("left_x", obj.getJSONObject("payload").getString("axis"))
        assertEquals(-0.5, obj.getJSONObject("payload").getDouble("value"), 0.0)
    }
    @Test fun badValuesAndNamesAreRejected() {
        assertThrows(IllegalArgumentException::class.java) { GamepadProtocol.axis("left_x", Float.NaN) }
        assertThrows(IllegalArgumentException::class.java) { GamepadProtocol.axis("lt", -1f) }
        assertThrows(IllegalArgumentException::class.java) { GamepadProtocol.axis("dpad_x", 0.2f) }
        assertThrows(IllegalArgumentException::class.java) { GamepadProtocol.axis("right_x", 1.1f) }
        assertThrows(IllegalArgumentException::class.java) { GamepadProtocol.button("invented", true) }
    }
}
