package com.ajsremote.authentication

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.ajsremote.data.DeviceCredentialStore
import com.ajsremote.pairing.PairingPayload
import com.ajsremote.security.SecretCipher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.tls.HandshakeCertificates
import okhttp3.tls.HeldCertificate
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.security.MessageDigest
import java.util.Base64
import java.util.Collections

/** Scripted peer, not a real server; no Keystore behavior is tested here. */
class PairingErrorCorrelationTest {
    private class Cipher : SecretCipher {
        override fun encrypt(plaintext: ByteArray) = Base64.getEncoder().encodeToString(plaintext)
        override fun decrypt(payload: String) = Base64.getDecoder().decode(payload)
        override fun deleteKey() = Unit
    }
    @Test fun unrelatedInvalidTokenErrorPreservesRecoveryJournal() = runBlocking {
        val dir = createTempDir(prefix = "ajs-error-")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        val server = MockWebServer()
        val cert = HeldCertificate.Builder().commonName("AJ's Remote Server").build()
        server.useHttps(HandshakeCertificates.Builder().heldCertificate(cert).build().sslSocketFactory(), false)
        val states = Collections.synchronizedList(mutableListOf<PairingState>())
        server.enqueue(MockResponse().withWebSocketUpgrade(object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                val request = JSONObject(text)
                when (request.getString("type")) {
                    "hello" -> webSocket.send(JSONObject().put("v", 1).put("type", "hello_ack")
                        .put("re", request.getString("id")).put("payload", JSONObject()
                            .put("server_id", "correlation-pc").put("server_name", "PC")
                            .put("protocol_version", 1).put("paired", false).put("challenge", "A".repeat(43))).toString())
                    "pair_request" -> webSocket.send(JSONObject().put("v", 1).put("type", "error")
                        .put("re", "wrong-request").put("payload", JSONObject()
                            .put("code", "pairing_token_invalid").put("fatal", true).put("message", "invalid")) .toString())
                }
            }
        }))
        server.start()
        try {
            val dataStore = PreferenceDataStoreFactory.create(scope = scope, produceFile = { File(dir, "store.preferences_pb") })
            val store = DeviceCredentialStore(dataStore, Cipher())
            val pin = MessageDigest.getInstance("SHA-256").digest(cert.certificate.encoded)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
            val qr = PairingPayload(1, "correlation-pc", "127.0.0.1", server.port, "a".repeat(16), "PC", pin)
            val job = launch { PairingClient(store, qr).run { states.add(it) } }
            withTimeout(15000) { job.join() }
            assertEquals("correlation-pc", store.pendingPairing())
            assertTrue(states.any { it is PairingState.RecoveryNeeded })
            assertFalse(states.any { it is PairingState.Connected || it == PairingState.Expired })
        } finally { server.shutdown(); scope.cancel(); dir.deleteRecursively() }
    }
}
