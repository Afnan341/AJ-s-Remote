package com.ajsremote.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.ajsremote.security.SecretCipher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Test
import java.io.File
import java.util.Base64

/** Repository behavior with a reversible test double, not a Keystore security test. */
class DeviceCredentialStoreTest {
    private class TestCipher : SecretCipher {
        override fun encrypt(plaintext: ByteArray) = "test:" + Base64.getEncoder().encodeToString(plaintext)
        override fun decrypt(payload: String) = Base64.getDecoder().decode(payload.removePrefix("test:"))
        override fun deleteKey() = Unit
    }
    @Test fun savesLoadsAndClearsWhileKeepingDeviceId() = runBlocking {
        val dir = createTempDir(prefix = "ajs-store-")
        val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
        try {
            val file = File(dir, "test.preferences_pb")
            val dataStore = PreferenceDataStoreFactory.create(scope = scope, produceFile = { file })
            val store = DeviceCredentialStore(dataStore, TestCipher())
            val id = store.deviceId()
            val secret = "A".repeat(43)
            val record = PairedServerCredentials("server", "PC", "192.168.1.2", 8765, "a".repeat(64), id, secret)
            store.save(record)
            assertEquals(record, store.credentials.first())
            assertFalse(file.readBytes().toString(Charsets.ISO_8859_1).contains(secret))
            store.clear()
            assertNull(store.credentials.first())
            assertEquals(id, store.deviceId())
        } finally { scope.cancel(); dir.deleteRecursively() }
    }
}
