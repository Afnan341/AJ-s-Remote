package com.ajsremote.networking

import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.security.MessageDigest
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

class CertificatePinTest {
    private fun cert(name: String): X509Certificate = javaClass.getResourceAsStream("/$name.der")!!.use {
        CertificateFactory.getInstance("X.509").generateCertificate(it) as X509Certificate
    }
    private fun fingerprint(cert: X509Certificate): String = MessageDigest.getInstance("SHA-256")
        .digest(cert.encoded).joinToString("") { "%02x".format(it.toInt() and 0xff) }

    @Test fun matchingDerCertificateAcceptedAndDifferentRejected() {
        val first = cert("server1")
        val second = cert("server2")
        val pin = CertificatePin(fingerprint(first))
        assertTrue(pin.matches(first))
        assertFalse(pin.matches(second))
        val manager = PinnedTrustManager(pin)
        manager.checkServerTrusted(arrayOf(first), "EC")
        assertThrows(CertificateException::class.java) { manager.checkServerTrusted(arrayOf(second), "EC") }
    }
    @Test fun emptyChainAndClientTrustAreRejected() {
        val manager = PinnedTrustManager(CertificatePin(fingerprint(cert("server1"))))
        assertThrows(CertificateException::class.java) { manager.checkServerTrusted(emptyArray(), "EC") }
        assertThrows(CertificateException::class.java) { manager.checkClientTrusted(arrayOf(cert("server1")), "EC") }
    }
    @Test fun malformedFingerprintIsRejected() {
        assertThrows(IllegalArgumentException::class.java) { CertificatePin("A".repeat(64)) }
        assertThrows(IllegalArgumentException::class.java) { CertificatePin("abc") }
    }
}
