package com.ajsremote.authentication

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ConnectionLeaseTest {
    @Test fun concurrentAttemptsAreRejectedAndCancellationReleasesLease() = runBlocking {
        val started = CompletableDeferred<Unit>()
        val keepOpen = CompletableDeferred<Unit>()
        val job = launch { ConnectionLease.run({}, { started.complete(Unit); keepOpen.await() }) }
        started.await()
        var rejected = false; var startedTwice = false
        ConnectionLease.run({ rejected = true }, { startedTwice = true })
        assertTrue(rejected); assertFalse(startedTwice)
        job.cancelAndJoin()
        var resumed = false
        ConnectionLease.run({}, { resumed = true })
        assertTrue(resumed)
    }
}
