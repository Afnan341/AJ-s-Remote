"""Exercise original Python server with a recording fake backend; never runs Kotlin or Android."""
from pathlib import Path
import json,os,re,sys,unittest
r=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(Path(os.environ.get('AJS_SERVER_DIR','../ajs_remote_server')).resolve()))
from ajs_server.protocol.validators import decode_client_message
from ajs_server.protocol.messages import ProtocolError
from ajs_server.input.input_manager import InputManager
from ajs_server.input.fake import FakeFactory
from ajs_server.input.codes import EV_ABS,EV_KEY,GAMEPAD_BUTTONS,GAMEPAD_AXES
class Tests(unittest.TestCase):
 def setUp(self):
  self.factory=FakeFactory();self.manager=InputManager(self.factory)
 def send(self,t,p):
  e=decode_client_message(json.dumps({'v':1,'type':t,'payload':p}));self.manager.handle('device',e)
 def test_all_button_mappings_down_up(self):
  for button in ('a','b','x','y','lb','rb','back','start'):
   self.send('gamepad_button',{'button':button,'action':'down'});self.send('gamepad_button',{'button':button,'action':'up'})
  dev=self.factory.by_name('gamepad')[0]
  for b in ('a','b','x','y','lb','rb','back','start'):
   self.assertIn((EV_KEY,GAMEPAD_BUTTONS[b],1),dev.events);self.assertIn((EV_KEY,GAMEPAD_BUTTONS[b],0),dev.events)
 def test_axis_endpoints_and_neutral(self):
  for axis in ('left_x','left_y','right_x','right_y','lt','rt','dpad_x','dpad_y'):
   self.send('gamepad_axis',{'axis':axis,'value':1});self.send('gamepad_axis',{'axis':axis,'value':0})
  dev=self.factory.by_name('gamepad')[0]
  for axis in ('left_x','left_y','right_x','right_y','lt','rt','dpad_x','dpad_y'):
   code,_,maximum=GAMEPAD_AXES[axis];self.assertIn((EV_ABS,code,maximum),dev.events);self.assertIn((EV_ABS,code,0),dev.events)
 def test_concurrent_holds_and_disconnect(self):
  for b in ('a','b'): self.send('gamepad_button',{'button':b,'action':'down'})
  self.send('gamepad_axis',{'axis':'left_x','value':-1})
  dev=self.factory.by_name('gamepad')[0];self.manager.device_disconnected('device')
  for b in ('a','b'): self.assertIn((EV_KEY,GAMEPAD_BUTTONS[b],0),dev.events)
  self.assertIn((EV_ABS,GAMEPAD_AXES['left_x'][0],0),dev.events);self.assertTrue(dev.closed)
 def test_invalid_input(self):
  for axis,value in [('lt',-1),('rt',-0.5),('left_x',2),('left_x',float('nan'))]:
   with self.subTest(axis=axis,value=value),self.assertRaises(ProtocolError): self.send('gamepad_axis',{'axis':axis,'value':value})
 def test_source_flow_markers(self):
  ui=(r/'app/src/main/java/com/ajsremote/gamepad/ControllerScreen.kt').read_text()
  client=(r/'app/src/main/java/com/ajsremote/authentication/PairingClient.kt').read_text()
  screen=(r/'app/src/main/java/com/ajsremote/ui/ConnectionScreen.kt').read_text()
  for s in ('"lb"','"rb"','"lt"','"rt"','"dpad_x"','"dpad_y"','"back"','"start"'):self.assertIn(s,ui)
  self.assertIn('ControllerScreen(gamepad',screen);self.assertLess(client.index('PairingProtocol.heartbeat(auth)'),client.index('gamepad?.attach(ws)'))
  self.assertIn('finally { position = Offset.Zero',ui);self.assertIn('session.neutralize()',ui)
if __name__=='__main__':unittest.main(verbosity=2)
