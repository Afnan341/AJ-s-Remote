"""Heuristic source checks only. Not a Kotlin compiler, Gradle resolver or Android test."""
from pathlib import Path
import re, tomllib, unittest, xml.etree.ElementTree as ET
R=Path(__file__).resolve().parent.parent
FILES=list((R/'app/src').rglob('*.kt'))
class Checks(unittest.TestCase):
 def test_package_paths(self):
  for p in FILES:
   text=p.read_text(encoding='utf8'); match=re.search(r'^package\s+([\w.]+)',text,re.M)
   with self.subTest(file=str(p)):
    self.assertIsNotNone(match); self.assertTrue(str(p.parent).endswith(match.group(1).replace('.','/')))
 def test_local_imports_have_obvious_declarations(self):
  declarations=set()
  for p in FILES:
   text=p.read_text(encoding='utf8'); match=re.search(r'^package\s+([\w.]+)',text,re.M)
   if not match: continue
   for obj in re.finditer(r'(?m)^(?:public\s+|internal\s+|private\s+|sealed\s+|data\s+|abstract\s+)*(?:class|object|interface|enum\s+class|fun|val)\s+([A-Za-z_]\w*)',text):
    declarations.add(match.group(1)+'.'+obj.group(1))
  for p in FILES:
   for name in re.findall(r'^import\s+(com\.ajsremote\.[\w.]+)',p.read_text(),re.M):
    with self.subTest(file=str(p),name=name): self.assertTrue(any(name==d or name.startswith(d+'.') for d in declarations))
 def test_declared_gradle_aliases(self):
  with (R/'gradle/libs.versions.toml').open('rb') as f: data=tomllib.load(f)
  scripts='\n'.join((R/p).read_text() for p in ['build.gradle.kts','app/build.gradle.kts'])
  for found in re.findall(r'libs\.plugins\.([\w.]+)',scripts): self.assertIn(found.replace('.','-'),data['plugins'])
  clean=re.sub(r'libs\.plugins\.[\w.]+','',scripts)
  for found in re.findall(r'libs\.([\w.]+)',clean): self.assertIn(found.replace('.','-'),data['libraries'])
 def test_active_pipeline_and_diagnostic(self):
  def text(p): return (R/p).read_text()
  self.assertIn('RemoteApp()',text('app/src/main/java/com/ajsremote/MainActivity.kt'))
  ui=text('app/src/main/java/com/ajsremote/ui/RemoteApp.kt')
  for x in ('ScannerScreen(', 'PairingPayloadParser.parse(raw)', 'ConnectionScreen('): self.assertIn(x,ui)
  self.assertIn('PairingClient(',text('app/src/main/java/com/ajsremote/ui/ConnectionScreen.kt'))
  self.assertIn('internal class ServerConnection',text('app/src/main/java/com/ajsremote/networking/ServerConnection.kt'))
 def test_recovery_and_error_correlation_markers(self):
  s=(R/'app/src/main/java/com/ajsremote/authentication/PairingClient.kt').read_text()
  for x in ('store.pendingPairing()', 'store.beginPairing(serverId)', 'store.completePairing(newCredentials)', 'PairingProtocol.payload(text, "error", expectedForCode)', 'update(PairingState.Connected'): self.assertIn(x,s)
  self.assertLess(s.index('store.completePairing(newCredentials)'),s.index('PairingProtocol.auth('))
  self.assertLess(s.index('PairingProtocol.heartbeat(auth)'),s.index('update(PairingState.Connected'))
 def test_manifest(self):
  root=ET.parse(R/'app/src/main/AndroidManifest.xml').getroot(); ns='{http://schemas.android.com/apk/res/android}'
  app=root.find('application'); self.assertEqual('false',app.get(ns+'allowBackup')); self.assertEqual('false',app.get(ns+'usesCleartextTraffic'))
  permissions={p.get(ns+'name') for p in root.findall('uses-permission')}; self.assertTrue({'android.permission.CAMERA','android.permission.INTERNET'}.issubset(permissions))
if __name__=='__main__': unittest.main(verbosity=2)
