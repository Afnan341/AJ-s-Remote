"""Source-level checks plus a Python-server HMAC vector; not Kotlin execution or an Android test."""
from pathlib import Path
import os, sys, unittest
r=Path(__file__).resolve().parent.parent
server=Path(os.environ.get('AJS_SERVER_DIR','../ajs_remote_server')).resolve()
sys.path.insert(0,str(server))
from ajs_server.security.authentication import derive_key, compute_proof, verify_proof
class Checks(unittest.TestCase):
 def read(self,p): return (r/p).read_text(encoding='utf8')
 def test_server_vector(self):
  secret='AAECAwQFBgcICQoLDA0ODxAREhMUFRYXGBkaGxwdHh8'; challenge='ICEiIyQlJicoKSorLC0uLzAxMjM0NTY3ODk6Ozw9Pj8'; device='0123456789abcdef0123456789abcdef'; proof='8CNXhJEx1_87ZLmkQ5GTYrLVjaXsIAbnsmEldyhg4uQ'
  key=derive_key(secret); self.assertEqual(proof,compute_proof(key,challenge,device));self.assertTrue(verify_proof(key,challenge,device,proof));self.assertFalse(verify_proof(key,challenge+'x',device,proof))
 def test_tls_guard_and_no_token_retry(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  for x in ('if (pin == null)', 'onSubmitted()', 'tokenSubmitted && !pairingSaved', 'sslSocketFactory(context.socketFactory, trust)', 'pin.matches(leaf)'): self.assertIn(x,s)
 def test_success_requires_auth_ack(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  self.assertGreater(s.index('update(PairingState.Connected'),s.index('PairingProtocol.heartbeat(auth)'))
  self.assertGreater(s.index('update(PairingState.Connected'),s.index('PairingProtocol.auth('))
 def test_secret_saved_before_authentication(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  self.assertLess(s.index('store.completePairing(newCredentials)'),s.index('PairingProtocol.auth('))
 def test_no_direct_secret_logging(self):
  for name in ('AuthenticationProof.kt','PairingProtocol.kt','PairingClient.kt'):
   s=self.read('app/src/main/java/com/ajsremote/authentication/'+name)
   for bad in ('println(', 'Log.', 'printStackTrace('): self.assertNotIn(bad,s)
 def test_expected_test_sources_exist(self):
  for p in ('app/src/test/java/com/ajsremote/authentication/AuthenticationProofTest.kt','app/src/test/java/com/ajsremote/authentication/PairingProtocolTest.kt','app/src/test/java/com/ajsremote/data/DeviceCredentialStoreTest.kt'):
   self.assertTrue((r/p).is_file())
if __name__=='__main__': unittest.main(verbosity=2)
