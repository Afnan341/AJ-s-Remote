"""Structural checks only. This does not compile Kotlin or emulate Android."""
import pathlib, tomllib, unittest, xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent.parent
class SourceChecks(unittest.TestCase):
 def read(self,p): return (root/p).read_text(encoding='utf-8')
 def test_catalog_and_dependencies(self):
  d=tomllib.loads(self.read('gradle/libs.versions.toml'))
  for key in ('androidx-camera-core','androidx-camera-camera2','androidx-camera-lifecycle','androidx-camera-view','mlkit-barcode-scanning','androidx-lifecycle-runtime-compose'):
   self.assertIn(key,d['libraries'])
  self.assertIn('libs.androidx.lifecycle.runtime.compose',self.read('app/build.gradle.kts'))
 def test_camera_permission_and_backup_setting(self):
  ns='{http://schemas.android.com/apk/res/android}'
  doc=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
  self.assertIn('android.permission.CAMERA',{e.get(ns+'name') for e in doc.findall('uses-permission')})
  self.assertEqual('false',doc.find('application').get(ns+'allowBackup'))
 def test_entry_and_qr_pipeline_wiring(self):
  self.assertIn('RemoteApp()',self.read('app/src/main/java/com/ajsremote/MainActivity.kt'))
  ui=self.read('app/src/main/java/com/ajsremote/ui/RemoteApp.kt')
  self.assertIn('PairingPayloadParser.parse(raw)',ui)
  self.assertIn('Not connected',ui)
  session=self.read('app/src/main/java/com/ajsremote/scanner/QrCameraSession.kt')
  for marker in ('FORMAT_QR_CODE','STRATEGY_KEEP_ONLY_LATEST','bindToLifecycle','proxy.close()', 'gate.tryClaim()', 'scanner.close()'):
   self.assertIn(marker,session)
 def test_scan_gate_is_atomic(self):
  self.assertIn('compareAndSet(false, true)',self.read('app/src/main/java/com/ajsremote/scanner/ScanGate.kt'))
 def test_fixtures_and_duplicate_tests_exist(self):
  self.assertIn('canonicalServerUriIsParsed',self.read('app/src/test/java/com/ajsremote/pairing/ServerGeneratedQrTest.kt'))
  self.assertIn('concurrentCallbacksOnlyDeliverOneValue',self.read('app/src/test/java/com/ajsremote/scanner/ScanGateTest.kt'))
if __name__=='__main__': unittest.main(verbosity=2)
