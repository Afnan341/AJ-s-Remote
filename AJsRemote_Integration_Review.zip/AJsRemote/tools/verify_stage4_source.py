"""Static structural checks, not Kotlin tests or a live networking/security audit."""
from pathlib import Path
import unittest, tomllib, xml.etree.ElementTree as ET
r=Path(__file__).resolve().parent.parent
class Check(unittest.TestCase):
 def read(self,s): return (r/s).read_text(encoding='utf-8')
 def test_matching_pin_and_rejecting_client_cert_present(self):
  s=self.read('app/src/main/java/com/ajsremote/networking/CertificatePin.kt')
  for x in ('MessageDigest.isEqual','certificate.checkValidity()','certificate.verify(certificate.publicKey)','throw CertificateException','chain[0]'): self.assertIn(x,s)
 def test_hostname_verifier_has_host_and_pin_conditions(self):
  s=self.read('app/src/main/java/com/ajsremote/networking/ServerConnection.kt')
  self.assertIn('host == qr.host && try',s); self.assertIn('pin.matches(leaf)',s)
  self.assertIn('allowUnencrypted: Boolean = false',s)
 def test_hello_and_protocol_fields_present(self):
  s=self.read('app/src/main/java/com/ajsremote/networking/HelloProtocol.kt')
  for x in ('hello_ack','device_id','device_name','protocol_version','challenge','expectedServerId'): self.assertIn(x,s)
 def test_ui_does_not_claim_pairing(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  self.assertIn('PairingProtocol.heartbeat(auth)',s); self.assertGreater(s.index('update(PairingState.Connected'),s.index('PairingProtocol.heartbeat(auth)'))
 def test_test_dependencies(self):
  c=tomllib.loads(self.read('gradle/libs.versions.toml'));self.assertIn('mockwebserver',c['libraries'])
  for p in ('CertificatePinTest.kt','HelloProtocolTest.kt','ServerConnectionTest.kt'):
   self.assertTrue((r/'app/src/test/java/com/ajsremote/networking'/p).exists())
if __name__=='__main__': unittest.main(verbosity=2)
