import os, sys, types, pathlib, tomllib, unittest, xml.etree.ElementTree as ET
root=pathlib.Path(__file__).resolve().parent.parent
server=pathlib.Path(os.environ.get('AJS_SERVER_DIR', '../ajs_remote_server')).resolve()
# QR rendering dependency is unavailable; URI construction/parsing do not use it.
qrcode=types.ModuleType('qrcode'); constants=types.ModuleType('qrcode.constants'); constants.ERROR_CORRECT_M=0
sys.modules['qrcode']=qrcode; sys.modules['qrcode.constants']=constants
sys.path.insert(0,str(server))
from ajs_server.qr.generator import PairingInfo, build_pairing_uri, parse_pairing_uri, InvalidPairingUri
class Checks(unittest.TestCase):
 def test_all_xml_well_formed(self):
  paths=list(root.glob('app/src/main/**/*.xml')); self.assertGreaterEqual(len(paths),4)
  for path in paths:
   with self.subTest(path=path.name): ET.parse(path)
 def test_catalog_toml(self):
  data=tomllib.loads((root/'gradle/libs.versions.toml').read_text()); self.assertIn('mlkit-barcode-scanning',data['libraries'])
 def test_server_pairing_qr_with_tls(self):
  info=PairingInfo(1,'server-id','192.168.1.20',8765,'AbC_123-defGHIjk',"Afnan's PC",'ab'*32)
  self.assertEqual(parse_pairing_uri(build_pairing_uri(info)),info)
 def test_server_pairing_qr_without_tls(self):
  info=PairingInfo(1,'server-id','192.168.1.20',8765,'AbC_123-defGHIjk','Café','')
  self.assertEqual(parse_pairing_uri(build_pairing_uri(info)),info)
 def test_server_rejects_invalid_token(self):
  info=PairingInfo(1,'server-id','192.168.1.20',8765,'short','PC','')
  with self.assertRaises(InvalidPairingUri): parse_pairing_uri(build_pairing_uri(info))
 def test_server_rejects_invalid_fingerprint(self):
  info=PairingInfo(1,'server-id','192.168.1.20',8765,'AbC_123-defGHIjk','PC','AB'*32)
  with self.assertRaises(InvalidPairingUri): parse_pairing_uri(build_pairing_uri(info))
 def test_server_rejects_missing_field(self):
  with self.assertRaises(InvalidPairingUri): parse_pairing_uri('ajsremote://pair?v=1')
 def test_server_rejects_duplicate_required_field(self):
  info=PairingInfo(1,'server-id','192.168.1.20',8765,'AbC_123-defGHIjk','PC','')
  with self.assertRaises(InvalidPairingUri): parse_pairing_uri(build_pairing_uri(info)+'&v=1')
 def test_manifest_declares_required_permissions(self):
  tree=ET.parse(root/'app/src/main/AndroidManifest.xml'); ns='{http://schemas.android.com/apk/res/android}'
  perms={x.attrib[ns+'name'] for x in tree.findall('uses-permission')}
  self.assertTrue({'android.permission.CAMERA','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'} <= perms)
if __name__=='__main__': unittest.main(verbosity=2)
