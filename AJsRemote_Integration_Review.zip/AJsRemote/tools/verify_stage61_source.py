"""Static invariants only: not Android/Kotlin execution or an integration test."""
import pathlib, unittest
r=pathlib.Path(__file__).resolve().parent.parent
class Checks(unittest.TestCase):
 def read(self,p): return (r/p).read_text(encoding='utf-8')
 def test_journal_precedes_request(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  send=s.index('ws.send(PairingProtocol.pairRequest(token))')
  self.assertLess(s.rindex('store.beginPairing(serverId)',0,send),send)
 def test_saved_secret_and_journal_removal_same_edit(self):
  s=self.read('app/src/main/java/com/ajsremote/data/DeviceCredentialStore.kt')
  start=s.index('suspend fun completePairing'); end=s.index('suspend fun clearPendingPairing',start)
  part=s[start:end]; self.assertIn('prefs[CREDENTIALS_KEY] = encrypted',part); self.assertIn('prefs.remove(PAIRING_IN_PROGRESS)',part)
 def test_active_path_uses_lease_and_recovery(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  for x in ('ConnectionLease.run','store.pendingPairing()','ack.paired','PairingState.RecoveryNeeded','store.completePairing(newCredentials)'): self.assertIn(x,s)
 def test_user_acknowledgement_is_required(self):
  s=self.read('app/src/main/java/com/ajsremote/ui/ConnectionScreen.kt')
  self.assertIn('I checked the PC',s); self.assertIn('This app cannot verify',s); self.assertIn('store.clearPendingPairing',s)
 def test_auth_ack_precedes_connected(self):
  s=self.read('app/src/main/java/com/ajsremote/authentication/PairingClient.kt')
  self.assertLess(s.index('PairingProtocol.heartbeat(auth)'),s.index('update(PairingState.Connected'))
 def test_legacy_diagnostic_is_not_ui_path(self):
  s=self.read('app/src/main/java/com/ajsremote/networking/ServerConnection.kt');self.assertIn('internal class ServerConnection',s)
  ui=self.read('app/src/main/java/com/ajsremote/ui/ConnectionScreen.kt');self.assertIn('PairingClient(',ui);self.assertNotIn('ServerConnection(',ui)
if __name__=='__main__': unittest.main(verbosity=2)
