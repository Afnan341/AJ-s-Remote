# AJ's Remote: Android project (current source handoff)

**Status: uncompiled and unverified.** This archive adds native controller source to the saved Stage 6.2 project. It is not a demonstrated working Android app. No APK, Android build, JUnit execution or real-device/server run was possible. Trusted Gradle wrapper scripts and JAR are missing; see build instructions below and `docs/Stage7_Controller_Progress.md`. The historical Stage 2 notes following this section describe earlier project status and are superseded by this notice.

## Build in Android Studio

1. On a trusted internet-connected machine install JDK 17, Android Studio, Android SDK Platform 35 and compatible build tools, and verified Gradle 8.9. Official checksum guidance: https://docs.gradle.org/current/userguide/best_practices_security.html and https://gradle.org/release-checksums/.
2. Open the extracted `AJsRemote` project directory. Generate the missing wrapper with a trusted Gradle install: `gradle wrapper --gradle-version 8.9 --distribution-type bin`. Verify the wrapper JAR against the official wrapper checksum, verify the Gradle 8.9 binary distribution separately, and add its official `distributionSha256Sum` to `gradle/wrapper/gradle-wrapper.properties`. This archive includes only wrapper properties, not `gradlew`, `gradlew.bat`, or the JAR.
3. Use JDK 17 in Android Studio and sync dependencies. Run `./gradlew :app:testDebugUnitTest :app:assembleDebug` (Windows: `gradlew.bat :app:testDebugUnitTest :app:assembleDebug`). Fix and report actual build/test failures. If successful, install the generated debug APK from `app/build/outputs/apk/debug/` onto the phone.

## Connect to the existing PC server

1. Start the existing AJ's Remote Server on Linux Mint. Keep TLS enabled, ensure the phone and PC can reach each other on the LAN, and open the server Pairing page. Do not use dry-run when expecting real game input. Confirm the dashboard's input access is ready and gamepad input is enabled. The server's own README and hardware-testing documentation describe `/dev/uinput` permissions.
2. Launch the phone app, tap **Connect to PC**, grant camera permission and scan the trusted PC's QR. Tap **Pair with PC**, then approve the prompt on that PC. The app is intended to display the controller only after server `auth_ok`. Scan only your own PC's QR; this is the trust bootstrap for its certificate fingerprint.
3. Test controller input in a Linux gamepad tester or Steam Input. Inputs use the server's existing virtual Xbox-style gamepad. An `input_disabled` response causes a warning and stops controller input; enable input on the PC, then disconnect and reconnect. `Reconnect saved PC` uses the stored PC address and fingerprint; if the address changes, scan a fresh QR.
4. If pairing was interrupted, resolve any pending PC prompt and remove the phone from the PC Devices list if present before acknowledging recovery and scanning a new QR. The phone cannot remotely confirm removal or retrieve a lost one-time secret.

## Controller status and limitations

Controller source has two sticks, D-pad, A/B/X/Y, L1/R1, L2/R2, Start and Select, designed for simultaneous touches. Layout customization currently means a persisted **swap sticks** option only, not free repositioning. L2/R2 are digital touch pads sending 0 or 1, not variable-pressure triggers. The server has no rumble/force feedback support. Layout on Vivo Y21, multitouch behavior, held-input release, `/dev/uinput`, performance and compatibility with games are not verified. No keyboard, mouse, file transfer or streaming UI is added. See the progress report for the precise validation results and remaining work.

---

# AJ's Remote: Android client, Stage 2 foundation

Native Kotlin and Jetpack Compose project targeting Android 8.0+ (API 26+). Stage 2 contains the project setup, static launch screen, QR payload parser, and encrypted credential-storage foundation. It does not scan QR codes, connect to a server, perform pairing/authentication, or control games yet. No PIN has been implemented.

## Files and architecture

- `app/src/main/java/com/ajsremote/ui/`: launch screen and theme.
- `pairing/`: pure Kotlin QR payload model and parser.
- `security/`: Keystore AES-GCM cipher and encrypted value format.
- `data/`: Preferences DataStore repository for device ID and encrypted single-server credentials.
- `app/src/test/`: parser, serialization and crypto-format unit tests.
- `docs/Stage1_Compatibility_Report.md`: unchanged copy of the Stage 1 report.
- `docs/Stage2_Progress.md`: status, checks, limitations and next steps.

Empty scanner, networking and authentication package directories are reserved for later stages and do not contain implementations.

## Build setup (not verified here)

Install Android Studio with Android SDK Platform 35, JDK 17 and Gradle 8.9. This archive does **not** include `gradlew`, `gradlew.bat` or `gradle-wrapper.jar`: they could not be generated in the sandbox. `gradle/wrapper/gradle-wrapper.properties` pins the intended distribution, but is not a functional wrapper by itself. From the project root, use a trusted local Gradle 8.9 installation:

```sh
gradle wrapper --gradle-version 8.9 --distribution-type bin
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

Gradle must download the Android Gradle Plugin and dependencies on first use. Open this project directory in Android Studio, let it sync, then run the same tests and a debug build. Review and verify the wrapper files generated from a trusted Gradle installation before committing them. A successful build and device test have not been established.

## Storage and security design

`DeviceCredentialStore` atomically maintains an installation-specific ID. `PairedServerCredentials` (including the secret and TLS certificate fingerprint) is JSON-serialized, then encrypted using AES-256-GCM with a random IV and Android Keystore key; only ciphertext is written to Preferences DataStore. Backup is disabled, so encrypted data does not migrate without its Keystore key. The token is not stored. This is application-layer encryption on top of Preferences DataStore, not an AndroidX encrypted DataStore implementation. Keystore hardware backing depends on the device.

The current `clear()` removes the encrypted credentials but retains the Keystore key and device ID. Retaining the key avoids races with active readers and other stores; no secure-erasure guarantee is made for DataStore historical blocks. Corruption and decryption errors propagate to callers rather than presenting an unauthenticated state as normal. Unit tests for Android Keystore require a real device or emulator and remain outstanding.

Never log QR strings, credentials or serialized JSON. Scanned fingerprints will be used as certificate pins in the later transport stage; storage by itself does not establish trust or secure a socket.

## Protocol caveats

The parser targets QR codes produced by the server's generator and validates required fields, IPv4, port range, token, protocol version and optional fingerprint. It deliberately rejects duplicate unknown fields, raw non-ASCII/whitespace, malformed UTF-8/percent escapes and oversized raw inputs (16,384 characters). The server parser is more permissive on some malformed input and Python integer spellings; the client rejects those rather than attempting to match every malformed representation. Server-generated canonical QR codes are the compatibility target. The parser's behavior has not yet been run on Android or tested by executing Kotlin in this environment.

Stage 1 describes plain WebSocket as allowed when the QR has no fingerprint. Android blocks cleartext by default for this target; that mode will require an explicit security-policy decision and a user warning in the networking stage. It is not enabled in the foundation. Stage 1 also describes TLS pinning conceptually; implement the actual pinned-certificate trust and IP identity policy carefully, without a trust-all fallback, and test both matching and wrong pins against the real server. This foundation implements neither transport nor pinning.
