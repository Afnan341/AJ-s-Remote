"""
AJS Remote Server 2.0 - Main Application Entry Point
Supports PySide6 desktop GUI, headless mode, diagnostics, and test client.
"""

import argparse
import asyncio
import os
import signal
import sys
import threading
from ajs_server.config import APP_DISPLAY_NAME, DEFAULT_PORT, DEFAULT_HOST
from ajs_server.logger import logger
from ajs_server.websocket_server import AjsWebSocketServer
from ajs_server.database import db
from ajs_server.auth import auth_manager
from ajs_server.qr_generator import build_qr_payload, generate_ascii_qr, get_local_ip
from ajs_server.diagnostics import run_all_diagnostics

def setup_signal_handlers(loop, server):
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, lambda: asyncio.create_task(server.stop()))
        except (NotImplementedError, RuntimeError):
            # On platforms where add_signal_handler is not implemented
            pass

def run_headless_server(host: str, port: int):
    """Runs the server in headless terminal mode."""
    print("=" * 65)
    print(f"  {APP_DISPLAY_NAME} - Headless Daemon Mode")
    print("=" * 65)

    local_ip = get_local_ip()
    pin = auth_manager.get_current_pin()
    qr_payload = build_qr_payload(server_ip=local_ip, port=port)

    print(f"\n[SERVER READY]")
    print(f"  Host:        {host}")
    print(f"  Port:        {port}")
    print(f"  Local IP:    {local_ip}")
    print(f"  Pairing PIN: {pin} (valid for 5 minutes)")
    print(f"  WebSocket:   ws://{local_ip}:{port}")

    print("\n[AJ'S REMOTE CONNECTION QR CODE]:")
    try:
        print(generate_ascii_qr(qr_payload))
    except Exception:
        print(f"  QR Payload: {qr_payload}")

    print("-" * 65)
    print("Listening for AJ's Remote Android connections... Press Ctrl+C to stop.")

    server = AjsWebSocketServer(host=host, port=port)
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    setup_signal_handlers(loop, server)

    try:
        loop.run_until_complete(server.start())
        loop.run_forever()
    except (KeyboardInterrupt, SystemExit):
        pass
    finally:
        loop.run_until_complete(server.stop())
        loop.close()
        print("\nAJS Remote Server stopped cleanly.")

def main():
    parser = argparse.ArgumentParser(description=f"{APP_DISPLAY_NAME} - Linux Gamepad & Remote Companion")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"WebSocket port (default: {DEFAULT_PORT})")
    parser.add_argument("--host", type=str, default=DEFAULT_HOST, help=f"Host address (default: {DEFAULT_HOST})")
    parser.add_argument("--headless", action="store_true", help="Run without graphical user interface")
    parser.add_argument("--diagnostics", action="store_true", help="Run system diagnostics and exit")
    parser.add_argument("--version", action="version", version=f"{APP_DISPLAY_NAME} v2.0.0")

    args = parser.parse_args()

    if args.diagnostics:
        from ajs_server.diagnostics import run_all_diagnostics
        results = run_all_diagnostics(port=args.port)
        for r in results:
            print(f"[{r['status']}] {r['name']}: {r['details']}")
            if r.get('action'):
                print(f"   Action: {r['action']}")
        sys.exit(0)

    # Check DISPLAY environment for GUI vs Headless
    has_display = bool(os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"))
    should_run_headless = args.headless or not has_display

    if should_run_headless:
        run_headless_server(args.host, args.port)
    else:
        # GUI mode with async server running in background thread
        from ajs_server.gui import launch_desktop_gui
        server = AjsWebSocketServer(host=args.host, port=args.port)

        def server_thread_target():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            loop.run_until_complete(server.start())
            loop.run_forever()

        t = threading.Thread(target=server_thread_target, daemon=True)
        t.start()

        launch_desktop_gui(server)

if __name__ == "__main__":
    main()
