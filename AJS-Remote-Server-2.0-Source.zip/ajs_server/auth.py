"""
AJS Remote Server 2.0 - Authentication & Security Engine
Manages 6-digit pairing PINs, crypto session tokens, rate limiting, and access control.
"""

import secrets
import time
from typing import Dict, Any, Optional, Tuple
from ajs_server.config import PIN_LENGTH, PIN_VALIDITY_SECONDS, MAX_AUTH_ATTEMPTS, AUTH_LOCKOUT_SECONDS
from ajs_server.database import db
from ajs_server.logger import logger

class AuthManager:
    def __init__(self):
        self._current_pin: Optional[str] = None
        self._pin_created_at: float = 0.0
        self._failed_attempts: Dict[str, list] = {}  # ip -> list of timestamps
        self.generate_new_pin()

    def generate_new_pin(self) -> str:
        """Generates a cryptographically secure 6-digit numeric PIN."""
        # 100000 to 999999
        self._current_pin = f"{secrets.randbelow(900000) + 100000}"
        self._pin_created_at = time.time()
        logger.info("New pairing PIN generated [REDACTED]", category="auth")
        return self._current_pin

    def get_current_pin(self) -> str:
        """Returns the current PIN, generating a new one if expired."""
        if not self._current_pin or (time.time() - self._pin_created_at > PIN_VALIDITY_SECONDS):
            self.generate_new_pin()
        return self._current_pin

    def get_pin_time_remaining(self) -> int:
        remaining = int(PIN_VALIDITY_SECONDS - (time.time() - self._pin_created_at))
        return max(0, remaining)

    def is_rate_limited(self, client_ip: str) -> bool:
        """Checks if client IP is temporarily locked out due to excessive failed attempts."""
        now = time.time()
        attempts = self._failed_attempts.get(client_ip, [])
        # filter attempts within lockout window
        recent = [t for t in attempts if now - t < AUTH_LOCKOUT_SECONDS]
        self._failed_attempts[client_ip] = recent
        return len(recent) >= MAX_AUTH_ATTEMPTS

    def record_failed_attempt(self, client_ip: str):
        now = time.time()
        if client_ip not in self._failed_attempts:
            self._failed_attempts[client_ip] = []
        self._failed_attempts[client_ip].append(now)

    def clear_failed_attempts(self, client_ip: str):
        if client_ip in self._failed_attempts:
            del self._failed_attempts[client_ip]

    def verify_pairing_pin(self, client_ip: str, device_id: str, device_name: str, submitted_pin: str) -> Tuple[bool, Optional[str], Optional[str]]:
        """
        Verifies submitted 6-digit PIN.
        Returns (success: bool, token: Optional[str], error_message: Optional[str])
        """
        if self.is_rate_limited(client_ip):
            logger.warning(f"Connection from {client_ip} rejected: rate-limited", category="security")
            return False, None, "Too many failed attempts. Try again in 60 seconds."

        if not submitted_pin or len(submitted_pin.strip()) != PIN_LENGTH:
            self.record_failed_attempt(client_ip)
            return False, None, "Invalid PIN format. Must be 6 digits."

        now = time.time()
        if not self._current_pin or (now - self._pin_created_at > PIN_VALIDITY_SECONDS):
            self.generate_new_pin()
            return False, None, "PIN expired. Please use the current PIN shown on screen."

        if secrets.compare_digest(submitted_pin.strip(), self._current_pin):
            self.clear_failed_attempts(client_ip)
            # Generate new permanent auth token for this device
            token = secrets.token_urlsafe(32)
            db.save_device(device_id=device_id, device_name=device_name, raw_token=token)
            # Rotate PIN immediately for single-use security
            self.generate_new_pin()
            logger.info(f"Device paired successfully: {device_name} ({device_id})", category="auth")
            return True, token, None
        else:
            self.record_failed_attempt(client_ip)
            logger.warning(f"Failed pairing attempt from {client_ip} for device {device_name}", category="auth")
            return False, None, "Incorrect pairing PIN."

    def authenticate_token(self, client_ip: str, device_id: str, token: str) -> Tuple[bool, Optional[str]]:
        """Authenticates returning device using its persistent auth token."""
        if self.is_rate_limited(client_ip):
            return False, "Rate limit exceeded. Please wait."

        if not device_id or not token:
            return False, "Missing credentials."

        device = db.get_device(device_id)
        if not device:
            return False, "Device not paired. Pairing PIN required."

        if device.get("is_blocked"):
            return False, "Device has been blocked by server administrator."

        if db.verify_device_token(device_id, token):
            self.clear_failed_attempts(client_ip)
            db.update_device_last_seen(device_id)
            logger.info(f"Device reconnected & authenticated: {device.get('device_name')} ({device_id})", category="auth")
            return True, None
        else:
            self.record_failed_attempt(client_ip)
            logger.warning(f"Invalid token for device {device_id} from {client_ip}", category="auth")
            return False, "Invalid authentication token."

# Global auth manager
auth_manager = AuthManager()
