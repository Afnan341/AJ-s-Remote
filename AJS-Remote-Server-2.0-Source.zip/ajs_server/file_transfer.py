"""
AJS Remote Server 2.0 - Secure File Transfer Engine
Handles chunked bidirectional transfers, path traversal guards, and integrity checks.
"""

import os
import re
import base64
import hashlib
import time
from pathlib import Path
from typing import Dict, Any, Optional, Callable, List, Tuple
from ajs_server.config import DEFAULT_DOWNLOAD_DIR, MAX_FILE_SIZE_BYTES
from ajs_server.database import db
from ajs_server.logger import logger

class FileTransferSession:
    def __init__(self, transfer_id: str, filename: str, file_size: int, total_chunks: int, download_dir: Path):
        self.transfer_id = transfer_id
        self.filename = self._sanitize_filename(filename)
        self.file_size = file_size
        self.total_chunks = total_chunks
        self.download_dir = download_dir
        self.chunks_received = 0
        self.bytes_written = 0
        self.start_time = time.time()
        self.hasher = hashlib.sha256()

        # Temporary file path during transfer
        self.temp_path = self.download_dir / f".tmp_{transfer_id}_{self.filename}"
        self.final_path = self._resolve_unique_path(self.download_dir / self.filename)
        self._file_handle = open(self.temp_path, "wb")

    def _sanitize_filename(self, name: str) -> str:
        # Strip all directory separators, parent references, and null characters
        base = os.path.basename(name)
        base = re.sub(r'[\r\n\t\0]', '', base)
        base = re.sub(r'[\\/]', '_', base)
        # Avoid hidden dot files
        if base.startswith('.'):
            base = 'file_' + base
        if not base.strip():
            base = f"transfer_{int(time.time())}.bin"
        return base

    def _resolve_unique_path(self, target_path: Path) -> Path:
        """Prevents silent overwrites by appending (1), (2), etc."""
        if not target_path.exists():
            return target_path
        stem = target_path.stem
        suffix = target_path.suffix
        parent = target_path.parent
        counter = 1
        while True:
            candidate = parent / f"{stem}_{counter}{suffix}"
            if not candidate.exists():
                return candidate
            counter += 1

    def append_chunk(self, chunk_index: int, b64_data: str) -> Tuple[int, float]:
        raw_bytes = base64.b64decode(b64_data)
        self._file_handle.write(raw_bytes)
        self.hasher.update(raw_bytes)
        self.bytes_written += len(raw_bytes)
        self.chunks_received += 1
        progress = (self.chunks_received / self.total_chunks) if self.total_chunks > 0 else 1.0
        return self.bytes_written, progress

    def finalize(self, expected_sha256: Optional[str] = None) -> Path:
        self._file_handle.close()
        calc_sha256 = self.hasher.hexdigest()

        if expected_sha256 and expected_sha256.lower() != calc_sha256.lower():
            if self.temp_path.exists():
                self.temp_path.unlink()
            raise ValueError(f"SHA-256 mismatch! Expected {expected_sha256}, got {calc_sha256}")

        # Atomic move to final destination
        self.temp_path.rename(self.final_path)
        # Set safe read/write permissions (no executable bit)
        os.chmod(self.final_path, 0o644)
        return self.final_path

    def cancel(self):
        try:
            self._file_handle.close()
        except Exception:
            pass
        if self.temp_path.exists():
            try:
                self.temp_path.unlink()
            except Exception:
                pass

class FileTransferManager:
    def __init__(self, download_dir: Optional[Path] = None):
        self.download_dir = download_dir or DEFAULT_DOWNLOAD_DIR
        self.download_dir.mkdir(parents=True, exist_ok=True)
        self.active_sessions: Dict[str, FileTransferSession] = {}
        self.listeners: List[Callable[[Dict[str, Any]], None]] = []

    def set_download_dir(self, path: Path):
        self.download_dir = path
        self.download_dir.mkdir(parents=True, exist_ok=True)

    def subscribe(self, callback: Callable[[Dict[str, Any]], None]):
        if callback not in self.listeners:
            self.listeners.append(callback)

    def _notify(self, event: Dict[str, Any]):
        for listener in list(self.listeners):
            try:
                listener(event)
            except Exception:
                pass

    def start_incoming_transfer(self, transfer_id: str, filename: str, file_size: int, total_chunks: int) -> bool:
        if file_size > MAX_FILE_SIZE_BYTES:
            raise ValueError(f"File exceeds maximum allowed size ({MAX_FILE_SIZE_BYTES} bytes)")

        # Path traversal security check
        sanitized = os.path.basename(filename)
        dest_candidate = (self.download_dir / sanitized).resolve()
        if not str(dest_candidate).startswith(str(self.download_dir.resolve())):
            raise ValueError("Path traversal attempt detected!")

        session = FileTransferSession(transfer_id, sanitized, file_size, total_chunks, self.download_dir)
        self.active_sessions[transfer_id] = session

        db.record_transfer(transfer_id, session.filename, file_size, direction="incoming", status="in_progress")
        logger.info(f"Incoming file transfer started: {session.filename} ({file_size} bytes)", category="file")

        self._notify({
            "type": "file.started",
            "transfer_id": transfer_id,
            "filename": session.filename,
            "size": file_size
        })
        return True

    def process_incoming_chunk(self, transfer_id: str, chunk_index: int, b64_data: str) -> Dict[str, Any]:
        session = self.active_sessions.get(transfer_id)
        if not session:
            raise KeyError(f"Transfer ID {transfer_id} not found")

        bytes_written, progress = session.append_chunk(chunk_index, b64_data)
        res = {
            "transfer_id": transfer_id,
            "chunks_received": session.chunks_received,
            "total_chunks": session.total_chunks,
            "bytes_written": bytes_written,
            "progress": progress
        }
        self._notify({"type": "file.progress", **res})
        return res

    def finish_incoming_transfer(self, transfer_id: str, expected_sha256: Optional[str] = None) -> str:
        session = self.active_sessions.get(transfer_id)
        if not session:
            raise KeyError(f"Transfer ID {transfer_id} not found")

        final_path = session.finalize(expected_sha256)
        del self.active_sessions[transfer_id]

        db.record_transfer(
            transfer_id=transfer_id,
            filename=session.filename,
            file_size=session.file_size,
            direction="incoming",
            status="completed",
            saved_path=str(final_path)
        )
        logger.info(f"File transfer completed: saved to {final_path}", category="file")

        self._notify({
            "type": "file.completed",
            "transfer_id": transfer_id,
            "filename": session.filename,
            "saved_path": str(final_path)
        })
        return str(final_path)

    def cancel_transfer(self, transfer_id: str, reason: str = "User cancelled"):
        session = self.active_sessions.get(transfer_id)
        if session:
            session.cancel()
            del self.active_sessions[transfer_id]
            db.record_transfer(
                transfer_id=transfer_id,
                filename=session.filename,
                file_size=session.file_size,
                direction="incoming",
                status="cancelled"
            )
            logger.info(f"Transfer {transfer_id} cancelled: {reason}", category="file")
            self._notify({
                "type": "file.cancelled",
                "transfer_id": transfer_id,
                "reason": reason
            })

file_manager = FileTransferManager()
