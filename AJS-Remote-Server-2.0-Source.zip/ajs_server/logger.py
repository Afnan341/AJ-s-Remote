"""
AJS Remote Server 2.0 - Secure Activity Logger
Ensures sensitive PINs, keys, and tokens are scrubbed from all logs.
Maintains in-memory ring buffer for live GUI/Web inspection.
"""

import logging
import re
import threading
from collections import deque
from datetime import datetime
from typing import List, Dict, Any, Callable
from ajs_server.config import LOG_PATH

# Patterns to scrub
SENSITIVE_PATTERNS = [
    re.compile(r'("pin"\s*:\s*)"\d+"', re.IGNORECASE),
    re.compile(r'("token"\s*:\s*)"[^"]+"', re.IGNORECASE),
    re.compile(r'("secret"\s*:\s*)"[^"]+"', re.IGNORECASE),
    re.compile(r'(pin\s*=\s*)\d+', re.IGNORECASE),
    re.compile(r'(token\s*=\s*)[a-zA-Z0-9_\-]+', re.IGNORECASE),
    re.compile(r'\b\d{6}\b'),  # Any bare 6-digit number that might be a PIN
]

def scrub_sensitive_data(text: str) -> str:
    """Replaces any potential PINs, tokens, or credentials with [REDACTED]."""
    if not isinstance(text, str):
        return text
    result = text
    for pattern in SENSITIVE_PATTERNS:
        result = pattern.sub(r'\1[REDACTED]' if r'\1' in pattern.pattern else '[REDACTED_PIN]', result)
    return result

class ScrubbingFormatter(logging.Formatter):
    """Custom logging formatter that strips credentials from records."""
    def format(self, record: logging.LogRecord) -> str:
        original = super().format(record)
        return scrub_sensitive_data(original)

class ServerLogger:
    """Manages file and in-memory activity logs."""
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        with cls._lock:
            if cls._instance is None:
                cls._instance = super(ServerLogger, cls).__new__(cls)
                cls._instance._init_logger()
            return cls._instance

    def _init_logger(self):
        self.ring_buffer = deque(maxlen=500)
        self.subscribers: List[Callable[[Dict[str, Any]], None]] = []

        self.logger = logging.getLogger("ajs_remote_server")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False

        formatter = ScrubbingFormatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )

        # File Handler
        try:
            file_handler = logging.FileHandler(str(LOG_PATH), encoding="utf-8")
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
        except Exception as e:
            print(f"Warning: Could not create log file handler: {e}")

        # Stream Handler
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        self.logger.addHandler(stream_handler)

    def log(self, level: str, message: str, category: str = "system"):
        """Logs an event and records it in memory."""
        safe_msg = scrub_sensitive_data(message)
        log_func = getattr(self.logger, level.lower(), self.logger.info)
        log_func(safe_msg)

        entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level.upper(),
            "category": category,
            "message": safe_msg
        }

        with self._lock:
            self.ring_buffer.append(entry)
            for sub in list(self.subscribers):
                try:
                    sub(entry)
                except Exception:
                    pass

    def info(self, msg: str, category: str = "system"):
        self.log("INFO", msg, category)

    def warning(self, msg: str, category: str = "system"):
        self.log("WARNING", msg, category)

    def error(self, msg: str, category: str = "system"):
        self.log("ERROR", msg, category)

    def debug(self, msg: str, category: str = "system"):
        self.log("DEBUG", msg, category)

    def get_logs(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            return list(self.ring_buffer)[-limit:]

    def clear_logs(self):
        with self._lock:
            self.ring_buffer.clear()

    def subscribe(self, callback: Callable[[Dict[str, Any]], None]):
        with self._lock:
            if callback not in self.subscribers:
                self.subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[Dict[str, Any]], None]):
        with self._lock:
            if callback in self.subscribers:
                self.subscribers.remove(callback)

# Global singleton
logger = ServerLogger()
