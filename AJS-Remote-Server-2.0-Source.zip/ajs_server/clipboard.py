"""
AJS Remote Server 2.0 - Two-Way Clipboard Synchronization
Handles Android-to-PC and PC-to-Android text sync with loop prevention hashes.
"""

import hashlib
import shutil
import subprocess
import threading
import time
from typing import Optional, Callable, List
from ajs_server.logger import logger

MAX_CLIPBOARD_CHARS = 1000000  # 1MB limit

class ClipboardManager:
    def __init__(self, check_interval: float = 1.0):
        self.check_interval = check_interval
        self._last_hash = ""
        self._memory_clipboard = ""
        self._subscribers: List[Callable[[str, str], None]] = []
        self._running = False
        self._thread: Optional[threading.Thread] = None

        # Detect tools
        self.has_xclip = shutil.which("xclip") is not None
        self.has_wl_copy = shutil.which("wl-copy") is not None

    def start_monitoring(self):
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True, name="AJS-ClipboardMonitor")
        self._thread.start()

    def stop_monitoring(self):
        self._running = False

    def subscribe(self, callback: Callable[[str, str], None]):
        """Callback format: callback(text, hash)"""
        if callback not in self._subscribers:
            self._subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[str, str], None]):
        if callback in self._subscribers:
            self._subscribers.remove(callback)

    def _hash(self, text: str) -> str:
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def get_pc_clipboard(self) -> str:
        """Reads current system clipboard."""
        if self.has_wl_copy:
            try:
                res = subprocess.run(["wl-paste", "--no-newline"], capture_output=True, text=True, timeout=1)
                if res.returncode == 0:
                    return res.stdout
            except Exception:
                pass

        if self.has_xclip:
            try:
                res = subprocess.run(["xclip", "-selection", "clipboard", "-o"], capture_output=True, text=True, timeout=1)
                if res.returncode == 0:
                    return res.stdout
            except Exception:
                pass

        return self._memory_clipboard

    def set_pc_clipboard(self, text: str, remote_hash: Optional[str] = None) -> bool:
        """Sets clipboard from phone to PC, preventing broadcast echo."""
        if len(text) > MAX_CLIPBOARD_CHARS:
            text = text[:MAX_CLIPBOARD_CHARS]

        text_hash = remote_hash or self._hash(text)
        if text_hash == self._last_hash:
            return False  # Loop prevention

        self._last_hash = text_hash
        self._memory_clipboard = text

        # Update X11 or Wayland clipboard
        updated = False
        if self.has_wl_copy:
            try:
                proc = subprocess.Popen(["wl-copy"], stdin=subprocess.PIPE)
                proc.communicate(input=text.encode("utf-8"), timeout=1)
                updated = True
            except Exception:
                pass

        if not updated and self.has_xclip:
            try:
                proc = subprocess.Popen(["xclip", "-selection", "clipboard"], stdin=subprocess.PIPE)
                proc.communicate(input=text.encode("utf-8"), timeout=1)
                updated = True
            except Exception:
                pass

        logger.info(f"Clipboard updated from remote ({len(text)} chars)", category="clipboard")
        return True

    def _monitor_loop(self):
        """Polls for local clipboard changes to broadcast to Android."""
        while self._running:
            time.sleep(self.check_interval)
            try:
                current = self.get_pc_clipboard()
                if not current:
                    continue
                curr_hash = self._hash(current)
                if curr_hash != self._last_hash:
                    self._last_hash = curr_hash
                    # Notify subscribers
                    for sub in list(self._subscribers):
                        try:
                            sub(current, curr_hash)
                        except Exception:
                            pass
            except Exception as e:
                pass

clipboard_manager = ClipboardManager()
