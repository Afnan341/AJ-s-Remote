"""
AJS Remote Server 2.0 - QR Code Connection System
Generates structured, versioned JSON QR payloads strictly for AJ's Remote Android.
No browser URLs, no external redirects - pure direct WebSocket coordinates.
"""

import socket
import json
import base64
import io
from typing import Dict, Any, List
import qrcode
from PIL import Image
from ajs_server.config import APP_NAME, PROTOCOL_VERSION, DEFAULT_PORT

def get_local_ip() -> str:
    """Finds the primary local LAN IP address of this machine."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Does not actually connect to public net, just gets route
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception:
        try:
            ip = socket.gethostbyname(socket.gethostname())
        except Exception:
            ip = "127.0.0.1"
    finally:
        s.close()
    return ip

def get_all_local_ips() -> List[str]:
    """Retrieves all non-loopback IPv4 addresses."""
    ips = []
    primary = get_local_ip()
    if primary and primary != "127.0.0.1":
        ips.append(primary)
    try:
        host_info = socket.getaddrinfo(socket.gethostname(), None)
        for item in host_info:
            addr = item[4][0]
            if ":" not in addr and addr != "127.0.0.1" and addr not in ips:
                ips.append(addr)
    except Exception:
        pass
    if not ips:
        ips.append("127.0.0.1")
    return ips

def build_qr_payload(server_ip: str = None, port: int = DEFAULT_PORT, pairing_required: bool = True, session_hint: str = None) -> Dict[str, Any]:
    """Builds the exact versioned JSON payload expected by AJ's Remote Android."""
    ip = server_ip or get_local_ip()
    payload = {
        "app": APP_NAME,
        "protocol_version": PROTOCOL_VERSION,
        "server_ip": ip,
        "port": port,
        "pairing_required": pairing_required
    }
    if session_hint:
        payload["session_hint"] = session_hint
    return payload

def generate_qr_image(payload: Dict[str, Any], box_size: int = 10, border: int = 2) -> Image.Image:
    """Generates a PIL Image of the QR code."""
    json_str = json.dumps(payload, separators=(',', ':'))
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=box_size,
        border=border
    )
    qr.add_data(json_str)
    qr.make(fit=True)
    # Futuristic red & dark theme QR or clean high-contrast
    img = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    return img

def generate_qr_base64(payload: Dict[str, Any]) -> str:
    """Returns data:image/png;base64,... string for Web & GUI display."""
    img = generate_qr_image(payload)
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    b64_str = base64.b64encode(buffered.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64_str}"

def generate_ascii_qr(payload: Dict[str, Any]) -> str:
    """Renders QR code in terminal text using ANSI blocks for headless inspection."""
    json_str = json.dumps(payload, separators=(',', ':'))
    qr = qrcode.QRCode()
    qr.add_data(json_str)
    f = io.StringIO()
    qr.print_ascii(out=f)
    f.seek(0)
    return f.read()
