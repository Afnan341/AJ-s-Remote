"""
AJS Remote Server 2.0 - System Diagnostic & Permission Verifier
Tests Python environment, uinput permissions, network interfaces, and gamepad creation.
"""

import sys
import os
import socket
import shutil
import grp
from typing import Dict, Any, List

def check_python_environment() -> Dict[str, Any]:
    version = sys.version_info
    is_supported = version.major == 3 and version.minor >= 8
    return {
        "name": "Python Environment",
        "status": "PASS" if is_supported else "FAIL",
        "details": f"Python {version.major}.{version.minor}.{version.micro}",
        "action": None if is_supported else "Install Python 3.8 or newer."
    }

def check_dependencies() -> Dict[str, Any]:
    deps = {
        "evdev": False,
        "websockets": False,
        "qrcode": False,
        "PIL (Pillow)": False
    }
    try:
        import evdev
        deps["evdev"] = True
    except ImportError:
        pass

    try:
        import websockets
        deps["websockets"] = True
    except ImportError:
        pass

    try:
        import qrcode
        deps["qrcode"] = True
    except ImportError:
        pass

    try:
        import PIL
        deps["PIL (Pillow)"] = True
    except ImportError:
        pass

    missing = [k for k, v in deps.items() if not v]
    all_ok = len(missing) == 0
    return {
        "name": "Python Dependencies",
        "status": "PASS" if all_ok else "FAIL",
        "details": "All core dependencies available" if all_ok else f"Missing: {', '.join(missing)}",
        "action": None if all_ok else f"Run: sudo apt-get install -y python3-evdev python3-websockets python3-qrcode python3-pil"
    }

def check_uinput_availability() -> Dict[str, Any]:
    uinput_path = "/dev/uinput"
    exists = os.path.exists(uinput_path)

    if not exists:
        return {
            "name": "/dev/uinput Existence",
            "status": "FAIL",
            "details": "/dev/uinput character device is missing.",
            "action": "Run: 'sudo modprobe uinput' and install udev rule: 'echo 'KERNEL==\"uinput\", MODE=\"0660\", GROUP=\"uinput\"' | sudo tee /etc/udev/rules.d/99-uinput.rules'"
        }

    is_readable = os.access(uinput_path, os.R_OK)
    is_writable = os.access(uinput_path, os.W_OK)

    if is_writable:
        return {
            "name": "/dev/uinput Permissions",
            "status": "PASS",
            "details": "/dev/uinput exists and is writable by current user.",
            "action": None
        }

    # Check user groups
    current_user = os.environ.get("USER", "current user")
    in_uinput_group = False
    try:
        uinput_grp = grp.getgrnam("uinput")
        if current_user in uinput_grp.gr_mem:
            in_uinput_group = True
    except KeyError:
        pass

    return {
        "name": "/dev/uinput Permissions",
        "status": "WARN",
        "details": f"Permission denied accessing /dev/uinput for user '{current_user}'. Gamepad will run in simulation mode.",
        "action": "Fix command:\n  sudo groupadd -f uinput\n  sudo usermod -aG uinput $USER\n  echo 'KERNEL==\"uinput\", MODE=\"0660\", GROUP=\"uinput\"' | sudo tee /etc/udev/rules.d/99-uinput.rules\n  sudo udevadm control --reload-rules && sudo udevadm trigger\n  (Logout and log back in required for group membership to take effect)"
    }

def check_virtual_gamepad_creation() -> Dict[str, Any]:
    try:
        import evdev
        from evdev import UInput, AbsInfo, ecodes
        capabilities = {
            ecodes.EV_KEY: [ecodes.BTN_A, ecodes.BTN_B],
            ecodes.EV_ABS: [(ecodes.ABS_X, AbsInfo(value=0, min=-32767, max=32767, fuzz=0, flat=0, resolution=0))]
        }
        test_dev = UInput(capabilities, name="AJS Diagnostic Probe")
        test_dev.close()
        return {
            "name": "Kernel Virtual Controller Creation",
            "status": "PASS",
            "details": "Linux kernel input subsystem accepted virtual gamepad creation without errors.",
            "action": None
        }
    except Exception as e:
        return {
            "name": "Kernel Virtual Controller Creation",
            "status": "WARN",
            "details": f"Could not create test kernel controller: {e}",
            "action": "Ensure /dev/uinput has rw permissions. Run install.sh to configure udev rules automatically."
        }

def check_network_interfaces() -> Dict[str, Any]:
    from ajs_server.qr_generator import get_local_ip, get_all_local_ips
    local_ip = get_local_ip()
    all_ips = get_all_local_ips()

    if local_ip == "127.0.0.1" and len(all_ips) <= 1:
        return {
            "name": "Network & Wi-Fi Interfaces",
            "status": "WARN",
            "details": "Only loopback 127.0.0.1 found. Wi-Fi or LAN connection not active.",
            "action": "Connect PC to local Wi-Fi router so Android phone can reach it."
        }

    return {
        "name": "Network & Wi-Fi Interfaces",
        "status": "PASS",
        "details": f"Primary IP: {local_ip} | Available: {', '.join(all_ips)}",
        "action": None
    }

def check_port_availability(port: int = 8765) -> Dict[str, Any]:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(("0.0.0.0", port))
        sock.close()
        return {
            "name": f"Port {port} Availability",
            "status": "PASS",
            "details": f"Port {port} is open and available for WebSocket server.",
            "action": None
        }
    except OSError as e:
        return {
            "name": f"Port {port} Availability",
            "status": "WARN",
            "details": f"Port {port} is currently in use or unavailable: {e}",
            "action": "Change the server port in Settings or terminate the existing process."
        }

def run_all_diagnostics(port: int = 8765) -> List[Dict[str, Any]]:
    return [
        check_python_environment(),
        check_dependencies(),
        check_uinput_availability(),
        check_virtual_gamepad_creation(),
        check_network_interfaces(),
        check_port_availability(port)
    ]

if __name__ == "__main__":
    print("=" * 60)
    print("  AJS REMOTE SERVER 2.0 - SYSTEM DIAGNOSTIC REPORT")
    print("=" * 60)
    results = run_all_diagnostics()
    for res in results:
        status_color = "\033[92m" if res["status"] == "PASS" else ("\033[93m" if res["status"] == "WARN" else "\033[91m")
        reset_color = "\033[0m"
        print(f"\n[{status_color}{res['status']}{reset_color}] {res['name']}")
        print(f"  Details: {res['details']}")
        if res.get("action"):
            print(f"  Suggested Action:\n    {res['action']}")
    print("\n" + "=" * 60)
