"""
AJS Remote Server 2.0
Advanced Linux PC Companion for AJ's Remote Android
"""

__version__ = "2.0.0"
__author__ = "AJ's Remote Team"
