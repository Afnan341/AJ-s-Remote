"""
AJS Remote Server 2.0 - Asyncio WebSocket Core
Handles persistent connections, handshake, heartbeats, controller/mouse/keyboard routing.
"""

import asyncio
import json
import time
from typing import Dict, Any, Optional, Set
import websockets
from websockets.server import WebSocketServerProtocol

from ajs_server.config import (
    DEFAULT_HOST, DEFAULT_PORT, PROTOCOL_VERSION, SERVER_VERSION,
    DEFAULT_HEARTBEAT_INTERVAL, DEFAULT_HEARTBEAT_TIMEOUT, MAX_MESSAGE_SIZE
)
from ajs_server.logger import logger
from ajs_server.auth import auth_manager
from ajs_server.protocol import (
    MSG_HELLO, MSG_WELCOME, MSG_PAIR, MSG_PAIR_RESP, MSG_LOGIN, MSG_LOGIN_RESP,
    MSG_PING, MSG_PONG, MSG_CTRL_BUTTON, MSG_CTRL_AXIS, MSG_CTRL_BUNDLE,
    MSG_MOUSE_MOVE, MSG_MOUSE_CLICK, MSG_MOUSE_SCROLL, MSG_KB_KEY, MSG_KB_TEXT,
    MSG_CLIPBOARD_SYNC, MSG_FILE_START, MSG_FILE_ACCEPT, MSG_FILE_REJECT,
    MSG_FILE_CHUNK, MSG_FILE_ACK, MSG_FILE_FINISH, MSG_FILE_COMPLETE, MSG_FILE_CANCEL,
    MSG_DISCONNECT, MSG_ERROR, MSG_SERVER_STATUS,
    validate_message, validate_controller_button, validate_controller_axis,
    validate_mouse_move, validate_mouse_click, validate_keyboard_key,
    make_error_message, ProtocolError
)
from ajs_server.virtual_gamepad import VirtualGamepad
from ajs_server.mouse_keyboard import MouseKeyboardEngine
from ajs_server.clipboard import clipboard_manager
from ajs_server.file_transfer import file_manager
from ajs_server.database import db

class ClientSession:
    def __init__(self, websocket: WebSocketServerProtocol, client_ip: str):
        self.ws = websocket
        self.ip = client_ip
        self.device_id: Optional[str] = None
        self.device_name: str = "Unknown Phone"
        self.is_authenticated = False
        self.connected_at = time.time()
        self.last_heartbeat = time.time()
        self.is_controller_owner = False

class AjsWebSocketServer:
    def __init__(self, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT):
        self.host = host
        self.port = port
        self.server: Optional[websockets.WebSocketServer] = None
        self.is_running = False
        self.sessions: Dict[WebSocketServerProtocol, ClientSession] = {}

        # Hardware Input Engines
        self.gamepad = VirtualGamepad()
        self.input_engine = MouseKeyboardEngine()

        # Connect clipboard broadcasts
        clipboard_manager.subscribe(self._on_local_clipboard_changed)

        # Heartbeat task handle
        self._heartbeat_task: Optional[asyncio.Task] = None

    async def start(self):
        """Starts WebSocket server."""
        if self.is_running:
            return

        logger.info(f"Starting AJS Remote Server 2.0 on {self.host}:{self.port}...", category="server")
        try:
            self.server = await websockets.serve(
                self._handle_connection,
                self.host,
                self.port,
                max_size=MAX_MESSAGE_SIZE,
                ping_interval=None,  # We manage application-level ping/pong for diagnostics
                close_timeout=5
            )
            self.is_running = True
            self._heartbeat_task = asyncio.create_task(self._heartbeat_monitor_loop())
            logger.info(f"Server online and listening on ws://{self.host}:{self.port}", category="server")
        except Exception as e:
            logger.error(f"Failed to start WebSocket server: {e}", category="server")
            raise

    async def stop(self):
        """Stops WebSocket server and releases all virtual input devices."""
        if not self.is_running:
            return

        logger.info("Stopping AJS Remote Server...", category="server")
        self.is_running = False

        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

        # Disconnect all active clients gracefully
        for ws, session in list(self.sessions.items()):
            try:
                await ws.send(json.dumps({"type": MSG_DISCONNECT, "reason": "Server shutting down"}))
                await ws.close()
            except Exception:
                pass
        self.sessions.clear()

        # Close server socket
        if self.server:
            self.server.close()
            await self.server.wait_closed()
            self.server = None

        # Release all gamepad and keyboard states
        self.gamepad.release_all()
        self.input_engine.release_all()

        logger.info("Server stopped cleanly. All input states reset.", category="server")

    async def _handle_connection(self, websocket: WebSocketServerProtocol):
        client_ip = websocket.remote_address[0]
        session = ClientSession(websocket, client_ip)
        self.sessions[websocket] = session
        logger.info(f"New connection from {client_ip}", category="network")

        try:
            async for raw_msg in websocket:
                try:
                    await self._process_message(session, raw_msg)
                except ProtocolError as pe:
                    await websocket.send(json.dumps(make_error_message(pe.code, pe.message)))
                except json.JSONDecodeError:
                    await websocket.send(json.dumps(make_error_message("ERR_MALFORMED_JSON", "Invalid JSON format")))
                except Exception as e:
                    logger.error(f"Error handling message from {client_ip}: {e}", category="server")
                    await websocket.send(json.dumps(make_error_message("ERR_INTERNAL", "Internal server error")))

        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            await self._cleanup_session(session)

    async def _cleanup_session(self, session: ClientSession):
        ws = session.ws
        if ws in self.sessions:
            del self.sessions[ws]

        logger.info(f"Device disconnected: {session.device_name} ({session.ip})", category="network")

        # Check if this session held controller ownership
        if session.is_controller_owner or len(self.sessions) == 0:
            # Revert any active buttons/axes to neutral to prevent stuck input
            self.gamepad.release_all()
            self.input_engine.release_all()

            # Pass controller ownership to next authenticated device if available
            for other in self.sessions.values():
                if other.is_authenticated:
                    other.is_controller_owner = True
                    break

    async def _process_message(self, session: ClientSession, raw_msg: str):
        msg = json.loads(raw_msg)
        is_valid, err = validate_message(msg)
        if not is_valid:
            raise ProtocolError("ERR_INVALID_SCHEMA", err or "Invalid schema")

        msg_type = msg["type"]

        # Heartbeat Ping (Always allowed)
        if msg_type == MSG_PING:
            session.last_heartbeat = time.time()
            await session.ws.send(json.dumps({
                "type": MSG_PONG,
                "client_timestamp": msg.get("timestamp"),
                "server_time": time.time()
            }))
            return

        # Handshake Hello
        if msg_type == MSG_HELLO:
            client_version = msg.get("protocol_version", 1)
            session.device_id = msg.get("device_id", "unknown_device")
            session.device_name = msg.get("device_name", "Android Phone")

            await session.ws.send(json.dumps({
                "type": MSG_WELCOME,
                "protocol_version": PROTOCOL_VERSION,
                "server_version": SERVER_VERSION,
                "server_name": "AJS Remote Server 2.0",
                "uinput_active": self.gamepad.is_hardware_active
            }))
            return

        # Pairing with 6-digit PIN
        if msg_type == MSG_PAIR:
            pin = str(msg.get("pin", ""))
            dev_id = msg.get("device_id", session.device_id or "unknown")
            dev_name = msg.get("device_name", session.device_name)
            session.device_id = dev_id
            session.device_name = dev_name

            success, token, err_msg = auth_manager.verify_pairing_pin(session.ip, dev_id, dev_name, pin)
            if success:
                session.is_authenticated = True
                session.is_controller_owner = True
                await session.ws.send(json.dumps({
                    "type": MSG_PAIR_RESP,
                    "success": True,
                    "auth_token": token,
                    "message": "Pairing successful!"
                }))
            else:
                await session.ws.send(json.dumps({
                    "type": MSG_PAIR_RESP,
                    "success": False,
                    "error": err_msg
                }))
            return

        # Login with existing Auth Token
        if msg_type == MSG_LOGIN:
            dev_id = msg.get("device_id", session.device_id)
            token = msg.get("auth_token", "")
            success, err_msg = auth_manager.authenticate_token(session.ip, dev_id, token)
            if success:
                session.device_id = dev_id
                dev_info = db.get_device(dev_id)
                if dev_info:
                    session.device_name = dev_info.get("device_name", "Android Phone")
                session.is_authenticated = True
                session.is_controller_owner = True
                await session.ws.send(json.dumps({
                    "type": MSG_LOGIN_RESP,
                    "success": True,
                    "device_name": session.device_name
                }))
            else:
                await session.ws.send(json.dumps({
                    "type": MSG_LOGIN_RESP,
                    "success": False,
                    "error": err_msg
                }))
            return

        # All subsequent control messages REQUIRE authentication
        if not session.is_authenticated:
            raise ProtocolError("ERR_UNAUTHORIZED", "Device is not authenticated. Please pair with PIN first.")

        # Update activity timestamp
        session.last_heartbeat = time.time()

        # Controller Button
        if msg_type == MSG_CTRL_BUTTON:
            validate_controller_button(msg)
            self.gamepad.set_button(msg["button"], msg["pressed"])
            return

        # Controller Axis
        if msg_type == MSG_CTRL_AXIS:
            validate_controller_axis(msg)
            self.gamepad.set_axis(msg["axis"], float(msg["value"]))
            return

        # Controller Bundle (Batch button and axes in one network packet)
        if msg_type == MSG_CTRL_BUNDLE:
            buttons = msg.get("buttons", {})
            for b_name, b_val in buttons.items():
                if b_name in self.gamepad.button_states:
                    self.gamepad.set_button(b_name, bool(b_val))
            axes = msg.get("axes", {})
            for a_name, a_val in axes.items():
                if a_name in self.gamepad.axis_states:
                    self.gamepad.set_axis(a_name, float(a_val))
            return

        # Mouse Move
        if msg_type == MSG_MOUSE_MOVE:
            validate_mouse_move(msg)
            self.input_engine.move_mouse(msg["dx"], msg["dy"])
            return

        # Mouse Click
        if msg_type == MSG_MOUSE_CLICK:
            validate_mouse_click(msg)
            self.input_engine.click_mouse(msg.get("button", "left"), msg.get("state", "click"))
            return

        # Mouse Scroll
        if msg_type == MSG_MOUSE_SCROLL:
            dy = float(msg.get("dy", 0))
            dx = float(msg.get("dx", 0))
            self.input_engine.scroll_mouse(dy, dx)
            return

        # Keyboard Key
        if msg_type == MSG_KB_KEY:
            validate_keyboard_key(msg)
            self.input_engine.set_key(msg["key"], msg["pressed"])
            return

        # Keyboard Text
        if msg_type == MSG_KB_TEXT:
            text = str(msg.get("text", ""))
            self.input_engine.type_text(text)
            return

        # Clipboard Sync (From phone to PC)
        if msg_type == MSG_CLIPBOARD_SYNC:
            text = str(msg.get("text", ""))
            rem_hash = msg.get("hash")
            clipboard_manager.set_pc_clipboard(text, rem_hash)
            return

        # File Transfer: Start
        if msg_type == MSG_FILE_START:
            tid = msg["transfer_id"]
            name = msg["filename"]
            size = int(msg["file_size"])
            chunks = int(msg["total_chunks"])
            try:
                file_manager.start_incoming_transfer(tid, name, size, chunks)
                await session.ws.send(json.dumps({"type": MSG_FILE_ACCEPT, "transfer_id": tid}))
            except Exception as e:
                await session.ws.send(json.dumps({"type": MSG_FILE_REJECT, "transfer_id": tid, "reason": str(e)}))
            return

        # File Transfer: Chunk
        if msg_type == MSG_FILE_CHUNK:
            tid = msg["transfer_id"]
            c_idx = int(msg["chunk_index"])
            data = msg["data_b64"]
            res = file_manager.process_incoming_chunk(tid, c_idx, data)
            await session.ws.send(json.dumps({"type": MSG_FILE_ACK, **res}))
            return

        # File Transfer: Finish
        if msg_type == MSG_FILE_FINISH:
            tid = msg["transfer_id"]
            sha = msg.get("sha256")
            try:
                saved = file_manager.finish_incoming_transfer(tid, sha)
                await session.ws.send(json.dumps({"type": MSG_FILE_COMPLETE, "transfer_id": tid, "saved_path": saved}))
            except Exception as e:
                await session.ws.send(json.dumps({"type": MSG_ERROR, "code": "ERR_FILE_FINISH", "message": str(e)}))
            return

        # File Transfer: Cancel
        if msg_type == MSG_FILE_CANCEL:
            tid = msg["transfer_id"]
            file_manager.cancel_transfer(tid, msg.get("reason", "Cancelled by client"))
            return

        # Disconnect Request
        if msg_type == MSG_DISCONNECT:
            await session.ws.close()
            return

        # Unknown message type
        raise ProtocolError("ERR_UNKNOWN_TYPE", f"Unrecognized message type: {msg_type}")

    def _on_local_clipboard_changed(self, text: str, text_hash: str):
        """Broadcasts PC clipboard update to all authenticated phones."""
        payload = json.dumps({
            "type": MSG_CLIPBOARD_SYNC,
            "direction": "to_phone",
            "text": text,
            "hash": text_hash
        })
        for session in list(self.sessions.values()):
            if session.is_authenticated:
                asyncio.create_task(session.ws.send(payload))

    async def _heartbeat_monitor_loop(self):
        """Monitors connected clients for heartbeat timeouts."""
        while self.is_running:
            await asyncio.sleep(DEFAULT_HEARTBEAT_INTERVAL)
            now = time.time()
            for ws, session in list(self.sessions.items()):
                if now - session.last_heartbeat > DEFAULT_HEARTBEAT_TIMEOUT:
                    logger.warning(f"Client {session.device_name} timed out ({session.ip}). Closing.", category="network")
                    try:
                        await ws.close(1001, "Heartbeat timeout")
                    except Exception:
                        pass

    def get_status(self) -> Dict[str, Any]:
        """Provides status summary for GUI and Web monitoring."""
        connected_devices = [
            {
                "device_id": s.device_id,
                "device_name": s.device_name,
                "ip": s.ip,
                "authenticated": s.is_authenticated,
                "is_controller_owner": s.is_controller_owner,
                "connected_seconds": int(time.time() - s.connected_at)
            }
            for s in self.sessions.values()
        ]
        return {
            "is_running": self.is_running,
            "host": self.host,
            "port": self.port,
            "connected_count": len(self.sessions),
            "authenticated_count": len([s for s in self.sessions.values() if s.is_authenticated]),
            "connected_devices": connected_devices,
            "uinput_active": self.gamepad.is_hardware_active,
            "mouse_active": self.input_engine.is_active
        }
