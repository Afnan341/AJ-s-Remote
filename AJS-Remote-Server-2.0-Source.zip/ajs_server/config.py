"""
AJS Remote Server 2.0 - Configuration Management
Handles persistent config defaults, paths, and environment detection.
"""

import os
from pathlib import Path

# Protocol & Application metadata
APP_NAME = "AJS Remote Server"
APP_DISPLAY_NAME = "AJS Remote Server 2.0"
PROTOCOL_VERSION = 1
SERVER_VERSION = "2.0.0"

# Directories
HOME_DIR = Path.home()
CONFIG_DIR = HOME_DIR / ".config" / "ajs-remote-server"
DATA_DIR = HOME_DIR / ".local" / "share" / "ajs-remote-server"
DEFAULT_DOWNLOAD_DIR = HOME_DIR / "Downloads" / "AJS_Remote_Transfers"

# Ensure runtime directories exist
CONFIG_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
DEFAULT_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Database and Log file paths
DB_PATH = DATA_DIR / "server.db"
LOG_PATH = DATA_DIR / "ajs_server.log"

# Network Defaults
DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 8765
DEFAULT_HEARTBEAT_INTERVAL = 3.0  # seconds
DEFAULT_HEARTBEAT_TIMEOUT = 10.0   # seconds
MAX_MESSAGE_SIZE = 16 * 1024 * 1024  # 16MB max payload for files

# Pairing & Security Defaults
PIN_LENGTH = 6
PIN_VALIDITY_SECONDS = 300  # 5 minutes
MAX_AUTH_ATTEMPTS = 5
AUTH_LOCKOUT_SECONDS = 60

# Gamepad Defaults
DEFAULT_STICK_DEADZONE = 0.08  # 8% inner deadzone
DEFAULT_TRIGGER_THRESHOLD = 0.05

# File Transfer Limits
MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024  # 500 MB
CHUNK_SIZE_BYTES = 64 * 1024  # 64 KB
