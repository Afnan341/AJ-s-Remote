"""
AJS Remote Server 2.0 - SQLite Database Layer
Stores authorized devices, persistent server settings, and transfer records.
"""

import sqlite3
import json
import hashlib
import time
from typing import Optional, List, Dict, Any
from pathlib import Path
from ajs_server.config import DB_PATH, DEFAULT_PORT, DEFAULT_STICK_DEADZONE, DEFAULT_DOWNLOAD_DIR

class Database:
    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            # Settings table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at REAL NOT NULL
            )
            """)

            # Authorized Devices table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS authorized_devices (
                device_id TEXT PRIMARY KEY,
                device_name TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                paired_at REAL NOT NULL,
                last_seen_at REAL NOT NULL,
                is_trusted INTEGER DEFAULT 1,
                is_blocked INTEGER DEFAULT 0
            )
            """)

            # File transfers history table
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS file_transfers (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                file_size INTEGER NOT NULL,
                direction TEXT NOT NULL,
                status TEXT NOT NULL,
                saved_path TEXT,
                timestamp REAL NOT NULL
            )
            """)
            conn.commit()

        # Seed default settings if empty
        self._seed_defaults()

    def _seed_defaults(self):
        defaults = {
            "server_port": str(DEFAULT_PORT),
            "require_pairing": "true",
            "pin_timeout_seconds": "300",
            "auto_start": "false",
            "stick_deadzone": str(DEFAULT_STICK_DEADZONE),
            "mouse_sensitivity": "1.0",
            "download_dir": str(DEFAULT_DOWNLOAD_DIR),
            "log_level": "INFO",
            "uinput_mode": "auto"
        }
        for k, v in defaults.items():
            if self.get_setting(k) is None:
                self.set_setting(k, v)

    def get_setting(self, key: str, default: Any = None) -> Any:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            if row:
                return row["value"]
            return default

    def get_all_settings(self) -> Dict[str, str]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT key, value FROM settings")
            rows = cursor.fetchall()
            return {row["key"]: row["value"] for row in rows}

    def set_setting(self, key: str, value: Any):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                (key, str(value), time.time())
            )
            conn.commit()

    # Device Management
    def save_device(self, device_id: str, device_name: str, raw_token: str):
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        now = time.time()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO authorized_devices (device_id, device_name, token_hash, paired_at, last_seen_at, is_trusted, is_blocked)
            VALUES (?, ?, ?, ?, ?, 1, 0)
            ON CONFLICT(device_id) DO UPDATE SET
                device_name = excluded.device_name,
                token_hash = excluded.token_hash,
                last_seen_at = excluded.last_seen_at,
                is_blocked = 0
            """, (device_id, device_name, token_hash, now, now))
            conn.commit()

    def verify_device_token(self, device_id: str, raw_token: str) -> bool:
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT token_hash, is_blocked FROM authorized_devices WHERE device_id = ?",
                (device_id,)
            )
            row = cursor.fetchone()
            if not row:
                return False
            if row["is_blocked"]:
                return False
            return row["token_hash"] == token_hash

    def update_device_last_seen(self, device_id: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE authorized_devices SET last_seen_at = ? WHERE device_id = ?",
                (time.time(), device_id)
            )
            conn.commit()

    def get_device(self, device_id: str) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM authorized_devices WHERE device_id = ?", (device_id,))
            row = cursor.fetchone()
            if row:
                return dict(row)
            return None

    def list_devices(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT device_id, device_name, paired_at, last_seen_at, is_trusted, is_blocked FROM authorized_devices ORDER BY last_seen_at DESC")
            return [dict(row) for row in cursor.fetchall()]

    def revoke_device(self, device_id: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM authorized_devices WHERE device_id = ?", (device_id,))
            conn.commit()

    def block_device(self, device_id: str, blocked: bool = True):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE authorized_devices SET is_blocked = ? WHERE device_id = ?",
                (1 if blocked else 0, device_id)
            )
            conn.commit()

    # File Transfer Records
    def record_transfer(self, transfer_id: str, filename: str, file_size: int, direction: str, status: str, saved_path: Optional[str] = None):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
            INSERT INTO file_transfers (id, filename, file_size, direction, status, saved_path, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET status = excluded.status, saved_path = excluded.saved_path
            """, (transfer_id, filename, file_size, direction, status, saved_path, time.time()))
            conn.commit()

    def list_transfers(self, limit: int = 50) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM file_transfers ORDER BY timestamp DESC LIMIT ?", (limit,))
            return [dict(row) for row in cursor.fetchall()]

# Global singleton
db = Database()
