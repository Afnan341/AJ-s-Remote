"""
AJS Remote Server 2.0 - Unified Wire Protocol Definition
Defines all message types, schemas, and validators for Android-to-PC communication.
"""

from typing import Dict, Any, Tuple, Optional
from ajs_server.config import PROTOCOL_VERSION

# Message Type Constants
MSG_HELLO = "handshake.hello"
MSG_WELCOME = "handshake.welcome"
MSG_PAIR = "auth.pair"
MSG_PAIR_RESP = "auth.pair_response"
MSG_LOGIN = "auth.login"
MSG_LOGIN_RESP = "auth.login_response"
MSG_PING = "heartbeat.ping"
MSG_PONG = "heartbeat.pong"

MSG_CTRL_BUTTON = "controller.button"
MSG_CTRL_AXIS = "controller.axis"
MSG_CTRL_BUNDLE = "controller.bundle"

MSG_MOUSE_MOVE = "mouse.move"
MSG_MOUSE_CLICK = "mouse.click"
MSG_MOUSE_SCROLL = "mouse.scroll"

MSG_KB_KEY = "keyboard.key"
MSG_KB_TEXT = "keyboard.text"

MSG_CLIPBOARD_SYNC = "clipboard.sync"

MSG_FILE_START = "file.start"
MSG_FILE_ACCEPT = "file.accept"
MSG_FILE_REJECT = "file.reject"
MSG_FILE_CHUNK = "file.chunk"
MSG_FILE_ACK = "file.ack"
MSG_FILE_FINISH = "file.finish"
MSG_FILE_COMPLETE = "file.complete"
MSG_FILE_CANCEL = "file.cancel"

MSG_DISCONNECT = "device.disconnect"
MSG_ERROR = "error"
MSG_SERVER_STATUS = "server.status"

# Recognized Gamepad Buttons
VALID_BUTTONS = {
    "A", "B", "X", "Y",
    "DPAD_UP", "DPAD_DOWN", "DPAD_LEFT", "DPAD_RIGHT",
    "L1", "R1", "L2", "R2", "L3", "R3",
    "START", "SELECT", "MENU", "HOME"
}

# Recognized Gamepad Axes
VALID_AXES = {
    "LEFT_X", "LEFT_Y",
    "RIGHT_X", "RIGHT_Y",
    "TRIGGER_L", "TRIGGER_R"
}

# Recognized Mouse Buttons
VALID_MOUSE_BUTTONS = {"left", "right", "middle"}
VALID_MOUSE_STATES = {"down", "up", "click"}

class ProtocolError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message

def make_error_message(code: str, message: str, original_type: Optional[str] = None) -> Dict[str, Any]:
    return {
        "type": MSG_ERROR,
        "code": code,
        "message": message,
        "original_type": original_type
    }

def validate_message(msg: Any) -> Tuple[bool, Optional[str]]:
    """Validates basic structure of an incoming JSON message."""
    if not isinstance(msg, dict):
        return False, "Message must be a JSON object"
    if "type" not in msg or not isinstance(msg["type"], str):
        return False, "Message missing string 'type' field"
    return True, None

def validate_controller_button(msg: Dict[str, Any]):
    if "button" not in msg or msg["button"] not in VALID_BUTTONS:
        raise ProtocolError("ERR_INVALID_BUTTON", f"Unknown button: {msg.get('button')}")
    if "pressed" not in msg or not isinstance(msg["pressed"], bool):
        raise ProtocolError("ERR_INVALID_BUTTON_STATE", "Field 'pressed' must be a boolean")

def validate_controller_axis(msg: Dict[str, Any]):
    if "axis" not in msg or msg["axis"] not in VALID_AXES:
        raise ProtocolError("ERR_INVALID_AXIS", f"Unknown axis: {msg.get('axis')}")
    if "value" not in msg or not isinstance(msg["value"], (int, float)):
        raise ProtocolError("ERR_INVALID_AXIS_VALUE", "Field 'value' must be a number")
    val = float(msg["value"])
    if msg["axis"] in ("TRIGGER_L", "TRIGGER_R"):
        if not (0.0 <= val <= 1.0):
            raise ProtocolError("ERR_AXIS_OUT_OF_RANGE", "Triggers must be in range [0.0, 1.0]")
    else:
        if not (-1.0 <= val <= 1.0):
            raise ProtocolError("ERR_AXIS_OUT_OF_RANGE", "Thumbstick axes must be in range [-1.0, 1.0]")

def validate_mouse_move(msg: Dict[str, Any]):
    if "dx" not in msg or "dy" not in msg:
        raise ProtocolError("ERR_INVALID_MOUSE", "Mouse move requires 'dx' and 'dy'")
    if not isinstance(msg["dx"], (int, float)) or not isinstance(msg["dy"], (int, float)):
        raise ProtocolError("ERR_INVALID_MOUSE", "'dx' and 'dy' must be numbers")

def validate_mouse_click(msg: Dict[str, Any]):
    btn = msg.get("button", "left").lower()
    state = msg.get("state", "click").lower()
    if btn not in VALID_MOUSE_BUTTONS:
        raise ProtocolError("ERR_INVALID_MOUSE_BUTTON", f"Invalid button: {btn}")
    if state not in VALID_MOUSE_STATES:
        raise ProtocolError("ERR_INVALID_MOUSE_STATE", f"Invalid click state: {state}")

def validate_keyboard_key(msg: Dict[str, Any]):
    if "key" not in msg or not isinstance(msg["key"], str):
        raise ProtocolError("ERR_INVALID_KEY", "Field 'key' must be a string")
    if "pressed" not in msg or not isinstance(msg["pressed"], bool):
        raise ProtocolError("ERR_INVALID_KEY_STATE", "Field 'pressed' must be a boolean")
