"""
AJS Remote Server 2.0 - Virtual Mouse & Keyboard Engine
Controls Linux cursor movement, clicks, scrolling, key presses, and text injection via evdev.
"""

import os
import time
from typing import Dict, Any, Optional
from ajs_server.logger import logger

try:
    import evdev
    from evdev import UInput, ecodes
    EVDEV_AVAILABLE = True
except ImportError:
    EVDEV_AVAILABLE = False
    UInput = None
    ecodes = None

# Keycode map
KEY_NAME_MAP = {}
if EVDEV_AVAILABLE:
    KEY_NAME_MAP = {
        "enter": ecodes.KEY_ENTER,
        "return": ecodes.KEY_ENTER,
        "space": ecodes.KEY_SPACE,
        "backspace": ecodes.KEY_BACKSPACE,
        "tab": ecodes.KEY_TAB,
        "esc": ecodes.KEY_ESC,
        "escape": ecodes.KEY_ESC,
        "shift": ecodes.KEY_LEFTSHIFT,
        "shift_left": ecodes.KEY_LEFTSHIFT,
        "shift_right": ecodes.KEY_RIGHTSHIFT,
        "ctrl": ecodes.KEY_LEFTCTRL,
        "ctrl_left": ecodes.KEY_LEFTCTRL,
        "ctrl_right": ecodes.KEY_RIGHTCTRL,
        "alt": ecodes.KEY_LEFTALT,
        "alt_left": ecodes.KEY_LEFTALT,
        "alt_right": ecodes.KEY_RIGHTALT,
        "super": ecodes.KEY_LEFTMETA,
        "meta": ecodes.KEY_LEFTMETA,
        "up": ecodes.KEY_UP,
        "down": ecodes.KEY_DOWN,
        "left": ecodes.KEY_LEFT,
        "right": ecodes.KEY_RIGHT,
        "delete": ecodes.KEY_DELETE,
        "home": ecodes.KEY_HOME,
        "end": ecodes.KEY_END,
        "pageup": ecodes.KEY_PAGEUP,
        "pagedown": ecodes.KEY_PAGEDOWN,
        "capslock": ecodes.KEY_CAPSLOCK,
        "volumeup": ecodes.KEY_VOLUMEUP,
        "volumedown": ecodes.KEY_VOLUMEDOWN,
        "mute": ecodes.KEY_MUTE
    }
    # Add A-Z and 0-9
    for c in "abcdefghijklmnopqrstuvwxyz":
        code = getattr(ecodes, f"KEY_{c.upper()}", None)
        if code:
            KEY_NAME_MAP[c] = code
    for n in "0123456789":
        code = getattr(ecodes, f"KEY_{n}", None)
        if code:
            KEY_NAME_MAP[n] = code
    for i in range(1, 13):
        code = getattr(ecodes, f"KEY_F{i}", None)
        if code:
            KEY_NAME_MAP[f"f{i}"] = code

class MouseKeyboardEngine:
    def __init__(self, force_simulation: bool = False):
        self.force_simulation = force_simulation
        self.mouse_dev: Optional[Any] = None
        self.kb_dev: Optional[Any] = None
        self.is_active = False
        self._pressed_keys = set()
        self._init_devices()

    def _init_devices(self):
        if self.force_simulation or not EVDEV_AVAILABLE:
            return

        uinput_path = "/dev/uinput"
        if not (os.path.exists(uinput_path) and os.access(uinput_path, os.W_OK)):
            return

        try:
            # Mouse capability
            mouse_caps = {
                ecodes.EV_REL: [ecodes.REL_X, ecodes.REL_Y, ecodes.REL_WHEEL, ecodes.REL_HWHEEL],
                ecodes.EV_KEY: [ecodes.BTN_LEFT, ecodes.BTN_RIGHT, ecodes.BTN_MIDDLE]
            }
            self.mouse_dev = UInput(mouse_caps, name="AJS Virtual Mouse")

            # Keyboard capability
            kb_keys = list(KEY_NAME_MAP.values())
            kb_caps = {
                ecodes.EV_KEY: list(set(kb_keys))
            }
            self.kb_dev = UInput(kb_caps, name="AJS Virtual Keyboard")
            self.is_active = True
            logger.info("AJS Virtual Mouse & Keyboard initialized", category="input")
        except Exception as e:
            self.is_active = False
            logger.warning(f"Failed to create mouse/keyboard uinput devices: {e}", category="input")

    def move_mouse(self, dx: float, dy: float):
        """Relative cursor motion."""
        int_dx = int(dx)
        int_dy = int(dy)
        if self.mouse_dev:
            self.mouse_dev.write(ecodes.EV_REL, ecodes.REL_X, int_dx)
            self.mouse_dev.write(ecodes.EV_REL, ecodes.REL_Y, int_dy)
            self.mouse_dev.syn()

    def click_mouse(self, button: str = "left", state: str = "click"):
        """Clicks, presses, or releases mouse buttons."""
        button = button.lower()
        state = state.lower()
        btn_code = ecodes.BTN_LEFT if button == "left" else (ecodes.BTN_RIGHT if button == "right" else ecodes.BTN_MIDDLE)

        if not self.mouse_dev:
            return

        if state == "click":
            self.mouse_dev.write(ecodes.EV_KEY, btn_code, 1)
            self.mouse_dev.syn()
            time.sleep(0.01)
            self.mouse_dev.write(ecodes.EV_KEY, btn_code, 0)
            self.mouse_dev.syn()
        elif state == "down":
            self.mouse_dev.write(ecodes.EV_KEY, btn_code, 1)
            self.mouse_dev.syn()
        elif state == "up":
            self.mouse_dev.write(ecodes.EV_KEY, btn_code, 0)
            self.mouse_dev.syn()

    def scroll_mouse(self, dy: float, dx: float = 0.0):
        """Scroll wheel events."""
        if not self.mouse_dev:
            return
        if dy != 0:
            self.mouse_dev.write(ecodes.EV_REL, ecodes.REL_WHEEL, int(dy))
        if dx != 0:
            self.mouse_dev.write(ecodes.EV_REL, ecodes.REL_HWHEEL, int(dx))
        self.mouse_dev.syn()

    def set_key(self, key_name: str, pressed: bool):
        """Press or release a key."""
        clean_key = key_name.lower().strip()
        code = KEY_NAME_MAP.get(clean_key)
        if not code:
            logger.debug(f"Unmapped key: {key_name}", category="input")
            return

        if pressed:
            self._pressed_keys.add(code)
        else:
            self._pressed_keys.discard(code)

        if self.kb_dev:
            self.kb_dev.write(ecodes.EV_KEY, code, 1 if pressed else 0)
            self.kb_dev.syn()

    def type_text(self, text: str):
        """Types string of text character by character."""
        if not self.kb_dev:
            return
        for char in text:
            lower = char.lower()
            code = KEY_NAME_MAP.get(lower)
            if not code:
                continue
            is_upper = char.isupper()
            if is_upper:
                self.kb_dev.write(ecodes.EV_KEY, ecodes.KEY_LEFTSHIFT, 1)
            self.kb_dev.write(ecodes.EV_KEY, code, 1)
            self.kb_dev.syn()
            time.sleep(0.005)
            self.kb_dev.write(ecodes.EV_KEY, code, 0)
            if is_upper:
                self.kb_dev.write(ecodes.EV_KEY, ecodes.KEY_LEFTSHIFT, 0)
            self.kb_dev.syn()
            time.sleep(0.005)

    def release_all(self):
        """Releases any stuck keys or mouse buttons on client disconnect."""
        if self.mouse_dev:
            for btn in (ecodes.BTN_LEFT, ecodes.BTN_RIGHT, ecodes.BTN_MIDDLE):
                self.mouse_dev.write(ecodes.EV_KEY, btn, 0)
            self.mouse_dev.syn()

        if self.kb_dev and self._pressed_keys:
            for code in list(self._pressed_keys):
                self.kb_dev.write(ecodes.EV_KEY, code, 0)
            self.kb_dev.syn()
            self._pressed_keys.clear()

    def close(self):
        self.release_all()
        if self.mouse_dev:
            try:
                self.mouse_dev.close()
            except Exception:
                pass
        if self.kb_dev:
            try:
                self.kb_dev.close()
            except Exception:
                pass
        self.is_active = False
