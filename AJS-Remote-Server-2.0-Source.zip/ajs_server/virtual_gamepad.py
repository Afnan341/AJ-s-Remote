"""
AJS Remote Server 2.0 - Virtual Gamepad Engine
Implements Linux kernel uinput virtual gamepad (Xbox 360 compatible).
Fully recognizable by Steam, Proton, Wine, RetroArch, and native Linux games.
"""

import math
import os
from typing import Dict, Any, Optional, Callable, Set, List, Tuple
from ajs_server.logger import logger
from ajs_server.config import DEFAULT_STICK_DEADZONE

try:
    import evdev
    from evdev import UInput, AbsInfo, ecodes
    EVDEV_AVAILABLE = True
except ImportError:
    EVDEV_AVAILABLE = False
    UInput = None
    AbsInfo = None
    ecodes = None

class UInputPermissionError(Exception):
    """Raised when /dev/uinput is unavailable or lacks write permissions."""
    pass

class VirtualGamepad:
    def __init__(self, deadzone: float = DEFAULT_STICK_DEADZONE, force_simulation: bool = False):
        self.deadzone = deadzone
        self.force_simulation = force_simulation
        self.uinput_device: Optional[Any] = None
        self.is_hardware_active = False

        # Live input state tracker
        self.button_states: Dict[str, bool] = {
            "A": False, "B": False, "X": False, "Y": False,
            "DPAD_UP": False, "DPAD_DOWN": False, "DPAD_LEFT": False, "DPAD_RIGHT": False,
            "L1": False, "R1": False, "L2": False, "R2": False,
            "L3": False, "R3": False, "START": False, "SELECT": False, "MENU": False
        }
        self.axis_states: Dict[str, float] = {
            "LEFT_X": 0.0, "LEFT_Y": 0.0,
            "RIGHT_X": 0.0, "RIGHT_Y": 0.0,
            "TRIGGER_L": 0.0, "TRIGGER_R": 0.0
        }

        # Subscribers for live test visualizers
        self.listeners: List[Callable[[Dict[str, Any]], None]] = []

        # Mapping tables
        self._init_mappings()
        self._init_device()

    def _init_mappings(self):
        if not EVDEV_AVAILABLE:
            return

        self.btn_map = {
            "A": ecodes.BTN_A,
            "B": ecodes.BTN_B,
            "X": ecodes.BTN_X,
            "Y": ecodes.BTN_Y,
            "L1": ecodes.BTN_TL,
            "R1": ecodes.BTN_TR,
            "SELECT": ecodes.BTN_SELECT,
            "START": ecodes.BTN_START,
            "MENU": ecodes.BTN_MODE,
            "HOME": ecodes.BTN_MODE,
            "L3": ecodes.BTN_THUMBL,
            "R3": ecodes.BTN_THUMBR
        }

    def _init_device(self):
        if self.force_simulation or not EVDEV_AVAILABLE:
            logger.info("VirtualGamepad operating in simulation/test mode", category="gamepad")
            return

        uinput_path = "/dev/uinput"
        if not os.path.exists(uinput_path):
            logger.warning("/dev/uinput does not exist. Udev permissions or kernel module missing.", category="gamepad")
            return

        if not os.access(uinput_path, os.W_OK):
            logger.warning("/dev/uinput is not writable by current user.", category="gamepad")
            return

        try:
            # Full Xbox 360 controller capabilities
            capabilities = {
                ecodes.EV_KEY: [
                    ecodes.BTN_A, ecodes.BTN_B, ecodes.BTN_X, ecodes.BTN_Y,
                    ecodes.BTN_TL, ecodes.BTN_TR, ecodes.BTN_SELECT, ecodes.BTN_START,
                    ecodes.BTN_MODE, ecodes.BTN_THUMBL, ecodes.BTN_THUMBR
                ],
                ecodes.EV_ABS: [
                    (ecodes.ABS_X, AbsInfo(value=0, min=-32767, max=32767, fuzz=16, flat=128, resolution=0)),
                    (ecodes.ABS_Y, AbsInfo(value=0, min=-32767, max=32767, fuzz=16, flat=128, resolution=0)),
                    (ecodes.ABS_RX, AbsInfo(value=0, min=-32767, max=32767, fuzz=16, flat=128, resolution=0)),
                    (ecodes.ABS_RY, AbsInfo(value=0, min=-32767, max=32767, fuzz=16, flat=128, resolution=0)),
                    (ecodes.ABS_Z, AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0)),       # Trigger L
                    (ecodes.ABS_RZ, AbsInfo(value=0, min=0, max=255, fuzz=0, flat=0, resolution=0)),      # Trigger R
                    (ecodes.ABS_HAT0X, AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0)),     # D-pad X
                    (ecodes.ABS_HAT0Y, AbsInfo(value=0, min=-1, max=1, fuzz=0, flat=0, resolution=0))      # D-pad Y
                ]
            }

            self.uinput_device = UInput(
                events=capabilities,
                name="Microsoft X-Box 360 pad (AJS Virtual)",
                vendor=0x045e,
                product=0x028e,
                version=0x0110
            )
            self.is_hardware_active = True
            logger.info("Linux kernel uinput virtual gamepad created successfully!", category="gamepad")
        except Exception as e:
            self.is_hardware_active = False
            logger.warning(f"Could not initialize uinput hardware device: {e}", category="gamepad")

    def subscribe(self, callback: Callable[[Dict[str, Any]], None]):
        if callback not in self.listeners:
            self.listeners.append(callback)

    def unsubscribe(self, callback: Callable[[Dict[str, Any]], None]):
        if callback in self.listeners:
            self.listeners.remove(callback)

    def _notify_listeners(self, event_type: str, data: Dict[str, Any]):
        event = {"type": event_type, "timestamp": os.times()[4], **data}
        for cb in list(self.listeners):
            try:
                cb(event)
            except Exception:
                pass

    def apply_deadzone(self, x: float, y: float) -> Tuple[float, float]:
        """Applies radial deadzone and smooth rescale."""
        magnitude = math.sqrt(x * x + y * y)
        if magnitude < self.deadzone:
            return 0.0, 0.0
        # Rescale smoothly from edge of deadzone to 1.0
        scale = (magnitude - self.deadzone) / (1.0 - self.deadzone)
        scale = min(1.0, scale) / magnitude
        return x * scale, y * scale

    def set_button(self, button: str, pressed: bool):
        """Sets digital button state."""
        button = button.upper()
        self.button_states[button] = pressed

        # Handle D-pad via HAT0 axes
        if button.startswith("DPAD_"):
            self._update_dpad()
        elif button in ("L2", "R2") and self.uinput_device:
            # Digital press of trigger
            trigger_val = 255 if pressed else 0
            axis_code = ecodes.ABS_Z if button == "L2" else ecodes.ABS_RZ
            self.uinput_device.write(ecodes.EV_ABS, axis_code, trigger_val)
            self.uinput_device.syn()
        elif button in self.btn_map and self.uinput_device:
            btn_code = self.btn_map[button]
            self.uinput_device.write(ecodes.EV_KEY, btn_code, 1 if pressed else 0)
            self.uinput_device.syn()

        self._notify_listeners("controller.button", {"button": button, "pressed": pressed})

    def _update_dpad(self):
        """Calculates and dispatches D-pad HAT axes."""
        hat_x = 0
        if self.button_states.get("DPAD_LEFT"):
            hat_x -= 1
        if self.button_states.get("DPAD_RIGHT"):
            hat_x += 1

        hat_y = 0
        if self.button_states.get("DPAD_UP"):
            hat_y -= 1
        if self.button_states.get("DPAD_DOWN"):
            hat_y += 1

        if self.uinput_device:
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_HAT0X, hat_x)
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_HAT0Y, hat_y)
            self.uinput_device.syn()

    def set_axis(self, axis: str, value: float):
        """Sets analog axis value [-1.0..1.0] or [0.0..1.0] for triggers."""
        axis = axis.upper()
        self.axis_states[axis] = value

        if not self.uinput_device:
            self._notify_listeners("controller.axis", {"axis": axis, "value": value})
            return

        if axis in ("LEFT_X", "LEFT_Y"):
            lx, ly = self.apply_deadzone(self.axis_states["LEFT_X"], self.axis_states["LEFT_Y"])
            ev_x = int(lx * 32767)
            ev_y = int(ly * 32767)
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_X, ev_x)
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_Y, ev_y)
            self.uinput_device.syn()

        elif axis in ("RIGHT_X", "RIGHT_Y"):
            rx, ry = self.apply_deadzone(self.axis_states["RIGHT_X"], self.axis_states["RIGHT_Y"])
            ev_rx = int(rx * 32767)
            ev_ry = int(ry * 32767)
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_RX, ev_rx)
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_RY, ev_ry)
            self.uinput_device.syn()

        elif axis == "TRIGGER_L":
            val = max(0.0, min(1.0, value))
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_Z, int(val * 255))
            self.uinput_device.syn()

        elif axis == "TRIGGER_R":
            val = max(0.0, min(1.0, value))
            self.uinput_device.write(ecodes.EV_ABS, ecodes.ABS_RZ, int(val * 255))
            self.uinput_device.syn()

        self._notify_listeners("controller.axis", {"axis": axis, "value": value})

    def release_all(self):
        """
        CRITICAL: Releases every pressed button and resets axes to zero.
        Prevents stuck buttons and infinite spinning when phone disconnects.
        """
        logger.info("Releasing all gamepad buttons and resetting axes to neutral", category="gamepad")
        for btn in list(self.button_states.keys()):
            if self.button_states[btn]:
                self.set_button(btn, False)

        for axis in list(self.axis_states.keys()):
            self.set_axis(axis, 0.0)

        if self.uinput_device:
            self.uinput_device.syn()

    def get_state(self) -> Dict[str, Any]:
        """Returns snapshot of all buttons and axes for GUI test screen."""
        return {
            "buttons": dict(self.button_states),
            "axes": dict(self.axis_states),
            "hardware_active": self.is_hardware_active
        }

    def close(self):
        """Cleanly releases uinput kernel device."""
        self.release_all()
        if self.uinput_device:
            try:
                self.uinput_device.close()
            except Exception:
                pass
            self.uinput_device = None
            self.is_hardware_active = False
