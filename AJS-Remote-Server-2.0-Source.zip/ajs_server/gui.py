"""
AJS Remote Server 2.0 - PySide6 Desktop GUI
Futuristic gaming interface (#050505, #FF2020, #151515) with live controller test visualizer.
"""

import sys
import os
import asyncio
import threading
from typing import Optional

try:
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QLabel, QPushButton, QStackedWidget, QTableWidget, QTableWidgetItem,
        QTextEdit, QLineEdit, QCheckBox, QSlider, QFrame, QScrollArea, QHeaderView
    )
    from PySide6.QtCore import Qt, QTimer, Signal, QObject
    from PySide6.QtGui import QFont, QPixmap, QImage, QColor, QPainter, QBrush, QPen
    PYSIDE6_AVAILABLE = True
except ImportError:
    PYSIDE6_AVAILABLE = False

from ajs_server.config import APP_DISPLAY_NAME, DEFAULT_PORT
from ajs_server.logger import logger
from ajs_server.database import db
from ajs_server.auth import auth_manager
from ajs_server.qr_generator import get_local_ip, build_qr_payload, generate_qr_image

# Futuristic Dark Gaming QSS Stylesheet
GAMING_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #050505;
    color: #E0E0E0;
    font-family: 'Segoe UI', 'Ubuntu', 'Roboto', sans-serif;
    font-size: 13px;
}

/* Sidebar navigation */
QFrame#Sidebar {
    background-color: #101010;
    border-right: 1px solid #252525;
}

QPushButton.NavButton {
    background-color: transparent;
    color: #A0A0A0;
    text-align: left;
    padding: 12px 18px;
    font-size: 13px;
    font-weight: bold;
    border: none;
    border-left: 3px solid transparent;
    border-radius: 4px;
}

QPushButton.NavButton:hover {
    background-color: #181818;
    color: #FFFFFF;
}

QPushButton.NavButton[active="true"] {
    background-color: #1A1A1A;
    color: #FF2020;
    border-left: 3px solid #FF2020;
}

/* Rounded Dark Panels */
QFrame.CardPanel {
    background-color: #151515;
    border: 1px solid #262626;
    border-radius: 10px;
    padding: 16px;
}

QFrame.CardPanel:hover {
    border: 1px solid #3A3A3A;
}

/* Futuristic Red Primary Buttons */
QPushButton.PrimaryBtn {
    background-color: #FF2020;
    color: #FFFFFF;
    font-weight: bold;
    padding: 10px 20px;
    border-radius: 6px;
    border: none;
}

QPushButton.PrimaryBtn:hover {
    background-color: #E01818;
}

QPushButton.PrimaryBtn:pressed {
    background-color: #B51010;
}

QPushButton.SecondaryBtn {
    background-color: #222222;
    color: #FFFFFF;
    font-weight: bold;
    padding: 10px 18px;
    border-radius: 6px;
    border: 1px solid #333333;
}

QPushButton.SecondaryBtn:hover {
    background-color: #2D2D2D;
    border-color: #FF2020;
}

/* Tables */
QTableWidget {
    background-color: #121212;
    border: 1px solid #222222;
    gridline-color: #1F1F1F;
    border-radius: 6px;
}

QHeaderView::section {
    background-color: #181818;
    color: #888888;
    padding: 8px;
    font-weight: bold;
    border: none;
    border-bottom: 1px solid #282828;
}

/* Text and Inputs */
QLineEdit, QTextEdit {
    background-color: #111111;
    color: #FFFFFF;
    border: 1px solid #2A2A2A;
    border-radius: 6px;
    padding: 8px 12px;
}

QLineEdit:focus, QTextEdit:focus {
    border: 1px solid #FF2020;
}
"""

if PYSIDE6_AVAILABLE:
    class GamepadCanvas(QWidget):
        """Visual representation of gamepad with live highlighting."""
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumSize(460, 280)
            self.buttons = {}
            self.axes = {
                "LEFT_X": 0.0, "LEFT_Y": 0.0,
                "RIGHT_X": 0.0, "RIGHT_Y": 0.0,
                "TRIGGER_L": 0.0, "TRIGGER_R": 0.0
            }

        def update_state(self, buttons, axes):
            self.buttons = buttons
            self.axes = axes
            self.update()

        def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)

            # Draw Gamepad Body Outline
            pen = QPen(QColor("#FF2020"), 2)
            brush = QBrush(QColor("#151515"))
            painter.setPen(pen)
            painter.setBrush(brush)
            painter.drawRoundedRect(40, 40, 380, 200, 40, 40)

            # Left Joystick
            lx = 120 + int(self.axes.get("LEFT_X", 0.0) * 30)
            ly = 130 + int(self.axes.get("LEFT_Y", 0.0) * 30)
            painter.setPen(QPen(QColor("#333333"), 2))
            painter.setBrush(QBrush(QColor("#0A0A0A")))
            painter.drawEllipse(85, 95, 70, 70)  # Stick base
            painter.setPen(QPen(QColor("#FF2020"), 2))
            painter.setBrush(QBrush(QColor("#FF2020" if self.buttons.get("L3") else "#282828")))
            painter.drawEllipse(lx - 15, ly - 15, 30, 30)

            # Right Joystick
            rx = 260 + int(self.axes.get("RIGHT_X", 0.0) * 30)
            ry = 160 + int(self.axes.get("RIGHT_Y", 0.0) * 30)
            painter.setPen(QPen(QColor("#333333"), 2))
            painter.setBrush(QBrush(QColor("#0A0A0A")))
            painter.drawEllipse(225, 125, 70, 70)
            painter.setPen(QPen(QColor("#FF2020"), 2))
            painter.setBrush(QBrush(QColor("#FF2020" if self.buttons.get("R3") else "#282828")))
            painter.drawEllipse(rx - 15, ry - 15, 30, 30)

            # D-Pad
            dpad_center_x, dpad_center_y = 190, 160
            for name, ox, oy in [("DPAD_UP", 0, -22), ("DPAD_DOWN", 0, 22), ("DPAD_LEFT", -22, 0), ("DPAD_RIGHT", 22, 0)]:
                pressed = self.buttons.get(name, False)
                painter.setBrush(QBrush(QColor("#FF2020" if pressed else "#222222")))
                painter.setPen(QPen(QColor("#FF2020" if pressed else "#444444"), 1))
                painter.drawRect(dpad_center_x + ox - 8, dpad_center_y + oy - 8, 16, 16)

            # ABXY Buttons
            abxy_coords = {
                "Y": (330, 95), "X": (305, 120), "B": (355, 120), "A": (330, 145)
            }
            colors = {"A": "#00FF66", "B": "#FF3333", "X": "#3399FF", "Y": "#FFCC00"}
            for btn, (bx, by) in abxy_coords.items():
                pressed = self.buttons.get(btn, False)
                painter.setBrush(QBrush(QColor(colors[btn] if pressed else "#222222")))
                painter.setPen(QPen(QColor(colors[btn] if pressed else "#444444"), 2 if pressed else 1))
                painter.drawEllipse(bx - 12, by - 12, 24, 24)
                painter.setPen(QPen(QColor("#000000" if pressed else "#AAAAAA")))
                painter.drawText(bx - 4, by + 4, btn)

            # Bumpers L1 / R1
            for name, x, w in [("L1", 70, 80), ("R1", 310, 80)]:
                pressed = self.buttons.get(name, False)
                painter.setBrush(QBrush(QColor("#FF2020" if pressed else "#222222")))
                painter.setPen(QPen(QColor("#FF2020" if pressed else "#444444"), 1))
                painter.drawRoundedRect(x, 20, w, 16, 4, 4)
                painter.setPen(QPen(QColor("#FFFFFF")))
                painter.drawText(x + 28, 33, name)

            # Triggers L2 / R2 bars
            tl_val = self.axes.get("TRIGGER_L", 0.0)
            tr_val = self.axes.get("TRIGGER_R", 0.0)
            painter.setPen(QPen(QColor("#444444"), 1))
            painter.setBrush(QBrush(QColor("#111111")))
            painter.drawRect(70, 6, 80, 10)
            painter.drawRect(310, 6, 80, 10)
            painter.setBrush(QBrush(QColor("#FF2020")))
            painter.drawRect(70, 6, int(80 * tl_val), 10)
            painter.drawRect(310, 6, int(80 * tr_val), 10)

    class DesktopMainWindow(QMainWindow):
        def __init__(self, server_instance=None):
            super().__init__()
            self.server = server_instance
            self.setWindowTitle(APP_DISPLAY_NAME)
            self.resize(1020, 680)
            self.setStyleSheet(GAMING_STYLESHEET)
            self._init_ui()

            # Refresh timer
            self.timer = QTimer(self)
            self.timer.timeout.connect(self._on_refresh_tick)
            self.timer.start(100)  # 10 Hz UI refresh

        def _init_ui(self):
            root = QWidget()
            layout = QHBoxLayout(root)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.setSpacing(0)

            # Sidebar
            sidebar = QFrame()
            sidebar.setObjectName("Sidebar")
            sidebar.setFixedWidth(230)
            side_layout = QVBoxLayout(sidebar)
            side_layout.setContentsMargins(14, 20, 14, 20)
            side_layout.setSpacing(8)

            logo = QLabel("AJS REMOTE\nSERVER 2.0")
            logo.setStyleSheet("color: #FF2020; font-size: 16px; font-weight: 900; letter-spacing: 1px;")
            side_layout.addWidget(logo)
            side_layout.addSpacing(16)

            self.nav_btns = []
            screens = [
                ("Dashboard", 0),
                ("Connect Phone", 1),
                ("Controller Test", 2),
                ("Settings", 3),
                ("Activity Log", 4)
            ]
            for label, idx in screens:
                btn = QPushButton(label)
                btn.setProperty("class", "NavButton")
                btn.clicked.connect(lambda checked=False, i=idx: self._switch_screen(i))
                side_layout.addWidget(btn)
                self.nav_btns.append(btn)

            side_layout.addStretch()

            # Server status indicator in sidebar
            self.sidebar_status = QLabel("Server: Online")
            self.sidebar_status.setStyleSheet("color: #00FF66; font-size: 11px;")
            side_layout.addWidget(self.sidebar_status)

            layout.addWidget(sidebar)

            # Screen Stack
            self.stack = QStackedWidget()
            self.stack.addWidget(self._create_dashboard_screen())
            self.stack.addWidget(self._create_connect_screen())
            self.stack.addWidget(self._create_controller_screen())
            self.stack.addWidget(self._create_settings_screen())
            self.stack.addWidget(self._create_log_screen())
            layout.addWidget(self.stack)

            self.setCentralWidget(root)
            self._switch_screen(0)

        def _switch_screen(self, index: int):
            self.stack.setCurrentIndex(index)
            for i, btn in enumerate(self.nav_btns):
                btn.setProperty("active", "true" if i == index else "false")
                btn.style().unpolish(btn)
                btn.style().polish(btn)

        def _create_dashboard_screen(self) -> QWidget:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(30, 30, 30, 30)
            l.setSpacing(20)

            title = QLabel("Dashboard")
            title.setStyleSheet("font-size: 24px; font-weight: bold; color: #FFFFFF;")
            l.addWidget(title)

            # Stat Cards Grid
            grid = QHBoxLayout()
            self.dash_status_card = QLabel("Status\nOnline")
            self.dash_ip_card = QLabel(f"IP Address\n{get_local_ip()}")
            self.dash_port_card = QLabel(f"Port\n{DEFAULT_PORT}")
            self.dash_clients_card = QLabel("Connected Devices\n0")

            for card in (self.dash_status_card, self.dash_ip_card, self.dash_port_card, self.dash_clients_card):
                card.setProperty("class", "CardPanel")
                card.setStyleSheet("background-color: #151515; border: 1px solid #262626; border-radius: 8px; padding: 14px; font-weight: bold; font-size: 14px;")
                grid.addWidget(card)
            l.addLayout(grid)

            # Connected Devices Table
            dev_title = QLabel("Connected Phone Controllers")
            dev_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #FFFFFF; margin-top: 10px;")
            l.addWidget(dev_title)

            self.device_table = QTableWidget(0, 4)
            self.device_table.setHorizontalHeaderLabels(["Device Name", "IP Address", "Controller Status", "Action"])
            self.device_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
            l.addWidget(self.device_table)

            l.addStretch()
            return w

        def _create_connect_screen(self) -> QWidget:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(30, 30, 30, 30)
            l.setSpacing(20)

            title = QLabel("Connect Phone")
            title.setStyleSheet("font-size: 24px; font-weight: bold; color: #FFFFFF;")
            l.addWidget(title)

            content = QHBoxLayout()

            # QR Code Image Frame
            qr_frame = QFrame()
            qr_frame.setProperty("class", "CardPanel")
            qr_layout = QVBoxLayout(qr_frame)
            self.qr_label = QLabel()
            self.qr_label.setFixedSize(220, 220)
            self.qr_label.setScaledContents(True)
            self._update_qr_image()
            qr_layout.addWidget(self.qr_label)
            content.addWidget(qr_frame)

            # Info & PIN
            info_frame = QFrame()
            info_frame.setProperty("class", "CardPanel")
            info_layout = QVBoxLayout(info_frame)
            info_layout.setSpacing(14)

            ip_lbl = QLabel(f"Server IP:  <b style='color:#FF2020;'>{get_local_ip()}</b>")
            port_lbl = QLabel(f"Port:  <b style='color:#FFFFFF;'>{DEFAULT_PORT}</b>")
            ip_lbl.setStyleSheet("font-size: 15px;")
            port_lbl.setStyleSheet("font-size: 15px;")
            info_layout.addWidget(ip_lbl)
            info_layout.addWidget(port_lbl)

            pin_box = QHBoxLayout()
            self.pin_label = QLabel(f"PIN:  <b style='font-size: 22px; color: #00FF66;'>{auth_manager.get_current_pin()}</b>")
            new_pin_btn = QPushButton("New PIN")
            new_pin_btn.setProperty("class", "SecondaryBtn")
            new_pin_btn.clicked.connect(self._generate_new_pin)
            pin_box.addWidget(self.pin_label)
            pin_box.addWidget(new_pin_btn)
            info_layout.addLayout(pin_box)

            instructions = QLabel(
                "Instructions:\n"
                "1. Connect Android phone to the same Wi-Fi.\n"
                "2. Open AJ's Remote Android app.\n"
                "3. Tap 'Scan QR' and point camera at screen.\n"
                "4. Enter the 6-digit PIN when prompted."
            )
            instructions.setStyleSheet("color: #888888; font-size: 12px; line-height: 1.5;")
            info_layout.addWidget(instructions)
            content.addWidget(info_frame)

            l.addLayout(content)
            l.addStretch()
            return w

        def _update_qr_image(self):
            payload = build_qr_payload(port=DEFAULT_PORT)
            img = generate_qr_image(payload)
            qimage = QImage(img.tobytes(), img.size[0], img.size[1], QImage.Format_RGB888)
            pix = QPixmap.fromImage(qimage)
            self.qr_label.setPixmap(pix)

        def _generate_new_pin(self):
            new_pin = auth_manager.generate_new_pin()
            self.pin_label.setText(f"PIN:  <b style='font-size: 22px; color: #00FF66;'>{new_pin}</b>")
            self._update_qr_image()

        def _create_controller_screen(self) -> QWidget:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(30, 30, 30, 30)
            l.setSpacing(14)

            title = QLabel("Controller Live Test")
            title.setStyleSheet("font-size: 24px; font-weight: bold; color: #FFFFFF;")
            l.addWidget(title)

            desc = QLabel("Displays live button presses and analog thumbstick movements from your phone.")
            desc.setStyleSheet("color: #888888;")
            l.addWidget(desc)

            self.gamepad_canvas = GamepadCanvas()
            l.addWidget(self.gamepad_canvas)
            l.addStretch()
            return w

        def _create_settings_screen(self) -> QWidget:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(30, 30, 30, 30)
            l.setSpacing(14)

            title = QLabel("Settings")
            title.setStyleSheet("font-size: 24px; font-weight: bold; color: #FFFFFF;")
            l.addWidget(title)

            form = QFrame()
            form.setProperty("class", "CardPanel")
            fl = QVBoxLayout(form)
            fl.setSpacing(14)

            port_box = QHBoxLayout()
            port_box.addWidget(QLabel("Server WebSocket Port:"))
            self.port_edit = QLineEdit(str(DEFAULT_PORT))
            self.port_edit.setFixedWidth(120)
            port_box.addWidget(self.port_edit)
            fl.addLayout(port_box)

            self.autostart_chk = QCheckBox("Start server automatically when system boots")
            fl.addWidget(self.autostart_chk)

            save_btn = QPushButton("Save Settings")
            save_btn.setProperty("class", "PrimaryBtn")
            save_btn.clicked.connect(self._save_settings)
            fl.addWidget(save_btn)

            l.addWidget(form)
            l.addStretch()
            return w

        def _save_settings(self):
            db.set_setting("server_port", self.port_edit.text().strip())
            db.set_setting("auto_start", "true" if self.autostart_chk.isChecked() else "false")
            logger.info("Server settings updated", category="settings")

        def _create_log_screen(self) -> QWidget:
            w = QWidget()
            l = QVBoxLayout(w)
            l.setContentsMargins(30, 30, 30, 30)
            l.setSpacing(14)

            title = QLabel("Activity Log")
            title.setStyleSheet("font-size: 24px; font-weight: bold; color: #FFFFFF;")
            l.addWidget(title)

            self.log_text = QTextEdit()
            self.log_text.setReadOnly(True)
            l.addWidget(self.log_text)

            btn_box = QHBoxLayout()
            clear_btn = QPushButton("Clear Log")
            clear_btn.setProperty("class", "SecondaryBtn")
            clear_btn.clicked.connect(lambda: (logger.clear_logs(), self.log_text.clear()))
            btn_box.addWidget(clear_btn)
            btn_box.addStretch()
            l.addLayout(btn_box)

            return w

        def _on_refresh_tick(self):
            # Update live gamepad canvas
            if self.server and hasattr(self.server, "gamepad"):
                gp = self.server.gamepad
                self.gamepad_canvas.update_state(gp.button_states, gp.axis_states)

            # Update logs
            entries = logger.get_logs(limit=40)
            formatted = "\n".join([f"[{e['timestamp'][11:19]}] [{e['level']}] {e['message']}" for e in entries])
            if self.log_text.toPlainText() != formatted:
                self.log_text.setPlainText(formatted)
                self.log_text.verticalScrollBar().setValue(self.log_text.verticalScrollBar().maximum())

def launch_desktop_gui(server_instance=None):
    """Launches the PySide6 desktop GUI."""
    if not PYSIDE6_AVAILABLE:
        print("PySide6 is not installed or GUI display server is not available.")
        print("Running in headless / terminal mode.")
        return False

    app = QApplication.instance() or QApplication(sys.argv)
    window = DesktopMainWindow(server_instance)
    window.show()
    return app.exec()
