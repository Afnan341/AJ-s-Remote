# AJS Remote Unified Wire Protocol Specification

**Version:** 1  
**Transport:** WebSocket (RFC 6455)  
**Encoding:** JSON UTF-8  
**Target Clients:** AJ's Remote Android Native Application & AJS Remote Server 2.0  

---

## 1. Overview & Connection Architecture

The AJ's Remote system links an Android phone to a Linux Mint / Ubuntu PC over the local Wi-Fi network.

```
[ Android Phone (AJ's Remote) ]
           │  1. Scan Server QR Code
           ▼
     Parses IP + Port
           │  2. Open WebSocket ws://<ip>:<port>
           ▼
[ AJS Remote Server 2.0 ]
           │  3. Handshake (`handshake.hello` <-> `handshake.welcome`)
           ▼
  Pairing Check
   ├── First time: `auth.pair` with 6-digit PIN -> receives persistent auth_token
   └── Reconnect:  `auth.login` with auth_token -> instant authentication
           │  4. Real-time Control Session
           ▼
   ├── Gamepad events (`controller.button`, `controller.axis`, `controller.bundle`)
   ├── Mouse & Keyboard (`mouse.move`, `mouse.click`, `mouse.scroll`, `keyboard.key`, `keyboard.text`)
   ├── Clipboard sync (`clipboard.sync`)
   └── File transfer (`file.start`, `file.chunk`, `file.finish`)
```

---

## 2. QR Code Connection Format

The server generates a structured JSON QR code. AJ's Remote Android reads this payload directly using its camera:

```json
{
  "app": "AJS Remote Server",
  "protocol_version": 1,
  "server_ip": "192.168.1.100",
  "port": 8765,
  "pairing_required": true,
  "session_hint": "optional_string"
}
```

### Fields:
- `app` (*string, required*): Must be `"AJS Remote Server"` or `"AJS Remote"`.
- `protocol_version` (*integer, required*): Protocol version (`1`).
- `server_ip` (*string, required*): IPv4 address of the Linux PC on the local network.
- `port` (*integer, required*): WebSocket server port (default `8765`).
- `pairing_required` (*boolean, required*): `true` if first-time 6-digit PIN is needed.

---

## 3. Session Lifecycle & Handshake

### 3.1 Handshake Hello (`handshake.hello`)
Sent by Android immediately upon opening WebSocket.

**Client Request:**
```json
{
  "type": "handshake.hello",
  "protocol_version": 1,
  "device_id": "pixel8_unique_hardware_id",
  "device_name": "Afnan's Pixel 8"
}
```

**Server Response (`handshake.welcome`):**
```json
{
  "type": "handshake.welcome",
  "protocol_version": 1,
  "server_version": "2.0.0",
  "server_name": "AJS Remote Server 2.0",
  "uinput_active": true
}
```

---

## 4. Authentication Messages

### 4.1 First-Time Pairing with PIN (`auth.pair`)
Sent when client has no saved token or pairing is requested.

**Client Request:**
```json
{
  "type": "auth.pair",
  "device_id": "pixel8_unique_hardware_id",
  "device_name": "Afnan's Pixel 8",
  "pin": "489201"
}
```

**Server Success Response (`auth.pair_response`):**
```json
{
  "type": "auth.pair_response",
  "success": true,
  "auth_token": "a8f3d820b92e41c4917a...",
  "message": "Pairing successful!"
}
```

**Server Failure Response:**
```json
{
  "type": "auth.pair_response",
  "success": false,
  "error": "Incorrect pairing PIN."
}
```

### 4.2 Reconnecting with Token (`auth.login`)
Returning devices authenticate silently using their stored token.

**Client Request:**
```json
{
  "type": "auth.login",
  "device_id": "pixel8_unique_hardware_id",
  "auth_token": "a8f3d820b92e41c4917a..."
}
```

**Server Response (`auth.login_response`):**
```json
{
  "type": "auth.login_response",
  "success": true,
  "device_name": "Afnan's Pixel 8"
}
```

---

## 5. Heartbeat & Watchdog

Both client and server maintain ping/pong heartbeats every 3 seconds. If no heartbeat or data is received for 10 seconds, the connection is closed and all held buttons/keys are reset immediately to prevent stuck inputs.

**Ping (Client -> Server):**
```json
{
  "type": "heartbeat.ping",
  "timestamp": 1730900000.123
}
```

**Pong (Server -> Client):**
```json
{
  "type": "heartbeat.pong",
  "client_timestamp": 1730900000.123,
  "server_time": 1730900000.125
}
```

---

## 6. Controller Input Messages

### 6.1 Digital Buttons (`controller.button`)
```json
{
  "type": "controller.button",
  "button": "A",
  "pressed": true
}
```
**Valid Button Values:**
- Action: `"A"`, `"B"`, `"X"`, `"Y"`
- D-Pad: `"DPAD_UP"`, `"DPAD_DOWN"`, `"DPAD_LEFT"`, `"DPAD_RIGHT"`
- Bumpers: `"L1"`, `"R1"`
- Triggers (digital click): `"L2"`, `"R2"`
- Stick clicks: `"L3"`, `"R3"`
- System: `"START"`, `"SELECT"`, `"MENU"`, `"HOME"`

### 6.2 Analog Axes (`controller.axis`)
```json
{
  "type": "controller.axis",
  "axis": "LEFT_X",
  "value": 0.45
}
```
**Valid Axis Values:**
- Thumbsticks (Range: `-1.0` to `1.0`):
  - `"LEFT_X"`, `"LEFT_Y"`
  - `"RIGHT_X"`, `"RIGHT_Y"`
- Analog Triggers (Range: `0.0` to `1.0`):
  - `"TRIGGER_L"`, `"TRIGGER_R"`

### 6.3 Low-Latency Input Bundle (`controller.bundle`)
Enables sending multiple buttons and axes in a single network packet for 60fps/120fps mobile touch sampling.
```json
{
  "type": "controller.bundle",
  "buttons": {
    "A": true,
    "L1": false
  },
  "axes": {
    "LEFT_X": 0.82,
    "LEFT_Y": -0.15,
    "TRIGGER_R": 0.50
  }
}
```

---

## 7. Mouse & Keyboard Messages

### 7.1 Mouse Movement (`mouse.move`)
```json
{
  "type": "mouse.move",
  "dx": 12.5,
  "dy": -8.0
}
```

### 7.2 Mouse Click (`mouse.click`)
```json
{
  "type": "mouse.click",
  "button": "left",
  "state": "click"
}
```
- `button`: `"left"`, `"right"`, `"middle"`
- `state`: `"click"`, `"down"`, `"up"`

### 7.3 Mouse Scroll (`mouse.scroll`)
```json
{
  "type": "mouse.scroll",
  "dy": 3.0,
  "dx": 0.0
}
```

### 7.4 Keyboard Key (`keyboard.key`)
```json
{
  "type": "keyboard.key",
  "key": "enter",
  "pressed": true
}
```

### 7.5 Keyboard Text Injection (`keyboard.text`)
```json
{
  "type": "keyboard.text",
  "text": "Hello Linux!"
}
```

---

## 8. Two-Way Clipboard Synchronization

To prevent infinite echo loops, every clipboard broadcast includes a SHA-256 hash. If the hash matches the last set clipboard value, it is silently ignored.

```json
{
  "type": "clipboard.sync",
  "direction": "to_pc",
  "text": "Copied text from Android phone",
  "hash": "b94d27b9934d3e08a52e52d7da7dabfac484efe37a5380ee9088f7ace2efcde9"
}
```

---

## 9. File Transfer Protocol

Transfers occur in chunked base64 packets with strict path traversal sanitation and SHA-256 integrity verification.

### Step 1: Transfer Initiation
```json
{
  "type": "file.start",
  "transfer_id": "tx_20261106_01",
  "filename": "screenshot.png",
  "file_size": 204800,
  "total_chunks": 4
}
```
**Server Response:**
`{"type": "file.accept", "transfer_id": "tx_20261106_01"}`

### Step 2: Chunk Transmission
```json
{
  "type": "file.chunk",
  "transfer_id": "tx_20261106_01",
  "chunk_index": 0,
  "data_b64": "iVBORw0KGgoAAAANSUhEUgAAA..."
}
```
**Server Acknowledgment:**
`{"type": "file.ack", "transfer_id": "tx_20261106_01", "chunks_received": 1, "progress": 0.25}`

### Step 3: Transfer Finalization
```json
{
  "type": "file.finish",
  "transfer_id": "tx_20261106_01",
  "sha256": "8a35560e208b5f3cf34..."
}
```
**Server Response:**
`{"type": "file.complete", "transfer_id": "tx_20261106_01", "saved_path": "/home/user/Downloads/AJS_Remote_Transfers/screenshot.png"}`

---

## 10. Error Handling & Codes

```json
{
  "type": "error",
  "code": "ERR_UNAUTHORIZED",
  "message": "Device is not authenticated. Please pair with PIN first."
}
```

### Standard Error Codes:
- `ERR_MALFORMED_JSON`: Request could not be parsed as JSON.
- `ERR_INVALID_SCHEMA`: Missing required fields or wrong data types.
- `ERR_UNAUTHORIZED`: Access to controls attempted before authentication.
- `ERR_RATE_LIMITED`: Too many failed PIN attempts. Wait 60 seconds.
- `ERR_INVALID_BUTTON`: Unrecognized gamepad button name.
- `ERR_INVALID_AXIS`: Unrecognized gamepad axis name.
- `ERR_AXIS_OUT_OF_RANGE`: Axis values exceeded valid normalized bounds.
- `ERR_PATH_TRAVERSAL`: Rejected file transfer containing malicious path components.
- `ERR_FILE_FINISH`: SHA-256 hash mismatch during file receipt.
