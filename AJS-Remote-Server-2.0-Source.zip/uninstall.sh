#!/usr/bin/env bash
# ==============================================================================
# AJS Remote Server 2.0 - Uninstaller Script
# ==============================================================================

set -e

GREEN="\033[92m"
RED="\033[91m"
RESET="\033[0m"

echo -e "${RED}Uninstalling AJS Remote Server 2.0...${RESET}"

if [ "$EUID" -ne 0 ]; then
    SUDO="sudo"
else
    SUDO=""
fi

$SUDO rm -rf /opt/ajs-remote-server
$SUDO rm -f /usr/local/bin/ajs-remote-server
$SUDO rm -f /usr/share/applications/ajs-remote-server.desktop
$SUDO rm -f /usr/share/icons/hicolor/256x256/apps/ajs-remote-server.png
$SUDO rm -f /etc/udev/rules.d/99-uinput.rules
$SUDO udevadm control --reload-rules || true

echo -e "${GREEN}AJS Remote Server 2.0 has been cleanly removed from your system.${RESET}"
