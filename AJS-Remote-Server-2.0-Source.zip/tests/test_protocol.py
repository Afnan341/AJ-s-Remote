"""
Tests for AJS Remote Protocol Specification & Schema Validation.
"""

import unittest
from ajs_server.protocol import (
    validate_message, validate_controller_button, validate_controller_axis,
    validate_mouse_move, validate_mouse_click, validate_keyboard_key,
    ProtocolError, MSG_HELLO, MSG_CTRL_BUTTON, MSG_CTRL_AXIS
)

class TestProtocol(unittest.TestCase):
    def test_basic_validation(self):
        valid, _ = validate_message({"type": MSG_HELLO})
        self.assertTrue(valid)

        valid, err = validate_message("not a dict")
        self.assertFalse(valid)

        valid, err = validate_message({})
        self.assertFalse(valid)

    def test_button_validation(self):
        # Valid buttons
        for btn in ["A", "B", "X", "Y", "DPAD_UP", "L1", "R2", "START", "SELECT"]:
            validate_controller_button({"type": MSG_CTRL_BUTTON, "button": btn, "pressed": True})
            validate_controller_button({"type": MSG_CTRL_BUTTON, "button": btn, "pressed": False})

        # Invalid button name
        with self.assertRaises(ProtocolError):
            validate_controller_button({"type": MSG_CTRL_BUTTON, "button": "INVALID_BTN", "pressed": True})

        # Invalid pressed state
        with self.assertRaises(ProtocolError):
            validate_controller_button({"type": MSG_CTRL_BUTTON, "button": "A", "pressed": "yes"})

    def test_axis_validation(self):
        # Valid thumbsticks [-1.0..1.0]
        validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "LEFT_X", "value": 0.5})
        validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "LEFT_Y", "value": -1.0})
        validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "RIGHT_X", "value": 1.0})

        # Out of range stick
        with self.assertRaises(ProtocolError):
            validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "LEFT_X", "value": 1.5})

        # Valid triggers [0.0..1.0]
        validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "TRIGGER_L", "value": 0.75})
        with self.assertRaises(ProtocolError):
            validate_controller_axis({"type": MSG_CTRL_AXIS, "axis": "TRIGGER_L", "value": -0.1})

    def test_mouse_and_keyboard_validation(self):
        validate_mouse_move({"dx": 10.5, "dy": -5.2})
        with self.assertRaises(ProtocolError):
            validate_mouse_move({"dx": "fast"})

        validate_mouse_click({"button": "left", "state": "click"})
        validate_mouse_click({"button": "right", "state": "down"})
        with self.assertRaises(ProtocolError):
            validate_mouse_click({"button": "fourth"})

        validate_keyboard_key({"key": "enter", "pressed": True})
        with self.assertRaises(ProtocolError):
            validate_keyboard_key({"key": 123, "pressed": True})

if __name__ == "__main__":
    unittest.main()
