"""
Tests for Structured QR Code Payload and Generation.
"""

import unittest
import json
from ajs_server.qr_generator import build_qr_payload, generate_qr_image, generate_qr_base64
from ajs_server.config import APP_NAME, PROTOCOL_VERSION

class TestQR(unittest.TestCase):
    def test_structured_json_format(self):
        payload = build_qr_payload(server_ip="192.168.1.120", port=8765, pairing_required=True)

        self.assertEqual(payload["app"], APP_NAME)
        self.assertEqual(payload["protocol_version"], PROTOCOL_VERSION)
        self.assertEqual(payload["server_ip"], "192.168.1.120")
        self.assertEqual(payload["port"], 8765)
        self.assertTrue(payload["pairing_required"])

    def test_qr_image_generation(self):
        payload = build_qr_payload(server_ip="192.168.1.120", port=8765)
        img = generate_qr_image(payload)
        self.assertIsNotNone(img)
        self.assertGreater(img.size[0], 100)

        b64 = generate_qr_base64(payload)
        self.assertTrue(b64.startswith("data:image/png;base64,"))

if __name__ == "__main__":
    unittest.main()
