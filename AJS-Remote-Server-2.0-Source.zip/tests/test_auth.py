"""
Tests for PIN generation, verification, token authentication, and rate limiting.
"""

import unittest
import time
from ajs_server.auth import AuthManager
from ajs_server.database import db

class TestAuth(unittest.TestCase):
    def setUp(self):
        self.auth = AuthManager()

    def test_pin_generation_and_validity(self):
        pin = self.auth.get_current_pin()
        self.assertEqual(len(pin), 6)
        self.assertTrue(pin.isdigit())

        # Test remaining time
        remaining = self.auth.get_pin_time_remaining()
        self.assertGreater(remaining, 200)

    def test_pin_verification_success(self):
        pin = self.auth.get_current_pin()
        success, token, err = self.auth.verify_pairing_pin("192.168.1.50", "phone_001", "Pixel 8", pin)
        self.assertTrue(success)
        self.assertIsNotNone(token)
        self.assertIsNone(err)

        # PIN should auto-rotate after successful pairing
        new_pin = self.auth.get_current_pin()
        self.assertNotEqual(pin, new_pin)

        # Token authentication should now succeed
        login_ok, login_err = self.auth.authenticate_token("192.168.1.50", "phone_001", token)
        self.assertTrue(login_ok)
        self.assertIsNone(login_err)

    def test_pin_verification_failure(self):
        success, token, err = self.auth.verify_pairing_pin("192.168.1.51", "phone_002", "Galaxy S24", "000000")
        self.assertFalse(success)
        self.assertIsNone(token)
        self.assertEqual(err, "Incorrect pairing PIN.")

    def test_rate_limiting(self):
        ip = "192.168.1.99"
        for _ in range(5):
            self.auth.verify_pairing_pin(ip, "phone_bad", "Bad Phone", "111111")

        # 6th attempt should be blocked by rate limiter
        self.assertTrue(self.auth.is_rate_limited(ip))
        success, _, err = self.auth.verify_pairing_pin(ip, "phone_bad", "Bad Phone", self.auth.get_current_pin())
        self.assertFalse(success)
        self.assertIn("Too many failed attempts", err)

if __name__ == "__main__":
    unittest.main()
