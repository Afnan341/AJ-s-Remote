"""
Tests for Virtual Gamepad Input, Analog Deadzones, and Stuck-Button Prevention.
"""

import unittest
from ajs_server.virtual_gamepad import VirtualGamepad

class TestVirtualGamepad(unittest.TestCase):
    def setUp(self):
        # Force simulation mode to test logic independently of hardware access
        self.gamepad = VirtualGamepad(deadzone=0.1, force_simulation=True)

    def tearDown(self):
        self.gamepad.close()

    def test_button_press_and_release(self):
        self.gamepad.set_button("A", True)
        self.assertTrue(self.gamepad.button_states["A"])

        self.gamepad.set_button("A", False)
        self.assertFalse(self.gamepad.button_states["A"])

    def test_simultaneous_button_presses(self):
        buttons = ["A", "B", "L1", "START", "DPAD_UP"]
        for btn in buttons:
            self.gamepad.set_button(btn, True)

        for btn in buttons:
            self.assertTrue(self.gamepad.button_states[btn])

    def test_analog_deadzone_and_scaling(self):
        # Inside deadzone (0.05 < 0.1) -> Snapped to 0.0
        x, y = self.gamepad.apply_deadzone(0.05, 0.0)
        self.assertEqual(x, 0.0)
        self.assertEqual(y, 0.0)

        # Outside deadzone (1.0) -> Scaled to 1.0
        x, y = self.gamepad.apply_deadzone(1.0, 0.0)
        self.assertAlmostEqual(x, 1.0, places=2)

    def test_stuck_button_prevention_on_disconnect(self):
        # Simulate user pressing buttons while phone disconnects
        self.gamepad.set_button("A", True)
        self.gamepad.set_button("X", True)
        self.gamepad.set_button("R1", True)
        self.gamepad.set_axis("LEFT_X", 0.95)
        self.gamepad.set_axis("TRIGGER_R", 0.8)

        # Trigger release_all (as occurs on device disconnection)
        self.gamepad.release_all()

        # All buttons MUST be False
        for btn, state in self.gamepad.button_states.items():
            self.assertFalse(state, f"Button {btn} was stuck active!")

        # All axes MUST be 0.0
        for axis, val in self.gamepad.axis_states.items():
            self.assertEqual(val, 0.0, f"Axis {axis} was not reset to 0.0!")

if __name__ == "__main__":
    unittest.main()
