"""
AJS Remote Server 2.0 - Comprehensive Test Suite Runner
Executes all unit and integration tests and prints structured results.
"""

import unittest
import sys
import os

# Ensure project root is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

def run_tests():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Discover and add test modules
    test_modules = [
        "tests.test_protocol",
        "tests.test_auth",
        "tests.test_gamepad",
        "tests.test_mouse_keyboard",
        "tests.test_clipboard",
        "tests.test_file_transfer",
        "tests.test_qr",
        "tests.test_server_lifecycle"
    ]

    for mod in test_modules:
        try:
            mod_suite = loader.loadTestsFromName(mod)
            suite.addTests(mod_suite)
        except Exception as e:
            print(f"Failed to load {mod}: {e}")

    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    print("\n" + "=" * 60)
    print(f"TESTS RUN:      {result.testsRun}")
    print(f"PASSED:         {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"FAILURES:       {len(result.failures)}")
    print(f"ERRORS:         {len(result.errors)}")
    print("=" * 60)

    return 0 if result.wasSuccessful() else 1

if __name__ == "__main__":
    sys.exit(run_tests())
