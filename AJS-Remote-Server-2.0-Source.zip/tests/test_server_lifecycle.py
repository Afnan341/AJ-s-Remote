"""
Tests for WebSocket Server Lifecycle, Authentication Handshake, and Client Disconnection.
"""

import asyncio
import unittest
import json
import websockets
from ajs_server.websocket_server import AjsWebSocketServer
from ajs_server.auth import auth_manager
from ajs_server.protocol import (
    MSG_HELLO, MSG_WELCOME, MSG_PAIR, MSG_PAIR_RESP,
    MSG_CTRL_BUTTON, MSG_CTRL_AXIS, MSG_PING, MSG_PONG, MSG_ERROR
)

class TestServerLifecycle(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.port = 9876  # Test port
        self.server = AjsWebSocketServer(host="127.0.0.1", port=self.port)
        await self.server.start()

    async def asyncTearDown(self):
        await self.server.stop()

    async def test_full_connection_and_auth_flow(self):
        uri = f"ws://127.0.0.1:{self.port}"
        async with websockets.connect(uri) as ws:
            # 1. Handshake Hello
            await ws.send(json.dumps({
                "type": MSG_HELLO,
                "protocol_version": 1,
                "device_id": "test_phone_42",
                "device_name": "Test Android"
            }))
            resp = json.loads(await ws.recv())
            self.assertEqual(resp["type"], MSG_WELCOME)

            # 2. Unauthorized attempt to send controller event before pairing
            await ws.send(json.dumps({
                "type": MSG_CTRL_BUTTON,
                "button": "A",
                "pressed": True
            }))
            err_resp = json.loads(await ws.recv())
            self.assertEqual(err_resp["type"], MSG_ERROR)
            self.assertEqual(err_resp["code"], "ERR_UNAUTHORIZED")

            # 3. Pairing Failure with wrong PIN
            await ws.send(json.dumps({
                "type": MSG_PAIR,
                "device_id": "test_phone_42",
                "pin": "000000"
            }))
            pair_fail = json.loads(await ws.recv())
            self.assertEqual(pair_fail["type"], MSG_PAIR_RESP)
            self.assertFalse(pair_fail["success"])

            # 4. Pairing Success with valid PIN
            valid_pin = auth_manager.get_current_pin()
            await ws.send(json.dumps({
                "type": MSG_PAIR,
                "device_id": "test_phone_42",
                "device_name": "Test Android",
                "pin": valid_pin
            }))
            pair_ok = json.loads(await ws.recv())
            self.assertEqual(pair_ok["type"], MSG_PAIR_RESP)
            self.assertTrue(pair_ok["success"])
            self.assertIn("auth_token", pair_ok)

            # 5. Authenticated Controller Event
            await ws.send(json.dumps({
                "type": MSG_CTRL_BUTTON,
                "button": "B",
                "pressed": True
            }))
            await asyncio.sleep(0.05)
            self.assertTrue(self.server.gamepad.button_states["B"])

            # 6. Heartbeat Ping / Pong
            await ws.send(json.dumps({"type": MSG_PING, "timestamp": 123456}))
            pong = json.loads(await ws.recv())
            self.assertEqual(pong["type"], MSG_PONG)

        # 7. Device disconnect - verify stuck-button prevention
        await asyncio.sleep(0.05)
        self.assertEqual(len(self.server.sessions), 0)
        # Button B must have been released automatically
        self.assertFalse(self.server.gamepad.button_states["B"])

if __name__ == "__main__":
    unittest.main()
