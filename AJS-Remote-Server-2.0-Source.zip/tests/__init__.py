"""
AJS Remote Server 2.0 - Test Suite
"""
