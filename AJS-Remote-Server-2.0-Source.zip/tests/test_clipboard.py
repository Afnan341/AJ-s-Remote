"""
Tests for Two-Way Clipboard Synchronization & Loop Prevention.
"""

import unittest
from ajs_server.clipboard import ClipboardManager

class TestClipboard(unittest.TestCase):
    def setUp(self):
        self.mgr = ClipboardManager()

    def test_loop_prevention(self):
        text = "Hello from AJ's Remote"
        h = self.mgr._hash(text)

        # First update should succeed
        res1 = self.mgr.set_pc_clipboard(text, h)
        self.assertTrue(res1)

        # Second update with same hash must return False to avoid infinite loop
        res2 = self.mgr.set_pc_clipboard(text, h)
        self.assertFalse(res2)

    def test_large_text_truncation(self):
        large_text = "A" * 1500000  # 1.5MB
        self.mgr.set_pc_clipboard(large_text)
        self.assertLessEqual(len(self.mgr._memory_clipboard), 1000000)

if __name__ == "__main__":
    unittest.main()
