"""
Tests for Mouse and Keyboard Engine.
"""

import unittest
from ajs_server.mouse_keyboard import MouseKeyboardEngine, KEY_NAME_MAP

class TestMouseKeyboard(unittest.TestCase):
    def setUp(self):
        self.engine = MouseKeyboardEngine(force_simulation=True)

    def tearDown(self):
        self.engine.close()

    def test_key_mappings(self):
        self.assertIn("enter", KEY_NAME_MAP)
        self.assertIn("space", KEY_NAME_MAP)
        self.assertIn("shift", KEY_NAME_MAP)
        self.assertIn("ctrl", KEY_NAME_MAP)
        self.assertIn("a", KEY_NAME_MAP)
        self.assertIn("z", KEY_NAME_MAP)

    def test_key_press_and_release(self):
        self.engine.set_key("enter", True)
        self.engine.set_key("enter", False)
        # Release all cleanup
        self.engine.release_all()
        self.assertEqual(len(self.engine._pressed_keys), 0)

    def test_mouse_actions(self):
        # Verify no exceptions raised during simulation
        self.engine.move_mouse(15, -20)
        self.engine.click_mouse("left", "click")
        self.engine.scroll_mouse(5)

if __name__ == "__main__":
    unittest.main()
