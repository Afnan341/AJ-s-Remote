"""
Tests for File Transfer, Path Traversal Defense, and Integrity Checks.
"""

import unittest
import tempfile
import base64
import hashlib
from pathlib import Path
from ajs_server.file_transfer import FileTransferManager

class TestFileTransfer(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.mgr = FileTransferManager(download_dir=Path(self.temp_dir.name))

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_path_traversal_prevention(self):
        # Attempting path traversal should be safely sanitized
        evil_name = "../../../etc/cron.d/evil_script.sh"
        self.mgr.start_incoming_transfer("tx_01", evil_name, 100, 1)
        session = self.mgr.active_sessions["tx_01"]

        # Filename must be sanitized to pure base name
        self.assertNotIn("..", session.filename)
        self.assertNotIn("/", session.filename)
        self.assertTrue(str(session.final_path).startswith(self.temp_dir.name))
        self.mgr.cancel_transfer("tx_01")

    def test_complete_transfer_flow(self):
        sample_data = b"AJS Remote Server 2.0 Test Payload"
        sha = hashlib.sha256(sample_data).hexdigest()
        b64 = base64.b64encode(sample_data).decode("utf-8")

        self.mgr.start_incoming_transfer("tx_02", "document.txt", len(sample_data), 1)
        self.mgr.process_incoming_chunk("tx_02", 0, b64)
        saved_path = self.mgr.finish_incoming_transfer("tx_02", sha)

        self.assertTrue(Path(saved_path).exists())
        with open(saved_path, "rb") as f:
            self.assertEqual(f.read(), sample_data)

if __name__ == "__main__":
    unittest.main()
