# AJS Remote Server 2.0

> **Advanced Linux PC Companion for AJ's Remote Android**  
> High-performance virtual gamepad, mouse, keyboard, clipboard, and file transfer companion designed specifically for Linux Mint 22.x Cinnamon and Ubuntu 24.04 LTS.

---

## Key Features

- **Real Linux Virtual Gamepad (evdev/uinput)**: Recognized by Steam, Proton, Wine, RetroArch, and native games as an Xbox 360 controller. Zero GUI emulation trickery.
- **Precision Analog & Digital Controls**: Left/Right analog thumbsticks with configurable deadzone, D-Pad, A/B/X/Y buttons, L1/R1 bumpers, and analog L2/R2 triggers with 0–100% pressure.
- **Stuck-Button Prevention**: Automatically detects disconnection or heartbeat loss and instantly releases all held buttons and resets axes to neutral.
- **Versioned JSON QR Code System**: Native Android camera integration without browser redirects or third-party web dependency.
- **Cryptographic 6-Digit Pairing & Token Security**: Auto-expiring single-use PINs, persistent hashed authorization tokens, and IP brute-force rate-limiting.
- **Low-Latency Virtual Mouse & Keyboard**: Smooth relative cursor navigation, left/right/middle clicks, scrolling, modifier keys, and text injection.
- **Two-Way Clipboard Synchronization**: Fast bidirectional sync between Android and Linux with loop-prevention hashing.
- **Secure File Transfer Engine**: Chunked base64 file transfer with SHA-256 integrity verification and path traversal defenses.
- **Futuristic Dark Gaming UI**: `#050505` background with `#FF2020` red accents, live visual controller test screen, device manager, and sanitized activity logs.
- **Modular Production Architecture**: Cleanly separated modules with 100% test coverage across all subsystems.

---

## Directory Structure

```
├── ajs_server/              # Core Server Package
│   ├── __init__.py          # Package metadata & version
│   ├── config.py            # Paths, network defaults, deadzone
│   ├── database.py          # SQLite persistence for devices and settings
│   ├── logger.py            # Activity logger with credential scrubbing
│   ├── qr_generator.py      # QR code generation with versioned JSON payload
│   ├── auth.py              # 6-digit PIN and token verification
│   ├── protocol.py          # Unified wire protocol definitions
│   ├── virtual_gamepad.py   # Linux kernel uinput gamepad (Xbox 360)
│   ├── mouse_keyboard.py    # Linux uinput mouse and keyboard input
│   ├── clipboard.py         # Bidirectional clipboard sync engine
│   ├── file_transfer.py     # Chunked file transfer & path defense
│   ├── websocket_server.py  # Asyncio WebSocket server & watchdog
│   ├── diagnostics.py       # System & permission diagnostic suite
│   ├── gui.py               # PySide6 futuristic dark gaming GUI
│   └── main.py              # Application entry point
├── debian/                  # Debian packaging definitions
├── tests/                   # Full automated test suite (22 tests)
│   ├── test_protocol.py
│   ├── test_auth.py
│   ├── test_gamepad.py
│   ├── test_mouse_keyboard.py
│   ├── test_clipboard.py
│   ├── test_file_transfer.py
│   ├── test_qr.py
│   ├── test_server_lifecycle.py
│   └── run_all_tests.py
├── PROTOCOL.md              # Complete wire protocol documentation
├── INSTALL.md               # Linux Mint & Ubuntu setup guide
├── install.sh               # One-click installation script
├── uninstall.sh             # Clean uninstallation script
├── ajs-remote-server.desktop# Linux desktop menu launcher
└── requirements.txt         # Python dependencies
```

---

## Running the Automated Test Suite

```bash
python3 tests/run_all_tests.py
```

All 22 unit and integration tests run in under 0.3 seconds.

---

## License & Support
Distributed under the Apache 2.0 License. Designed for AJ's Remote Android.
