# Installation & Setup Guide: AJS Remote Server 2.0

Target Platforms: **Linux Mint 22.x Cinnamon**, **Ubuntu 24.04 LTS**, Debian-based x86_64 distributions.

---

## 1. Quick Installation (Recommended)

### Option A: Install via Debian Package (.deb)
Double-click `ajs-remote-server_2.0.0_amd64.deb` in the file manager, or run:

```bash
sudo dpkg -i ajs-remote-server_2.0.0_amd64.deb
sudo apt-get install -f   # Resolves any missing dependencies automatically
```

After installation:
1. The application appears in your Linux Mint Cinnamon start menu under **Games** and **Accessories** as **AJS Remote Server 2.0**.
2. udev rules for virtual gamepad and mouse permissions are automatically configured.
3. Log out and log back in once if this is your first time using virtual uinput devices.

---

### Option B: One-Click Installer Script (`install.sh`)
If installing from the source archive:

```bash
chmod +x install.sh
./install.sh
```

The script will:
- Check Python 3 version and virtual input device support.
- Install required system packages (`python3-evdev`, `python3-websockets`, `python3-qrcode`, `python3-pil`).
- Create the `uinput` system group and add your user account.
- Configure `/etc/udev/rules.d/99-uinput.rules` with `MODE="0660", GROUP="uinput"`.
- Install the desktop launcher and high-res icon.

---

## 2. Linux Mint Permissions & uinput Configuration

AJS Remote Server 2.0 creates real virtual gamepads and mice via the Linux kernel's `uinput` subsystem without requiring you to launch the GUI as `root`.

If virtual gamepad creation shows a warning, verify:

### 1. Check if uinput module is loaded:
```bash
lsmod | grep uinput
# If not loaded:
sudo modprobe uinput
echo "uinput" | sudo tee -a /etc/modules
```

### 2. Configure udev rule:
```bash
echo 'KERNEL=="uinput", MODE="0660", GROUP="uinput", OPTIONS+="static_node=uinput"' | sudo tee /etc/udev/rules.d/99-uinput.rules
sudo groupadd -f uinput
sudo usermod -aG uinput $USER
sudo udevadm control --reload-rules
sudo udevadm trigger
```

*Note: Group membership updates require logging out and logging back in.*

---

## 3. Running AJS Remote Server

### From the Application Menu:
Click **Start Menu -> Games -> AJS Remote Server 2.0**

### From the Terminal (Desktop GUI):
```bash
python3 -m ajs_server.main
```

### From the Terminal (Headless / Server Mode):
```bash
python3 -m ajs_server.main --headless
```

### Running System Diagnostics:
```bash
python3 -m ajs_server.diagnostics
```

---

## 4. Connecting with AJ's Remote Android

1. Open **AJS Remote Server 2.0** on your Linux PC.
2. Ensure both the PC and your Android phone are connected to the same Wi-Fi router.
3. Open the **AJ's Remote** application on your Android phone.
4. Tap **Scan QR Code** and scan the QR code displayed on the server dashboard.
5. Enter the **6-digit pairing PIN** shown on your PC screen.
6. Once paired, your phone is permanently authenticated and can reconnect automatically anytime!
