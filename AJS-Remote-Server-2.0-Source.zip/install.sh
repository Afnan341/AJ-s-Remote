#!/usr/bin/env bash
# ==============================================================================
# AJS Remote Server 2.0 - One-Click Installer Script
# Primary Target: Linux Mint 22.x Cinnamon / Ubuntu 24.04 LTS (x86_64)
# ==============================================================================

set -e

GREEN="\033[92m"
RED="\033[91m"
YELLOW="\033[93m"
RESET="\033[0m"

echo -e "${GREEN}======================================================${RESET}"
echo -e "${GREEN}   AJS Remote Server 2.0 - Installer for Linux PC    ${RESET}"
echo -e "${GREEN}======================================================${RESET}"

# Check for root or sudo availability
if [ "$EUID" -ne 0 ]; then
    SUDO="sudo"
    echo -e "${YELLOW}[*] Prompting for sudo permissions to configure udev and install files...${RESET}"
else
    SUDO=""
fi

TARGET_USER="${SUDO_USER:-$USER}"

echo -e "\n${GREEN}[1/5] Installing System Dependencies...${RESET}"
$SUDO apt-get update -qq
$SUDO apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-evdev \
    python3-websockets \
    python3-qrcode \
    python3-pil \
    xclip

# Optional PySide6 install
if ! python3 -c "import PySide6" 2>/dev/null; then
    echo -e "${YELLOW}[*] Installing PySide6 for desktop GUI...${RESET}"
    $SUDO apt-get install -y python3-pyside6 || true
fi

echo -e "\n${GREEN}[2/5] Configuring Linux Kernel uinput Permissions...${RESET}"
# Load uinput kernel module
$SUDO modprobe uinput || true

# Ensure module loads automatically at boot
if ! grep -q "^uinput" /etc/modules 2>/dev/null; then
    echo "uinput" | $SUDO tee -a /etc/modules >/dev/null
fi

# Create uinput group
$SUDO groupadd -f uinput

# Add target user to uinput and input groups
$SUDO usermod -a -G uinput "$TARGET_USER" || true
$SUDO usermod -a -G input "$TARGET_USER" || true

# Install udev rule for persistent permissions
echo -e "${YELLOW}[*] Creating /etc/udev/rules.d/99-uinput.rules...${RESET}"
cat << 'EOF' | $SUDO tee /etc/udev/rules.d/99-uinput.rules >/dev/null
# uinput rules for AJS Remote Server Virtual Gamepad and Mouse
KERNEL=="uinput", MODE="0660", GROUP="uinput", OPTIONS+="static_node=uinput"
SUBSYSTEM=="input", ATTRS{name}=="*AJS*", MODE="0660", GROUP="uinput"
EOF

# Reload udev
$SUDO udevadm control --reload-rules || true
$SUDO udevadm trigger || true

echo -e "\n${GREEN}[3/5] Installing Application Binaries & Modules...${RESET}"
INSTALL_DIR="/opt/ajs-remote-server"
$SUDO mkdir -p "$INSTALL_DIR"
$SUDO cp -r ajs_server "$INSTALL_DIR/"
$SUDO cp requirements.txt "$INSTALL_DIR/"
$SUDO cp PROTOCOL.md "$INSTALL_DIR/"
$SUDO cp README.md "$INSTALL_DIR/"

# Create executable runner in /usr/local/bin
cat << 'EOF' | $SUDO tee /usr/local/bin/ajs-remote-server >/dev/null
#!/usr/bin/env bash
exec python3 -m ajs_server.main "$@"
EOF
$SUDO chmod +x /usr/local/bin/ajs-remote-server

echo -e "\n${GREEN}[4/5] Installing Application Menu Launcher & Icon...${RESET}"
$SUDO mkdir -p /usr/share/icons/hicolor/256x256/apps
if [ -f "ajs-remote-server.png" ]; then
    $SUDO cp ajs-remote-server.png /usr/share/icons/hicolor/256x256/apps/
fi

if [ -f "ajs-remote-server.desktop" ]; then
    $SUDO cp ajs-remote-server.desktop /usr/share/applications/
    $SUDO update-desktop-database /usr/share/applications/ 2>/dev/null || true
fi

echo -e "\n${GREEN}[5/5] Running Pre-Flight Diagnostics...${RESET}"
PYTHONPATH="$INSTALL_DIR" python3 -m ajs_server.diagnostics

echo -e "\n${GREEN}======================================================${RESET}"
echo -e "${GREEN}   INSTALLATION COMPLETE!                            ${RESET}"
echo -e "${GREEN}======================================================${RESET}"
echo -e "You can now launch AJS Remote Server 2.0:"
echo -e "  1. From Linux Mint Menu: ${YELLOW}Start -> Games -> AJS Remote Server 2.0${RESET}"
echo -e "  2. From terminal:        ${YELLOW}ajs-remote-server${RESET}"
echo -e "  3. Headless daemon mode: ${YELLOW}ajs-remote-server --headless${RESET}"
echo -e "\n${YELLOW}NOTE: If you were just added to the 'uinput' group, please log out and log back in once for permissions to take full effect.${RESET}\n"
